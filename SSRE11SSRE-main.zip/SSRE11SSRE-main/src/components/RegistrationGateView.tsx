import React, { useState, useMemo } from 'react';
import { User as FirebaseUser } from 'firebase/auth';
import { ShieldAlert, Send, CheckCircle2, User, Phone, Lock, Sparkles, Building2, RefreshCw, LogOut, ShieldCheck, Clock } from 'lucide-react';
import { UserAccount, UserRole } from '../types';
import { isOwnerEmail } from '../utils/labourAccountHelper';

interface RegistrationGateViewProps {
  currentUser: FirebaseUser;
  accounts: UserAccount[];
  onSaveUserAccount: (account: UserAccount) => Promise<void>;
  onSignOut: () => void;
}

export const RegistrationGateView: React.FC<RegistrationGateViewProps> = ({
  currentUser,
  accounts,
  onSaveUserAccount,
  onSignOut,
}) => {
  const [name, setName] = useState(currentUser.displayName || '');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('labour');
  const [aadhaar, setAadhaar] = useState('');
  const [specialization, setSpecialization] = useState('Gypsum Mistri');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitFeedback, setSubmitFeedback] = useState<string | null>(null);

  // Check if there's an existing registration for this Gmail email
  const existingRequest = useMemo(() => {
    return accounts.find(
      (acc) => acc.email.trim().toLowerCase() === (currentUser.email || '').trim().toLowerCase()
    );
  }, [accounts, currentUser.email]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setIsSubmitting(true);
    try {
      const newAccount: UserAccount = {
        id: existingRequest?.id || `usr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        name: name.trim(),
        email: (currentUser.email || '').trim().toLowerCase(),
        phone: phone.trim() || undefined,
        role,
        specialization: role === 'labour' ? specialization : 'Site Supervisor',
        status: 'pending',
        isVerifiedByOwner: false,
        registeredAt: new Date().toISOString(),
        aadhaarNo: aadhaar.trim() || undefined,
        photoUrl: currentUser.photoURL || undefined,
        updatedAt: new Date().toISOString(),
      };

      await onSaveUserAccount(newAccount);
      setSubmitFeedback('आपकी जानकारी Owner (ठेकेदार) को भेज दी गई है! Owner के Verify करते ही आपका बिल दिख जाएगा।');
    } catch (err: any) {
      alert(`Failed to submit request: ${err?.message || 'Error occurred'}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRefresh = () => {
    window.location.reload();
  };

  return (
    <div className="max-w-xl mx-auto my-8 p-6 sm:p-8 bg-white border border-slate-200 rounded-2xl shadow-xl space-y-6 text-slate-800 animate-in fade-in duration-200">
      {/* Brand & Gate Identity */}
      <div className="text-center space-y-2">
        <div className="w-16 h-16 mx-auto rounded-2xl bg-amber-500/15 text-amber-600 border border-amber-500/30 flex items-center justify-center shadow-inner">
          <Clock className="w-9 h-9" />
        </div>
        <div>
          <h2 className="text-xl font-black text-slate-950 tracking-tight">
            SSR Enterprises &bull; Labour Portal
          </h2>
          <p className="text-xs text-amber-700 font-extrabold uppercase tracking-wider mt-1">
            Owner Verification Pending &bull; (सत्यापन लंबित)
          </p>
        </div>
      </div>

      {/* Security Rule Explainer Card */}
      <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2 text-amber-950">
        <div className="flex items-center space-x-2 font-black text-xs uppercase tracking-wide text-amber-900">
          <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
          <span>सुरक्षा नियम: Owner अप्रूवल के बाद ही बिल दिखेगा</span>
        </div>
        <p className="text-xs text-amber-900/90 leading-relaxed font-medium">
          आपकी Gmail ID से लॉग-इन हो चुका है, लेकिन ठेकेदार (Owner) जब तक आपकी Gmail ID को <strong>Verify &amp; Approve</strong> नहीं करेंगे, तब तक आपका बिल और पेमेंट अमाउंट गोपनीय रहेगा।
        </p>
      </div>

      {/* Gmail Profile Info */}
      <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
        <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">लॉग-इन Gmail अकाउंट</span>
        <div className="flex items-center space-x-3">
          <div className="w-11 h-11 rounded-full border border-slate-200 bg-white overflow-hidden flex items-center justify-center shrink-0 shadow-xs">
            {currentUser.photoURL ? (
              <img src={currentUser.photoURL} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
            ) : (
              <User className="w-5 h-5 text-slate-400" />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <span className="font-extrabold text-sm text-slate-950 block truncate">
              {existingRequest?.name || currentUser.displayName || 'Labour Member'}
            </span>
            <span className="font-mono text-xs text-slate-600 block truncate">{currentUser.email}</span>
            {existingRequest?.ratePerSqft && (
              <span className="text-[11px] text-emerald-700 font-bold block mt-0.5">
                निर्धारित दर: ₹{existingRequest.ratePerSqft}/sqft
              </span>
            )}
          </div>
          <button
            type="button"
            onClick={onSignOut}
            className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-700 text-xs font-bold rounded-lg transition shrink-0 flex items-center space-x-1"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Logout</span>
          </button>
        </div>
      </div>

      {/* Dynamic State: Registered & Awaiting Owner Verification vs Not Registered Yet */}
      {submitFeedback ? (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl space-y-2 animate-in fade-in">
          <div className="flex items-center space-x-2 text-emerald-700 font-extrabold text-sm">
            <CheckCircle2 className="w-5 h-5 shrink-0" />
            <span>अनुरोध भेजा गया (Awaiting Owner Approval)</span>
          </div>
          <p className="text-xs">
            {submitFeedback}
          </p>
          <div className="pt-2">
            <button
              type="button"
              onClick={handleRefresh}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs flex items-center justify-center space-x-1.5 transition"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>वेरिफिकेशन स्थिति पुनः जांचें (Refresh)</span>
            </button>
          </div>
        </div>
      ) : existingRequest ? (
        <div className="p-5 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-ping" />
              <h4 className="font-black text-slate-900 text-sm">
                Owner सत्यापन लंबित (Pending Verification)
              </h4>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-amber-100 border border-amber-300 text-amber-800 font-black text-[10px] uppercase">
              {existingRequest.status}
            </span>
          </div>

          <div className="text-xs text-slate-600 space-y-2">
            <p>
              नमस्ते <strong>{existingRequest.name}</strong>! आपका खाता सिस्टम में दर्ज है। ठेकेदार (Owner: <span className="font-mono font-bold text-slate-800">ssre07860@gmail.com</span>) द्वारा आपकी इस Gmail ID को Verify करते ही आपका पूरा डिजिटल बिल और भुगतान राशि दिखाई देने लगेगी।
            </p>

            <div className="p-3 bg-white border border-slate-200 rounded-lg space-y-1.5 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-500">दर्ज नाम:</span>
                <span className="font-bold text-slate-900">{existingRequest.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">भूमिका:</span>
                <span className="font-bold text-slate-900 uppercase">{existingRequest.role}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Gmail ID:</span>
                <span className="font-mono text-slate-900">{existingRequest.email}</span>
              </div>
              {existingRequest.phone && (
                <div className="flex justify-between">
                  <span className="text-slate-500">मोबाइल नंबर:</span>
                  <span className="font-bold text-slate-900">{existingRequest.phone}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 pt-1">
            <button
              type="button"
              onClick={handleRefresh}
              className="flex-1 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black rounded-lg transition text-xs flex items-center justify-center space-x-1.5 shadow-sm"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>जांचें कि Owner ने Approve किया या नहीं</span>
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4 animate-in fade-in">
          <div className="space-y-1">
            <h3 className="font-black text-sm text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>लेबर प्रोफाइल विवरण दर्ज करें (Submit For Owner Verification)</span>
            </h3>
            <p className="text-xs text-slate-500">
              अपना नाम व मोबाइल नंबर दर्ज करें ताकि Owner आपकी Gmail ID को पहचानकर तुरंत Approve कर सकें।
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                आपका पूरा नाम (Labour / Mistri Name) *
              </label>
              <input
                type="text"
                required
                placeholder="उदा. Adil Ahmad / Ramesh"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                मोबाइल नंबर (Phone Number) *
              </label>
              <input
                type="text"
                required
                placeholder="10 अंकों का मोबाइल नंबर"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                काम का प्रकार (Trade / Work Type)
              </label>
              <input
                type="text"
                value={specialization}
                onChange={(e) => setSpecialization(e.target.value)}
                placeholder="उदा. Gypsum Mistri / Ceiling"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-medium text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                आधार नंबर (Aadhaar - Optional)
              </label>
              <input
                type="text"
                placeholder="12 digit Aadhaar"
                value={aadhaar}
                onChange={(e) => setAadhaar(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg font-medium text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none text-xs"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center space-x-2 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white font-black rounded-lg transition shadow-md cursor-pointer text-xs"
          >
            <Send className="w-4 h-4 text-amber-400" />
            <span>{isSubmitting ? 'अनुरोध भेजा जा रहा है...' : 'Owner को वेरिफिकेशन अनुरोध भेजें (Send for Approval)'}</span>
          </button>
        </form>
      )}

      <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
        <span>SSR Enterprises Billing Portal</span>
        <span>Owner: ssre07860@gmail.com</span>
      </div>
    </div>
  );
};
