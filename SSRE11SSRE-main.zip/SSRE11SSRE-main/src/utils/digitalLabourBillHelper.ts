import { collection, doc, getDocs, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import {
  FloorEntry,
  UnitSqftConfig,
  BillHeader,
  LabourDigitalBillRecord,
  LabourBillItem,
} from '../types';
import { numberToIndianWords } from './labourBillHelper';
import { getUnitSqftValue } from './monthlySummaryHelper';

const STORAGE_LABOUR_BILLS_KEY = 'ssr_labour_digital_bills_v2';

/**
 * Default Seed Labour Bills
 * Matching exact screenshot: SSR BILL (SSR01), 25/07/2026, Rs. 9,920 Work Amount, Rs. 72,000 Kharcha, Rs. -62,080 Net Balance
 */
export const INITIAL_LABOUR_DIGITAL_BILLS: LabourDigitalBillRecord[] = [
  {
    id: 'bill-ssr-01',
    billNo: 'SSR01',
    billingDate: '25/07/2026',
    paymentDate: '10/08/2026',
    monthYear: '2026-07',
    companyName: 'SSR ENTERPRISE',
    companyAddress: 'Varthur Gunjur Main Road Near Airtel Office\nBengaluru Urban Karnataka -560087',
    companyMobile: '+919026129779',
    companyEmail: 'ssrenterprises111@gmail.com',
    companyGstin: '29QZGPS3021A1Z9',
    toTitle: 'To',
    clientAddress: 'Prestige Lavender Field Varthur\nBangalore Karnataka -560087',
    clientMobile: '9916484804',
    salutation: 'Dear Sir/Madam',
    introNote: 'Thank You For Your Valuable Inquiry. We Are Pleased To Quotes As Below :',
    labourName: 'SSR BILL',
    labourAadhaar: '5684-8584-2200',
    labourMobile: '9916484804',
    towerNo: 'Tower 1',
    items: [
      {
        id: 'item-1',
        towerOrFloor: 'T=1/PLF',
        description: '11 Floor Unit No 1,2,3,4,5,6,7,8 (Labour: SSR Bill)',
        quantity: 5000,
        rate: 1,
        total: 5000,
      },
      {
        id: 'item-2',
        towerOrFloor: 'T=1/PLF',
        description: '12 Floor Lobby (Labour: SSR Bill)',
        quantity: 1,
        rate: 120,
        total: 120,
      },
      {
        id: 'item-3',
        towerOrFloor: 'T=1/PLF',
        description: 'Gf To 31 Floor Starcesh/1 (Labour: SSR Bill)',
        quantity: 32,
        rate: 120,
        total: 3840,
      },
      {
        id: 'item-4',
        towerOrFloor: 'T=1/PLF',
        description: 'New Floor Work Item',
        quantity: 1,
        rate: 120,
        total: 120,
      },
      {
        id: 'item-5',
        towerOrFloor: 'T=1/PLF',
        description: 'New Floor Work Item',
        quantity: 1,
        rate: 120,
        total: 120,
      },
      {
        id: 'item-6',
        towerOrFloor: 'T=1/PLF',
        description: 'New Floor Work Item',
        quantity: 1,
        rate: 120,
        total: 120,
      },
      {
        id: 'item-7',
        towerOrFloor: 'T=1/PLF',
        description: 'New Floor Work Item',
        quantity: 1,
        rate: 120,
        total: 120,
      },
      {
        id: 'item-8',
        towerOrFloor: 'T=1/PLF',
        description: 'New Floor Work Item',
        quantity: 1,
        rate: 120,
        total: 120,
      },
      {
        id: 'item-9',
        towerOrFloor: 'T=1/PLF',
        description: 'New Floor Work Item',
        quantity: 1,
        rate: 120,
        total: 120,
      },
      {
        id: 'item-10',
        towerOrFloor: 'T=1/PLF',
        description: 'New Floor Work Item',
        quantity: 1,
        rate: 120,
        total: 120,
      },
      {
        id: 'item-11',
        towerOrFloor: 'T=1/PLF',
        description: 'New Floor Work Item',
        quantity: 1,
        rate: 120,
        total: 120,
      },
    ],
    totalWorkAmount: 9920,
    totalKharcha: 72000,
    netBalancePayable: -62080,
    amountInWords: 'Nine Thousand Nine Hundred and Twenty Rupees Only',
    labourSignText: 'SSR',
    supervisorSignText: 'Ramu Kumar',
    contractorSignText: 'Rizwan',
    status: 'approved',
    createdAt: '2026-07-25T10:00:00.000Z',
    updatedAt: '2026-07-25T10:00:00.000Z',
  },
  {
    id: 'bill-adil-ahmad-02',
    billNo: 'SSR02',
    billingDate: '15/09/2026',
    paymentDate: '25/09/2026',
    monthYear: '2026-09',
    companyName: 'SSR ENTERPRISE',
    companyAddress: 'Varthur Gunjur Main Road Near Airtel Office\nBengaluru Urban Karnataka -560087',
    companyMobile: '+919026129779',
    companyEmail: 'ssrenterprises111@gmail.com',
    companyGstin: '29QZGPS3021A1Z9',
    toTitle: 'To',
    clientAddress: 'Prestige Lavender Field Varthur\nBangalore Karnataka -560087',
    clientMobile: '9916484804',
    salutation: 'Dear Sir/Madam',
    introNote: 'Thank You For Your Valuable Inquiry. We Are Pleased To Quotes As Below :',
    labourName: 'Adil Ahmad',
    labourAadhaar: '9845-2311-6677',
    labourMobile: '9876543210',
    towerNo: 'Tower 2',
    items: [
      {
        id: 'item-adil-1',
        towerOrFloor: 'T=2/FL-01',
        description: '01 Floor Unit No 1,2,3,4,5,6,7,8 (Labour: Adil Ahmad)',
        quantity: 5040,
        rate: 12,
        total: 60480,
      },
      {
        id: 'item-adil-2',
        towerOrFloor: 'T=2/FL-02',
        description: '02 Floor Unit No 1,2,3,4,5,6,7,8 (Labour: Adil Ahmad)',
        quantity: 5040,
        rate: 12,
        total: 60480,
      },
      {
        id: 'item-adil-3',
        towerOrFloor: 'T=2/FL-02',
        description: '02 Floor Lobby (Labour: Adil Ahmad)',
        quantity: 1,
        rate: 120,
        total: 120,
      },
      {
        id: 'item-adil-4',
        towerOrFloor: 'T=2/STAR',
        description: '01 to 05 Floor Starcesh/1 (Labour: Adil Ahmad)',
        quantity: 5,
        rate: 120,
        total: 600,
      },
    ],
    totalWorkAmount: 121680,
    totalKharcha: 45000,
    netBalancePayable: 76680,
    amountInWords: 'One Lakh Twenty One Thousand Six Hundred and Eighty Rupees Only',
    labourSignText: 'Adil Ahmad',
    supervisorSignText: 'Ramu Kumar',
    contractorSignText: 'Rizwan',
    status: 'approved',
    createdAt: '2026-09-15T12:00:00.000Z',
    updatedAt: '2026-09-15T12:00:00.000Z',
  },
];

/**
 * Calculate totals for digital bill
 */
export function calculateDigitalBillTotals(
  items: LabourBillItem[],
  totalKharcha: number
): {
  totalWorkAmount: number;
  totalKharcha: number;
  netBalancePayable: number;
  amountInWords: string;
} {
  const totalWorkAmount = items.reduce((sum, it) => sum + (Number(it.total) || 0), 0);
  const netBalancePayable = totalWorkAmount - (Number(totalKharcha) || 0);
  const amountInWords = numberToIndianWords(Math.max(0, totalWorkAmount));

  return {
    totalWorkAmount,
    totalKharcha,
    netBalancePayable,
    amountInWords,
  };
}

/**
 * Build dynamic digital bill items from actual verified floor records for a specific labour
 */
export function buildDigitalBillFromFloors(
  labourName: string,
  floors: FloorEntry[],
  sqftConfig: UnitSqftConfig,
  header: BillHeader,
  options?: {
    ratePerSqft?: number;
    billingDate?: string;
    paymentDate?: string;
    totalKharcha?: number;
    towerFilter?: string;
  }
): LabourDigitalBillRecord {
  const normLabour = labourName.trim().toLowerCase();
  const rate = options?.ratePerSqft || header.defaultLabourRate || 12;
  const filteredFloors = options?.towerFilter && options.towerFilter !== 'all'
    ? floors.filter((f) => f.towerNo === options.towerFilter)
    : floors;

  const items: LabourBillItem[] = [];

  // Group work by floor
  filteredFloors.forEach((floor) => {
    // Check units 1 to 8
    const flatUnitKeys = ['unit1', 'unit2', 'unit3', 'unit4', 'unit5', 'unit6', 'unit7', 'unit8'];
    const matchedFlats: number[] = [];
    let flatsSqft = 0;

    flatUnitKeys.forEach((key, idx) => {
      const uLabour = floor.unitLabours?.[key] || floor.labourName || '';
      const uStatus = floor[key as keyof FloorEntry];
      if (uLabour.trim().toLowerCase() === normLabour && uStatus === 'paid') {
        matchedFlats.push(idx + 1);
        flatsSqft += getUnitSqftValue(key, sqftConfig);
      }
    });

    const towerPrefix = floor.towerNo.replace(/[^0-9]/g, '') || '1';

    if (matchedFlats.length > 0) {
      const isAllFlats = matchedFlats.length === 8;
      const desc = isAllFlats
        ? `${floor.floorNo} Floor Unit No 1,2,3,4,5,6,7,8 (Labour: ${labourName})`
        : `${floor.floorNo} Floor Unit No ${matchedFlats.join(',')} (Labour: ${labourName})`;

      items.push({
        id: `item-${floor.id}-flats`,
        towerOrFloor: `T=${towerPrefix}/FL-${floor.floorNo}`,
        description: desc,
        quantity: flatsSqft > 0 ? flatsSqft : 5000,
        rate: rate,
        total: Math.round((flatsSqft > 0 ? flatsSqft : 5000) * rate),
      });
    }

    // Check Lobby
    const lobbyLabour = floor.unitLabours?.lobby || floor.labourName || '';
    if (lobbyLabour.trim().toLowerCase() === normLabour && floor.lobby === 'paid') {
      const lobbySqft = getUnitSqftValue('lobby', sqftConfig) || 120;
      items.push({
        id: `item-${floor.id}-lobby`,
        towerOrFloor: `T=${towerPrefix}/LOBBY`,
        description: `${floor.floorNo} Floor Lobby (Labour: ${labourName})`,
        quantity: 1,
        rate: 120,
        total: 120,
      });
    }

    // Check Starc 1
    const starc1Labour = floor.unitLabours?.starc1 || floor.labourName || '';
    if (starc1Labour.trim().toLowerCase() === normLabour && floor.starc1 === 'paid') {
      items.push({
        id: `item-${floor.id}-starc1`,
        towerOrFloor: `T=${towerPrefix}/STAR1`,
        description: `${floor.floorNo} Floor Starcesh/1 (Labour: ${labourName})`,
        quantity: 1,
        rate: 120,
        total: 120,
      });
    }

    // Check Starc 2
    const starc2Labour = floor.unitLabours?.starc2 || floor.labourName || '';
    if (starc2Labour.trim().toLowerCase() === normLabour && floor.starc2 === 'paid') {
      items.push({
        id: `item-${floor.id}-starc2`,
        towerOrFloor: `T=${towerPrefix}/STAR2`,
        description: `${floor.floorNo} Floor Starcesh/2 (Labour: ${labourName})`,
        quantity: 1,
        rate: 120,
        total: 120,
      });
    }
  });

  // If no items generated, provide 3 default rows so the bill is ready for immediate editing
  if (items.length === 0) {
    items.push({
      id: `item-def-1`,
      towerOrFloor: `T=1/PLF`,
      description: `11 Floor Unit No 1,2,3,4,5,6,7,8 (Labour: ${labourName})`,
      quantity: 5000,
      rate: rate,
      total: 5000 * rate,
    });
    items.push({
      id: `item-def-2`,
      towerOrFloor: `T=1/PLF`,
      description: `12 Floor Lobby (Labour: ${labourName})`,
      quantity: 1,
      rate: 120,
      total: 120,
    });
    items.push({
      id: `item-def-3`,
      towerOrFloor: `T=1/PLF`,
      description: `Gf To 31 Floor Starcesh/1 (Labour: ${labourName})`,
      quantity: 32,
      rate: 120,
      total: 3840,
    });
  }

  const kharcha = options?.totalKharcha ?? 0;
  const totals = calculateDigitalBillTotals(items, kharcha);

  const billCode = `SSR-${labourName.slice(0, 2).toUpperCase()}-${Math.floor(10 + Math.random() * 90)}`;
  const nowStr = new Date().toLocaleDateString('en-GB'); // DD/MM/YYYY

  return {
    id: `bill-${labourName.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${Date.now()}`,
    billNo: billCode,
    billingDate: options?.billingDate || nowStr,
    paymentDate: options?.paymentDate || nowStr,
    monthYear: new Date().toISOString().slice(0, 7),
    companyName: header.scName || 'SSR ENTERPRISE',
    companyAddress: header.address || 'Varthur Gunjur Main Road Near Airtel Office\nBengaluru Urban Karnataka -560087',
    companyMobile: '+919026129779',
    companyEmail: 'ssrenterprises111@gmail.com',
    companyGstin: '29QZGPS3021A1Z9',
    toTitle: 'To',
    clientAddress: `${header.projectName || 'Prestige Lavender Field Varthur'}\nBangalore Karnataka -560087`,
    clientMobile: '9916484804',
    salutation: 'Dear Sir/Madam',
    introNote: 'Thank You For Your Valuable Inquiry. We Are Pleased To Quotes As Below :',
    labourName: labourName,
    labourAadhaar: '5684-8584-2200',
    labourMobile: '9916484804',
    towerNo: options?.towerFilter || header.towerNo || 'Tower 1',
    items,
    totalWorkAmount: totals.totalWorkAmount,
    totalKharcha: totals.totalKharcha,
    netBalancePayable: totals.netBalancePayable,
    amountInWords: totals.amountInWords,
    labourSignText: labourName,
    supervisorSignText: header.supervisorSignature || 'Ramu Kumar',
    contractorSignText: header.contractorSignature || 'Rizwan',
    status: 'approved',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

/**
 * Load Labour Digital Bills from Firestore or LocalStorage
 */
export async function loadDigitalBillRecords(): Promise<LabourDigitalBillRecord[]> {
  try {
    const querySnapshot = await getDocs(collection(db, 'labour_bills'));
    if (!querySnapshot.empty) {
      const records: LabourDigitalBillRecord[] = [];
      querySnapshot.forEach((d) => {
        records.push({ ...(d.data() as LabourDigitalBillRecord), id: d.id });
      });
      localStorage.setItem(STORAGE_LABOUR_BILLS_KEY, JSON.stringify(records));
      return records;
    }
  } catch (err) {
    console.info('Firestore labour_bills read fallback to local state:', err);
  }

  // Fallback to local storage
  const cached = localStorage.getItem(STORAGE_LABOUR_BILLS_KEY);
  if (cached) {
    try {
      const parsed = JSON.parse(cached);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    } catch {
      // Ignore
    }
  }

  // Default seed
  localStorage.setItem(STORAGE_LABOUR_BILLS_KEY, JSON.stringify(INITIAL_LABOUR_DIGITAL_BILLS));
  return INITIAL_LABOUR_DIGITAL_BILLS;
}

/**
 * Save or Update Labour Digital Bill Record in Firestore & LocalStorage
 */
export async function saveDigitalBillRecord(record: LabourDigitalBillRecord): Promise<void> {
  const updated: LabourDigitalBillRecord = {
    ...record,
    updatedAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'labour_bills', record.id), updated, { merge: true });
  } catch (err) {
    console.warn('Could not sync digital bill to Firestore:', err);
  }

  const current = await loadDigitalBillRecords();
  const index = current.findIndex((b) => b.id === record.id);
  let updatedList: LabourDigitalBillRecord[];
  if (index >= 0) {
    updatedList = [...current];
    updatedList[index] = updated;
  } else {
    updatedList = [updated, ...current];
  }
  localStorage.setItem(STORAGE_LABOUR_BILLS_KEY, JSON.stringify(updatedList));
}

/**
 * Delete Labour Digital Bill Record from Firestore & LocalStorage
 */
export async function deleteDigitalBillRecord(billId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'labour_bills', billId));
  } catch (err) {
    console.warn('Could not delete digital bill from Firestore:', err);
  }

  const current = await loadDigitalBillRecords();
  const updatedList = current.filter((b) => b.id !== billId);
  localStorage.setItem(STORAGE_LABOUR_BILLS_KEY, JSON.stringify(updatedList));
}
