import React, { useState, useMemo } from 'react';
import {
  X,
  Shield,
  ShieldCheck,
  UserPlus,
  Users,
  Building,
  FileCheck,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  Lock,
  Mail,
  Phone,
  Settings,
  PlusCircle,
  Database,
  ArrowRight,
  Eye,
  Check,
  RotateCcw,
  Sparkles,
  Layers,
  DollarSign,
  CloudCheck,
  LogOut,
  Clock,
  Search,
} from 'lucide-react';
import { User as FirebaseUser } from 'firebase/auth';
import { LabourRegistrationModal } from './LabourRegistrationModal';
import { User } from 'lucide-react';
import {
  FloorEntry,
  BillHeader,
  UnitSqftConfig,
  UserAccount,
  UserRole,
  UserAccessInfo,
  LabourMonthlyApproval,
} from '../types';
import { UNIT_CONFIG_MAP, toggleFloorCompletedStatus } from '../utils/floorCalculationHelper';
import { getUniqueTowers, generateFloorsForNewTower, deduplicateFloors } from '../utils/towerHelper';
import { getUniqueLabourNames } from '../utils/labourBillHelper';
import { isOwnerEmail, calculateLabourWorkRecords } from '../utils/labourAccountHelper';
import { ConfirmationDialog } from './ConfirmationDialog';

interface OwnerAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: FirebaseUser | null;
  userAccess: UserAccessInfo;
  floors: FloorEntry[];
  header: BillHeader;
  sqftConfig: UnitSqftConfig;
  accounts: UserAccount[];
  monthlyApprovals: LabourMonthlyApproval[];
  onSaveHeader: (header: BillHeader) => void;
  onSaveSqftConfig: (config: UnitSqftConfig) => void;
  onUpdateFloor: (floor: FloorEntry) => void;
  onDeleteFloor: (floorId: string) => void;
  onBatchDeleteFloors: (floorIds: string[]) => void;
  onBatchSaveFloors: (updatedFloors: FloorEntry[]) => void;
  onAddTowerFloors: (newFloors: FloorEntry[]) => void;
  onSaveUserAccount: (account: UserAccount) => Promise<void>;
  onDeleteUserAccount: (accountId: string) => Promise<void>;
  onSaveMonthlyApproval: (approval: LabourMonthlyApproval) => Promise<void>;
  onOpenGmailModal: () => void;
  onBackupNow: () => Promise<void>;
  onRestoreFromCloud: () => Promise<void>;
  onEditFloorClick: (floor: FloorEntry) => void;
  initialTab?: 'labour_gmail' | 'users' | 'sites' | 'bills' | 'master_floors' | 'rates' | 'requests';
}

export const OwnerAdminModal: React.FC<OwnerAdminModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  userAccess,
  floors,
  header,
  sqftConfig,
  accounts,
  monthlyApprovals,
  onSaveHeader,
  onSaveSqftConfig,
  onUpdateFloor,
  onDeleteFloor,
  onBatchDeleteFloors,
  onBatchSaveFloors,
  onAddTowerFloors,
  onSaveUserAccount,
  onDeleteUserAccount,
  onSaveMonthlyApproval,
  onOpenGmailModal,
  onBackupNow,
  onRestoreFromCloud,
  onEditFloorClick,
  initialTab,
}) => {
  const [activeTab, setActiveTab] = useState<'labour_gmail' | 'users' | 'sites' | 'bills' | 'master_floors' | 'rates' | 'requests'>(
    initialTab || 'labour_gmail'
  );

  React.useEffect(() => {
    if (initialTab) {
      setActiveTab(initialTab);
    }
  }, [initialTab, isOpen]);

  // Labour Gmail Connect & Verify State
  const [labourGmailName, setLabourGmailName] = useState('');
  const [labourGmailEmail, setLabourGmailEmail] = useState('');
  const [labourGmailPhone, setLabourGmailPhone] = useState('');
  const [labourGmailRate, setLabourGmailRate] = useState<number>(12);
  const [labourGmailSearch, setLabourGmailSearch] = useState('');
  const [labourGmailFeedback, setLabourGmailFeedback] = useState<string | null>(null);

  // Labour registration modal states
  const [isLabourModalOpen, setIsLabourModalOpen] = useState(false);
  const [selectedLabourForEdit, setSelectedLabourForEdit] = useState<UserAccount | null>(null);

  // New User Form State
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserPhone, setNewUserPhone] = useState('');
  const [newUserRole, setNewUserRole] = useState<UserRole>('supervisor');
  const [newUserSpecialization, setNewUserSpecialization] = useState('Site Supervisor');
  const [newUserTower, setNewUserTower] = useState('All Towers');
  const [newUserRate, setNewUserRate] = useState<number>(12);
  const [userFeedback, setUserFeedback] = useState<string | null>(null);

  // Sites Form State
  const [siteHeaderForm, setSiteHeaderForm] = useState<BillHeader>(header);
  const [newTowerName, setNewTowerName] = useState('');
  const [newTowerFloorsCount, setNewTowerFloorsCount] = useState<number>(26);
  const [siteFeedback, setSiteFeedback] = useState<string | null>(null);

  // Master Floors Controls
  const [floorSearch, setFloorSearch] = useState('');
  const [selectedTowerFilter, setSelectedTowerFilter] = useState<string>('all');
  const [selectedFloorIds, setSelectedFloorIds] = useState<string[]>([]);
  const [bulkActionFeedback, setBulkActionFeedback] = useState<string | null>(null);

  // Rates Form
  const [sqftForm, setSqftForm] = useState<UnitSqftConfig>(sqftConfig);
  const [ratesFeedback, setRatesFeedback] = useState<string | null>(null);

  // Extra custom unit form states
  const [extraUnitKey, setExtraUnitKey] = useState('');
  const [extraUnitLabel, setExtraUnitLabel] = useState('');
  const [extraUnitSqft, setExtraUnitSqft] = useState<number>(0);

  // OTP Verification States
  const [otpModalOpen, setOtpModalOpen] = useState(false);
  const [otpTargetMonth, setOtpTargetMonth] = useState<string>('');
  const [otpTargetLabour, setOtpTargetLabour] = useState<string>('');
  const [otpTargetBill, setOtpTargetBill] = useState<{
    totalSqft: number;
    ratePerSqft: number;
    grossAmount: number;
    holdAmount: number;
    advanceDeduction: number;
    netPayable: number;
    email?: string;
  } | null>(null);
  const [otpTargetAction, setOtpTargetAction] = useState<'approve' | 'reject'>('approve');
  const [generatedOtp, setGeneratedOtp] = useState<string>('');
  const [enteredOtp, setEnteredOtp] = useState<string>('');
  const [otpCountdown, setOtpCountdown] = useState<number>(120); // 120s (2 minutes)
  const [otpError, setOtpError] = useState<string | null>(null);
  const [resendCooldown, setResendCooldown] = useState<number>(30); // 30s resend cooldown
  const [showSmtpAlert, setShowSmtpAlert] = useState<boolean>(false);

  // Destructive Action Confirmation Dialog State
  const [confirmDialogState, setConfirmDialogState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmText?: string;
    itemDetails?: { label: string; value: string | number }[];
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  // OTP Countdown & Cooldown Timer Effect
  React.useEffect(() => {
    let timer: NodeJS.Timeout;
    if (otpModalOpen) {
      timer = setInterval(() => {
        setOtpCountdown((prev) => (prev > 0 ? prev - 1 : 0));
        setResendCooldown((prev) => (prev > 0 ? prev - 1 : 0));
      }, 1000);
    }
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [otpModalOpen]);

  const availableTowers = useMemo(() => getUniqueTowers(floors), [floors]);
  const availableLabours = useMemo(() => getUniqueLabourNames(floors), [floors]);

  // Filtered labour accounts for Labour Gmail tab
  const filteredLabourAccounts = useMemo(() => {
    return accounts
      .filter((a) => a.role === 'labour')
      .filter((a) => {
        if (!labourGmailSearch.trim()) return true;
        const q = labourGmailSearch.toLowerCase();
        return (
          a.name.toLowerCase().includes(q) ||
          a.email.toLowerCase().includes(q) ||
          (a.phone && a.phone.includes(q))
        );
      });
  }, [accounts, labourGmailSearch]);

  const handleAddAndVerifyLabourGmail = async (autoApprove: boolean = true) => {
    if (!labourGmailName.trim()) {
      alert('कृपया लेबर का नाम चुनें या दर्ज करें (Please enter or select Labour Name)');
      return;
    }
    if (!labourGmailEmail.trim() || !labourGmailEmail.includes('@')) {
      alert('कृपया मान्य Gmail ID दर्ज करें (Please enter a valid Gmail ID)');
      return;
    }

    const cleanEmail = labourGmailEmail.trim().toLowerCase();
    const cleanName = labourGmailName.trim();

    const existing = accounts.find((a) => a.email.trim().toLowerCase() === cleanEmail);

    const accountToSave: UserAccount = {
      id: existing ? existing.id : `usr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: cleanName,
      mappedLabourName: cleanName,
      email: cleanEmail,
      phone: labourGmailPhone.trim() || existing?.phone || undefined,
      role: 'labour',
      specialization: 'Gypsum Mistri',
      assignedTower: 'All Towers',
      ratePerSqft: labourGmailRate || existing?.ratePerSqft || 12,
      status: autoApprove ? 'approved' : 'pending',
      isVerifiedByOwner: autoApprove,
      verifiedByEmail: currentUser?.email || 'ssre07860@gmail.com',
      verifiedAt: autoApprove ? new Date().toISOString() : undefined,
      registeredAt: existing ? existing.registeredAt : new Date().toISOString(),
      approvedBy: `${currentUser?.email || 'ssre07860@gmail.com'} (SSR Owner)`,
      approvedAt: autoApprove ? new Date().toISOString() : undefined,
      updatedAt: new Date().toISOString(),
    };

    try {
      await onSaveUserAccount(accountToSave);
      setLabourGmailFeedback(
        autoApprove
          ? `सफलता: लेबर "${cleanName}" (${cleanEmail}) को Owner द्वारा Verify & Approve कर दिया गया! अब वे लॉग-इन करके अपना डिजिटल बिल देख सकते हैं।`
          : `लेबर "${cleanName}" (${cleanEmail}) को Pending में जोड़ दिया गया।`
      );
      setLabourGmailName('');
      setLabourGmailEmail('');
      setLabourGmailPhone('');
      setTimeout(() => setLabourGmailFeedback(null), 4500);
    } catch (err: any) {
      alert(`त्रुटि: ${err?.message || 'Failed to save labour account'}`);
    }
  };

  const handleToggleLabourVerification = async (account: UserAccount) => {
    const isCurrentlyApproved = account.status === 'approved' && account.isVerifiedByOwner !== false;
    const nextApproved = !isCurrentlyApproved;

    const updated: UserAccount = {
      ...account,
      status: nextApproved ? 'approved' : 'rejected',
      isVerifiedByOwner: nextApproved,
      verifiedByEmail: currentUser?.email || 'ssre07860@gmail.com',
      verifiedAt: nextApproved ? new Date().toISOString() : undefined,
      approvedBy: `${currentUser?.email || 'ssre07860@gmail.com'} (SSR Owner)`,
      approvedAt: nextApproved ? new Date().toISOString() : undefined,
      updatedAt: new Date().toISOString(),
    };

    await onSaveUserAccount(updated);
    setLabourGmailFeedback(
      nextApproved
        ? `लेबर "${account.name}" (${account.email}) को Owner द्वारा Verify & Approve कर दिया गया! अब वे अपना बिल देख सकते हैं।`
        : `लेबर "${account.name}" (${account.email}) की बिल अनुमति रोक दी गई (Access Revoked).`
    );
    setTimeout(() => setLabourGmailFeedback(null), 3500);
  };

  // Memoize all pending supervisor requests
  const pendingRequests = useMemo(() => {
    const list: Array<{
      floorId: string;
      floorNo: string;
      towerNo: string;
      unitKey: string;
      unitLabel: string;
      labourName: string;
      sqft: number;
      floor: FloorEntry;
    }> = [];

    const unitKeysWithLabels = [
      { key: 'unit1', configKey: 'unit1', label: 'Unit 1' },
      { key: 'unit2', configKey: 'unit2', label: 'Unit 2' },
      { key: 'unit3', configKey: 'unit3', label: 'Unit 3' },
      { key: 'unit4', configKey: 'unit4', label: 'Unit 4' },
      { key: 'unit5', configKey: 'unit5', label: 'Unit 5' },
      { key: 'unit6', configKey: 'unit6', label: 'Unit 6' },
      { key: 'unit7', configKey: 'unit7', label: 'Unit 7' },
      { key: 'unit8', configKey: 'unit8', label: 'Unit 8' },
      { key: 'lobby', configKey: 'lobby', label: 'Lobby' },
      { key: 'starc1', configKey: 'starc1', label: 'Star C1' },
      { key: 'starc2', configKey: 'starc2', label: 'Star C2' },
    ];

    floors.forEach((f) => {
      unitKeysWithLabels.forEach(({ key, configKey, label }) => {
        if (f[key as keyof FloorEntry] === 'pending') {
          const sqft = Number(sqftConfig[configKey as keyof UnitSqftConfig] || 0);
          const assignedLabour = (f.unitLabours && f.unitLabours[key]) || f.labourName || 'Adil Ahmad';
          list.push({
            floorId: f.id,
            floorNo: f.floorNo,
            towerNo: f.towerNo || 'Tower 2',
            unitKey: key,
            unitLabel: label,
            labourName: assignedLabour,
            sqft,
            floor: f,
          });
        }
      });
    });

    return list;
  }, [floors, sqftConfig]);

  const handleApproveRequest = (floor: FloorEntry, unitKey: string) => {
    const updated: FloorEntry = {
      ...floor,
      [unitKey]: 'paid' as const,
    };

    let flatsCount = 0;
    ['unit1', 'unit2', 'unit3', 'unit4', 'unit5', 'unit6', 'unit7', 'unit8'].forEach((k) => {
      if (updated[k as keyof FloorEntry] === 'paid') flatsCount++;
    });

    const lobbyCount = updated.lobby === 'paid' ? 1 : 0;
    const s1Count = updated.starc1 === 'paid' ? 1 : 0;
    const s2Count = updated.starc2 === 'paid' ? 1 : 0;

    updated.gypsumRunningFlats = flatsCount;
    updated.gypsumRunningLobby = lobbyCount;
    updated.starches1WC = s1Count;
    updated.starches2WC = s2Count;
    updated.verifyFlats = flatsCount;
    updated.verifyLobby = lobbyCount;
    updated.verifyStar1 = s1Count;
    updated.verifyStar2 = s2Count;

    let completedSqft = 0;
    const unitKeysWithConfig = [
      { key: 'unit1', configKey: 'unit1' },
      { key: 'unit2', configKey: 'unit2' },
      { key: 'unit3', configKey: 'unit3' },
      { key: 'unit4', configKey: 'unit4' },
      { key: 'unit5', configKey: 'unit5' },
      { key: 'unit6', configKey: 'unit6' },
      { key: 'unit7', configKey: 'unit7' },
      { key: 'unit8', configKey: 'unit8' },
      { key: 'lobby', configKey: 'lobby' },
      { key: 'starc1', configKey: 'starc1' },
      { key: 'starc2', configKey: 'starc2' },
    ];
    unitKeysWithConfig.forEach(({ key, configKey }) => {
      if (updated[key as keyof FloorEntry] === 'paid') {
        completedSqft += Number(sqftConfig[configKey as keyof UnitSqftConfig] || 0);
      }
    });

    const holdPercent = 20;
    const releaseQty = floor.releaseQuantity > 0 ? floor.releaseQuantity : completedSqft;

    if (flatsCount === 8 && lobbyCount === 1 && s1Count === 1 && s2Count === 1) {
      const holdQty = Math.round((releaseQty * holdPercent) / 100);
      updated.releaseQuantity = releaseQty;
      updated.holdQuantity = holdQty;
      updated.paidQuantity = releaseQty - holdQty;
    } else if (flatsCount === 0 && lobbyCount === 0 && s1Count === 0 && s2Count === 0) {
      updated.releaseQuantity = releaseQty;
      updated.holdQuantity = releaseQty;
      updated.paidQuantity = 0;
    } else {
      const calculatedPaid = Math.max(0, Math.round(completedSqft * (1 - holdPercent / 100)));
      updated.releaseQuantity = releaseQty;
      updated.paidQuantity = calculatedPaid;
      updated.holdQuantity = Math.max(0, releaseQty - calculatedPaid);
    }

    updated.updatedAt = new Date().toISOString();
    onUpdateFloor(updated);
  };

  const handleApproveAllRequests = () => {
    if (pendingRequests.length === 0) return;
    
    const floorGroups: Record<string, FloorEntry> = {};
    
    pendingRequests.forEach((req) => {
      const floorId = req.floorId;
      if (!floorGroups[floorId]) {
        floorGroups[floorId] = { ...req.floor };
      }
      (floorGroups[floorId][req.unitKey as keyof FloorEntry] as any) = 'paid';
    });
    
    const updatedFloors = Object.values(floorGroups).map((floor) => {
      let updated = { ...floor };
      
      let flatsCount = 0;
      ['unit1', 'unit2', 'unit3', 'unit4', 'unit5', 'unit6', 'unit7', 'unit8'].forEach((k) => {
        if (updated[k as keyof FloorEntry] === 'paid') flatsCount++;
      });

      const lobbyCount = updated.lobby === 'paid' ? 1 : 0;
      const s1Count = updated.starc1 === 'paid' ? 1 : 0;
      const s2Count = updated.starc2 === 'paid' ? 1 : 0;

      updated.gypsumRunningFlats = flatsCount;
      updated.gypsumRunningLobby = lobbyCount;
      updated.starches1WC = s1Count;
      updated.starches2WC = s2Count;
      updated.verifyFlats = flatsCount;
      updated.verifyLobby = lobbyCount;
      updated.verifyStar1 = s1Count;
      updated.verifyStar2 = s2Count;

      let completedSqft = 0;
      const unitKeysWithConfig = [
        { key: 'unit1', configKey: 'unit1' },
        { key: 'unit2', configKey: 'unit2' },
        { key: 'unit3', configKey: 'unit3' },
        { key: 'unit4', configKey: 'unit4' },
        { key: 'unit5', configKey: 'unit5' },
        { key: 'unit6', configKey: 'unit6' },
        { key: 'unit7', configKey: 'unit7' },
        { key: 'unit8', configKey: 'unit8' },
        { key: 'lobby', configKey: 'lobby' },
        { key: 'starc1', configKey: 'starc1' },
        { key: 'starc2', configKey: 'starc2' },
      ];
      unitKeysWithConfig.forEach(({ key, configKey }) => {
        if (updated[key as keyof FloorEntry] === 'paid') {
          completedSqft += Number(sqftConfig[configKey as keyof UnitSqftConfig] || 0);
        }
      });

      const holdPercent = 20;
      const releaseQty = floor.releaseQuantity > 0 ? floor.releaseQuantity : completedSqft;

      if (flatsCount === 8 && lobbyCount === 1 && s1Count === 1 && s2Count === 1) {
        const holdQty = Math.round((releaseQty * holdPercent) / 100);
        updated.releaseQuantity = releaseQty;
        updated.holdQuantity = holdQty;
        updated.paidQuantity = releaseQty - holdQty;
      } else if (flatsCount === 0 && lobbyCount === 0 && s1Count === 0 && s2Count === 0) {
        updated.releaseQuantity = releaseQty;
        updated.holdQuantity = releaseQty;
        updated.paidQuantity = 0;
      } else {
        const calculatedPaid = Math.max(0, Math.round(completedSqft * (1 - holdPercent / 100)));
        updated.releaseQuantity = releaseQty;
        updated.paidQuantity = calculatedPaid;
        updated.holdQuantity = Math.max(0, releaseQty - calculatedPaid);
      }

      updated.updatedAt = new Date().toISOString();
      return updated;
    });
    
    onBatchSaveFloors(updatedFloors);
    setBulkActionFeedback(`Successfully approved all ${pendingRequests.length} pending supervisor work requests!`);
    setTimeout(() => setBulkActionFeedback(null), 3500);
  };

  // Master Floors Filtered List (must be before early return to satisfy Rules of Hooks)
  const filteredFloorsList = useMemo(() => {
    return floors.filter((f) => {
      if (selectedTowerFilter !== 'all' && f.towerNo !== selectedTowerFilter) {
        return false;
      }
      if (floorSearch.trim()) {
        const q = floorSearch.toLowerCase();
        const matchFloor = String(f.floorNo).toLowerCase().includes(q);
        const matchFlats = (f.flatsNo || '').toLowerCase().includes(q);
        const matchLabour = (f.labourName || '').toLowerCase().includes(q);
        if (!matchFloor && !matchFlats && !matchLabour) return false;
      }
      return true;
    });
  }, [floors, selectedTowerFilter, floorSearch]);

  const computedLabourBills = useMemo(() => {
    const list: Array<{
      id: string;
      monthYear: string;
      labourName: string;
      email?: string;
      totalSqft: number;
      ratePerSqft: number;
      grossAmount: number;
      holdAmount: number;
      advanceDeduction: number;
      netPayable: number;
      status: 'approved' | 'pending' | 'rejected';
      remarks?: string;
      paymentStatus: 'paid' | 'partial' | 'pending';
    }> = [];

    // Let's get all unique labours and months
    const allLabours = getUniqueLabourNames(floors);
    const months = ['2026-09', '2026-08', '2026-07'];

    months.forEach((m) => {
      allLabours.forEach((lab) => {
        // Let's see if there is an existing approval record in database
        const matchDb = monthlyApprovals.find(
          (a) => a.monthYear === m && a.labourName.toLowerCase() === lab.toLowerCase()
        );

        // Let's calculate active work details for this labour and month
        const stats = calculateLabourWorkRecords(lab, floors, sqftForm, 12, m);

        // If they have no work and no DB record, skip them to keep list clean
        if (stats.totalUnits === 0 && !matchDb) {
          return;
        }

        const registeredAcc = accounts.find((a) => a.name.toLowerCase() === lab.toLowerCase());

        list.push({
          id: matchDb ? matchDb.id : `approval-${m}-${lab.replace(/\s+/g, '_')}`,
          monthYear: m,
          labourName: lab,
          email: registeredAcc?.email || matchDb?.labourEmail || '',
          totalSqft: matchDb ? matchDb.totalSqft : stats.totalSqft,
          ratePerSqft: matchDb ? matchDb.ratePerSqft : (registeredAcc?.ratePerSqft || 12),
          grossAmount: matchDb ? matchDb.grossAmount : stats.grossAmount,
          holdAmount: matchDb ? matchDb.holdAmount : stats.holdAmount,
          advanceDeduction: matchDb ? matchDb.advanceDeduction : stats.advanceDeduction,
          netPayable: matchDb ? matchDb.netPayable : stats.netPayable,
          status: matchDb ? matchDb.status : 'pending',
          remarks: matchDb?.remarks || 'Automatic calculation based on completed units',
          paymentStatus: matchDb ? matchDb.paymentStatus : 'pending',
        });
      });
    });

    // Also include any other database approvals that aren't in floors (like summary or legacy entries)
    monthlyApprovals.forEach((dbApp) => {
      const alreadyAdded = list.some((item) => item.id === dbApp.id);
      if (!alreadyAdded) {
        list.push({
          id: dbApp.id,
          monthYear: dbApp.monthYear,
          labourName: dbApp.labourName,
          email: dbApp.labourEmail || '',
          totalSqft: dbApp.totalSqft,
          ratePerSqft: dbApp.ratePerSqft,
          grossAmount: dbApp.grossAmount,
          holdAmount: dbApp.holdAmount,
          advanceDeduction: dbApp.advanceDeduction,
          netPayable: dbApp.netPayable,
          status: dbApp.status,
          remarks: dbApp.remarks,
          paymentStatus: dbApp.paymentStatus,
        });
      }
    });

    // Sort by monthYear descending, then labourName ascending
    return list.sort((a, b) => {
      if (a.monthYear !== b.monthYear) return b.monthYear.localeCompare(a.monthYear);
      return a.labourName.localeCompare(b.labourName);
    });
  }, [floors, sqftForm, monthlyApprovals, accounts]);

  if (!isOpen) return null;

  // Handlers for User Management
  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || !newUserEmail.trim()) {
      setUserFeedback('Please enter both name and email for the new user.');
      return;
    }

    const newAccount: UserAccount = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: newUserName.trim(),
      email: newUserEmail.trim().toLowerCase(),
      phone: newUserPhone.trim() || undefined,
      role: newUserRole,
      specialization: newUserRole === 'labour' ? (newUserSpecialization || 'Gypsum Mistri') : newUserRole === 'supervisor' ? 'Site Supervisor' : 'Contractor / Owner',
      assignedTower: newUserTower,
      ratePerSqft: newUserRole === 'labour' ? newUserRate : undefined,
      status: 'pending',
      registeredAt: new Date().toISOString(),
      approvedBy: currentUser?.email || 'ssre07860@gmail.com (Owner)',
      approvedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      await onSaveUserAccount(newAccount);
      setNewUserName('');
      setNewUserEmail('');
      setNewUserPhone('');
      setUserFeedback(`User "${newAccount.name}" added successfully as ${newAccount.role.toUpperCase()}!`);
      setTimeout(() => setUserFeedback(null), 3000);
    } catch (err: any) {
      setUserFeedback(`Error creating user: ${err?.message || 'Failed to save'}`);
    }
  };

  const handleToggleUserStatus = async (account: UserAccount) => {
    const nextStatus = account.status === 'approved' ? 'rejected' : 'approved';
    const updated: UserAccount = {
      ...account,
      status: nextStatus,
      approvedBy: currentUser?.email || 'ssre07860@gmail.com (Owner)',
      approvedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await onSaveUserAccount(updated);
  };

  const handleDeleteUser = (accountId: string, name: string, role?: string) => {
    setConfirmDialogState({
      isOpen: true,
      title: `Delete User Account "${name}"?`,
      message: `Are you sure you want to delete user account "${name}"? They will be removed from permissions and can no longer log in or submit entries.`,
      confirmText: 'Delete User Account',
      itemDetails: [
        { label: 'User Name', value: name },
        { label: 'Account ID', value: accountId },
        ...(role ? [{ label: 'Assigned Role', value: role.toUpperCase() }] : []),
      ],
      onConfirm: async () => {
        setConfirmDialogState((prev) => ({ ...prev, isOpen: false }));
        await onDeleteUserAccount(accountId);
        setUserFeedback(`User "${name}" deleted.`);
        setTimeout(() => setUserFeedback(null), 2500);
      },
    });
  };

  // Handlers for Sites & Towers
  const handleSaveSiteDetails = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveHeader(siteHeaderForm);
    setSiteFeedback('Site & Company bill details saved to Cloud successfully!');
    setTimeout(() => setSiteFeedback(null), 3000);
  };

  const handleAddNewTower = () => {
    if (!newTowerName.trim()) {
      alert('Please enter Tower Name (e.g. Tower No 3)');
      return;
    }
    const cleanName = newTowerName.trim();
    if (availableTowers.some((t) => t.toLowerCase() === cleanName.toLowerCase())) {
      alert(`Tower "${cleanName}" already exists!`);
      return;
    }

    const generated = generateFloorsForNewTower({
      towerNo: cleanName,
      scName: header.scName || 'SSR ENTERPRISES',
      floorTemplate: 'custom',
      customFloorCount: newTowerFloorsCount,
      initialStatus: 'pending',
      sqftConfig,
    });
    onAddTowerFloors(generated);
    setNewTowerName('');
    setSiteFeedback(`Tower "${cleanName}" created with ${generated.length} floors!`);
    setTimeout(() => setSiteFeedback(null), 3000);
  };

  const handleDeleteTower = (towerName: string) => {
    if (availableTowers.length <= 1) {
      alert('Cannot delete the only remaining tower.');
      return;
    }
    const towerFloorIds = floors.filter((f) => f.towerNo === towerName).map((f) => f.id);
    setConfirmDialogState({
      isOpen: true,
      title: `Delete Entire Tower "${towerName}"?`,
      message: `SECURITY CHECK: Are you sure you want to delete all floors under "${towerName}"? This action cannot be undone and will permanently erase all associated floor records and measurements.`,
      confirmText: `Delete Tower & ${towerFloorIds.length} Floors`,
      itemDetails: [
        { label: 'Tower Name', value: towerName },
        { label: 'Total Floors to Erase', value: towerFloorIds.length },
      ],
      onConfirm: () => {
        setConfirmDialogState((prev) => ({ ...prev, isOpen: false }));
        onBatchDeleteFloors(towerFloorIds);
        setSiteFeedback(`Tower "${towerName}" and its ${towerFloorIds.length} floors have been deleted.`);
        setTimeout(() => setSiteFeedback(null), 3000);
      },
    });
  };

  // Master Floors Controls
  const toggleSelectFloor = (id: string) => {
    setSelectedFloorIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const selectAllFiltered = () => {
    if (selectedFloorIds.length === filteredFloorsList.length) {
      setSelectedFloorIds([]);
    } else {
      setSelectedFloorIds(filteredFloorsList.map((f) => f.id));
    }
  };

  const handleBatchDeleteSelectedFloors = () => {
    if (selectedFloorIds.length === 0) return;
    setConfirmDialogState({
      isOpen: true,
      title: `Delete ${selectedFloorIds.length} Selected Floors?`,
      message: `Are you sure you want to permanently delete all ${selectedFloorIds.length} selected floors? This will remove all their unit measurements, hold amounts, and billing records from Firebase Cloud.`,
      confirmText: `Delete ${selectedFloorIds.length} Floors`,
      itemDetails: [
        { label: 'Selected Floors', value: selectedFloorIds.length },
        { label: 'Target Tower', value: selectedTowerFilter === 'all' ? 'All Towers' : selectedTowerFilter },
      ],
      onConfirm: () => {
        setConfirmDialogState((prev) => ({ ...prev, isOpen: false }));
        onBatchDeleteFloors(selectedFloorIds);
        setBulkActionFeedback(`${selectedFloorIds.length} floors deleted successfully.`);
        setSelectedFloorIds([]);
        setTimeout(() => setBulkActionFeedback(null), 3000);
      },
    });
  };

  const handleRequestDeleteSingleFloor = (floor: FloorEntry) => {
    setConfirmDialogState({
      isOpen: true,
      title: `Delete Floor ${floor.floorNo}?`,
      message: `Are you sure you want to permanently delete Floor ${floor.floorNo} (${floor.towerNo})? All measurements and billing progress will be removed.`,
      confirmText: 'Delete Floor',
      itemDetails: [
        { label: 'Floor No', value: floor.floorNo },
        { label: 'Tower', value: floor.towerNo },
        { label: 'Release Sqft', value: `${(floor.releaseQuantity || 0).toLocaleString('en-IN')} sqft` },
        { label: 'Labour', value: floor.labourName || 'Unassigned' },
      ],
      onConfirm: () => {
        setConfirmDialogState((prev) => ({ ...prev, isOpen: false }));
        onDeleteFloor(floor.id);
        setBulkActionFeedback(`Floor ${floor.floorNo} deleted successfully.`);
        setTimeout(() => setBulkActionFeedback(null), 3000);
      },
    });
  };

  const handleBatchMarkSelectedDone = () => {
    if (selectedFloorIds.length === 0) return;
    const updatedList = floors.map((f) => {
      if (selectedFloorIds.includes(f.id)) {
        return toggleFloorCompletedStatus(f, sqftConfig, true);
      }
      return f;
    });
    onBatchSaveFloors(updatedList);
    setBulkActionFeedback(`Marked all units as Paid/Done on ${selectedFloorIds.length} floors.`);
    setSelectedFloorIds([]);
    setTimeout(() => setBulkActionFeedback(null), 3000);
  };

  const handleBatchResetSelected = () => {
    if (selectedFloorIds.length === 0) return;
    const updatedList = floors.map((f) => {
      if (selectedFloorIds.includes(f.id)) {
        return toggleFloorCompletedStatus(f, sqftConfig, false);
      }
      return f;
    });
    onBatchSaveFloors(updatedList);
    setBulkActionFeedback(`Reset units to in-progress on ${selectedFloorIds.length} floors.`);
    setSelectedFloorIds([]);
    setTimeout(() => setBulkActionFeedback(null), 3000);
  };

  // Bill Approval Handlers
  const handleSetMonthlyBillStatus = async (
    monthKey: string,
    labourName: string,
    status: 'approved' | 'rejected',
    billDetails?: {
      totalSqft: number;
      ratePerSqft: number;
      grossAmount: number;
      holdAmount: number;
      advanceDeduction: number;
      netPayable: number;
      email?: string;
    } | null
  ) => {
    const id = `approval-${monthKey}-${labourName.replace(/\s+/g, '_')}`;
    const existing = monthlyApprovals.find(
      (a) => a.monthYear === monthKey && a.labourName.toLowerCase() === labourName.toLowerCase()
    );

    const newApproval: LabourMonthlyApproval = {
      id: existing ? existing.id : id,
      monthYear: monthKey,
      labourName: labourName,
      labourEmail: billDetails?.email || existing?.labourEmail || '',
      towerNo: existing?.towerNo || 'Tower No 2',
      totalSqft: billDetails ? billDetails.totalSqft : (existing ? existing.totalSqft : 0),
      ratePerSqft: billDetails ? billDetails.ratePerSqft : (existing ? existing.ratePerSqft : 12),
      grossAmount: billDetails ? billDetails.grossAmount : (existing ? existing.grossAmount : 0),
      holdAmount: billDetails ? billDetails.holdAmount : (existing ? existing.holdAmount : 0),
      advanceDeduction: billDetails ? billDetails.advanceDeduction : (existing ? existing.advanceDeduction : 0),
      netPayable: billDetails ? billDetails.netPayable : (existing ? existing.netPayable : 0),
      status: status,
      approvalDate: status === 'approved' ? new Date().toLocaleDateString('en-IN') : undefined,
      approvedBy: `${currentUser?.email || 'ssre07860@gmail.com'} (SSR Owner)`,
      signatureStamp: status === 'approved' ? 'VERIFIED & APPROVED - SSR ENTERPRISES (OWNER)' : undefined,
      paymentStatus: status === 'approved' ? 'paid' : 'pending',
      updatedAt: new Date().toISOString(),
    };
    await onSaveMonthlyApproval(newApproval);
  };

  const handleTriggerOtpFlow = (
    monthKey: string,
    labourName: string,
    action: 'approve' | 'reject',
    billDetails?: {
      totalSqft: number;
      ratePerSqft: number;
      grossAmount: number;
      holdAmount: number;
      advanceDeduction: number;
      netPayable: number;
      email?: string;
    }
  ) => {
    const randomOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(randomOtp);
    setOtpTargetMonth(monthKey);
    setOtpTargetLabour(labourName);
    setOtpTargetBill(billDetails || null);
    setOtpTargetAction(action);
    setEnteredOtp('');
    setOtpCountdown(120); // 2 minutes
    setResendCooldown(30); // 30 seconds
    setOtpError(null);
    setOtpModalOpen(true);
    setShowSmtpAlert(true);
    
    // Auto-hide alert after 10s
    setTimeout(() => {
      setShowSmtpAlert(false);
    }, 10000);
  };

  const handleResendOtp = () => {
    if (resendCooldown > 0) return;
    const randomOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedOtp(randomOtp);
    setOtpCountdown(120); // 2 minutes
    setResendCooldown(30); // 30 seconds
    setOtpError(null);
    setEnteredOtp('');
    setShowSmtpAlert(true);
    
    setTimeout(() => {
      setShowSmtpAlert(false);
    }, 10000);
  };

  const handleVerifyAndApplyAction = async () => {
    if (otpCountdown <= 0) {
      setOtpError('OTP has expired. Please request a new OTP.');
      return;
    }
    if (enteredOtp.trim() !== generatedOtp) {
      setOtpError('Invalid OTP, please try again.');
      return;
    }
    setOtpModalOpen(false);
    setShowSmtpAlert(false);
    await handleSetMonthlyBillStatus(
      otpTargetMonth,
      otpTargetLabour,
      otpTargetAction === 'approve' ? 'approved' : 'rejected',
      otpTargetBill
    );
  };

  // Rates Save
  const handleSaveRates = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSqftConfig(sqftForm);
    setRatesFeedback('Unit Sqft dimensions & rates updated successfully!');
    setTimeout(() => setRatesFeedback(null), 3000);
  };

  const handleToggleBaseUnitStatus = (unitKey: string) => {
    const currentInactive = sqftForm.inactiveUnits || [];
    const nextInactive = currentInactive.includes(unitKey)
      ? currentInactive.filter((k) => k !== unitKey)
      : [...currentInactive, unitKey];
    setSqftForm({
      ...sqftForm,
      inactiveUnits: nextInactive,
    });
  };

  const handleAddExtraUnit = () => {
    if (!extraUnitKey.trim() || !extraUnitLabel.trim()) {
      alert("Please fill in both Unit Key and Unit Label");
      return;
    }
    const sanitizedKey = extraUnitKey.trim().toLowerCase().replace(/[^a-z0-9]/g, '');
    if (!sanitizedKey) return;

    // Check if key already exists as standard base or extra unit
    const isStandard = ['unit1', 'unit2', 'unit3', 'unit4', 'unit5', 'unit6', 'unit7', 'unit8', 'lobby', 'starc1', 'starc2'].includes(sanitizedKey);
    const isExtra = (sqftForm.extraUnits || []).some((u) => u.key === sanitizedKey);
    if (isStandard || isExtra) {
      alert(`Unit key "${sanitizedKey}" already exists!`);
      return;
    }

    const nextExtra = [...(sqftForm.extraUnits || []), { key: sanitizedKey, label: extraUnitLabel.trim(), sqft: extraUnitSqft }];
    setSqftForm({
      ...sqftForm,
      extraUnits: nextExtra,
    });
    setExtraUnitKey('');
    setExtraUnitLabel('');
    setExtraUnitSqft(0);
  };

  const handleDeleteExtraUnit = (unitKey: string) => {
    const nextExtra = (sqftForm.extraUnits || []).filter((u) => u.key !== unitKey);
    setSqftForm({
      ...sqftForm,
      extraUnits: nextExtra,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-5xl overflow-hidden max-h-[94vh] flex flex-col">
        {/* Top Header */}
        <div className="p-4 bg-gradient-to-r from-amber-950 via-slate-900 to-slate-900 text-white flex items-center justify-between border-b border-amber-500/30">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center shadow-lg font-black">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base sm:text-lg font-black tracking-tight text-white">
                  Owner Admin Control Center
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black uppercase">
                  Full Master Access
                </span>
              </div>
              <p className="text-[11px] text-slate-300 flex items-center space-x-1.5 mt-0.5">
                <span>SSR Enterprises • Prestige Lavender Field</span>
                <span>•</span>
                <span className="text-emerald-400 font-mono font-bold">
                  {currentUser?.email || 'ssre07860@gmail.com'}
                </span>
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            {/* Direct Gmail Login Trigger */}
            <button
              type="button"
              onClick={onOpenGmailModal}
              className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-300 border border-amber-500/40 text-xs font-bold transition shadow-xs"
            >
              <Mail className="w-3.5 h-3.5 text-amber-400" />
              <span>{currentUser ? 'Cloud Sync Active' : 'Login Gmail ID'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-100/80 px-4 text-xs font-bold overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('labour_gmail')}
            className={`py-3 px-3.5 border-b-2 flex items-center space-x-1.5 whitespace-nowrap transition relative ${
              activeTab === 'labour_gmail'
                ? 'border-amber-600 text-amber-900 bg-white font-black'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Labour Gmail Verification &amp; Access (लेबर अनुमति)</span>
            <span className="ml-1 px-1.5 py-0.5 bg-emerald-100 text-emerald-800 font-black text-[10px] rounded-full border border-emerald-300">
              {accounts.filter((a) => a.role === 'labour').length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('requests')}
            className={`py-3 px-3.5 border-b-2 flex items-center space-x-1.5 whitespace-nowrap transition relative ${
              activeTab === 'requests'
                ? 'border-amber-600 text-amber-900 bg-white font-black'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4 text-amber-600" />
            <span>Supervisor Requests</span>
            {pendingRequests.length > 0 && (
              <span className="absolute top-1 right-1 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
              </span>
            )}
            {pendingRequests.length > 0 && (
              <span className="ml-1 px-1.5 py-0.5 bg-amber-500 text-amber-950 font-black text-[10px] rounded-full">
                {pendingRequests.length}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('users')}
            className={`py-3 px-3.5 border-b-2 flex items-center space-x-1.5 whitespace-nowrap transition ${
              activeTab === 'users'
                ? 'border-amber-600 text-amber-900 bg-white font-black'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4 text-amber-600" />
            <span>Users &amp; Permissions ({accounts.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('sites')}
            className={`py-3 px-3.5 border-b-2 flex items-center space-x-1.5 whitespace-nowrap transition ${
              activeTab === 'sites'
                ? 'border-amber-600 text-amber-900 bg-white font-black'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Building className="w-4 h-4 text-amber-600" />
            <span>Sites &amp; Towers ({availableTowers.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('bills')}
            className={`py-3 px-3.5 border-b-2 flex items-center space-x-1.5 whitespace-nowrap transition ${
              activeTab === 'bills'
                ? 'border-amber-600 text-amber-900 bg-white font-black'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileCheck className="w-4 h-4 text-amber-600" />
            <span>Bill Approvals &amp; Payouts</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('master_floors')}
            className={`py-3 px-3.5 border-b-2 flex items-center space-x-1.5 whitespace-nowrap transition ${
              activeTab === 'master_floors'
                ? 'border-amber-600 text-amber-900 bg-white font-black'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4 text-amber-600" />
            <span>Master Floors (Edit / Batch Delete)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('rates')}
            className={`py-3 px-3.5 border-b-2 flex items-center space-x-1.5 whitespace-nowrap transition ${
              activeTab === 'rates'
                ? 'border-amber-600 text-amber-900 bg-white font-black'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <DollarSign className="w-4 h-4 text-amber-600" />
            <span>Sqft Dimensions &amp; Rates</span>
          </button>
        </div>

        {/* Tab Content Area */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 text-xs space-y-4">
          {/* TAB: LABOUR GMAIL VERIFICATION & PERMISSIONS */}
          {activeTab === 'labour_gmail' && (
            <div className="space-y-5">
              {labourGmailFeedback && (
                <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl font-bold flex items-center space-x-2 animate-in fade-in">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                  <span className="text-xs">{labourGmailFeedback}</span>
                </div>
              )}

              {/* Explainer / Rule Card */}
              <div className="p-4 bg-emerald-950 text-white rounded-xl border border-emerald-800 space-y-2">
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                  <h3 className="font-extrabold text-sm tracking-wide">
                    लेबर Gmail ID अनुमति व सत्यापन प्रणाली (Labour Access &amp; Verification)
                  </h3>
                </div>
                <p className="text-xs text-emerald-200/90 leading-relaxed">
                  <strong>नियम (Rule):</strong> लेबर जब अपनी Gmail ID से लॉग-इन करेगा, तो जब तक आप (Owner) उसकी Gmail ID यहाँ दर्ज करके <strong>Verify &amp; Approve</strong> नहीं कर देते, तब तक उसे अपना कोई भी बिल, Sqft माप या राशि नहीं दिखेगी। Owner द्वारा सत्यापन के तुरंत बाद लेबर को उसका पूरा डिजिटल बिल और भुगतान विवरण दिखाई देगा।
                </p>
              </div>

              {/* Add & Connect Labour Form */}
              <div className="p-4 sm:p-5 bg-white border border-slate-200 rounded-xl shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <div className="flex items-center space-x-2">
                    <UserPlus className="w-4 h-4 text-emerald-600" />
                    <h4 className="font-black text-sm text-slate-900">
                      ⚡ नया लेबर Gmail जोड़ें व तुरंत सत्यापित करें (Add &amp; Verify Labour)
                    </h4>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500">
                    Owner Approval Required
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      लेबर का नाम (Labour Name) *
                    </label>
                    <input
                      list="labour-names-list"
                      type="text"
                      required
                      placeholder="उदा. Adil Ahmad या Dilshad"
                      value={labourGmailName}
                      onChange={(e) => setLabourGmailName(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                    <datalist id="labour-names-list">
                      {availableLabours.map((l) => (
                        <option key={l} value={l} />
                      ))}
                    </datalist>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      लेबर की Gmail ID (Gmail ID) *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="उदा. adil@gmail.com"
                      value={labourGmailEmail}
                      onChange={(e) => setLabourGmailEmail(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      दर प्रति वर्ग फीट (Rate ₹/sqft)
                    </label>
                    <input
                      type="number"
                      value={labourGmailRate}
                      onChange={(e) => setLabourGmailRate(Number(e.target.value) || 12)}
                      placeholder="12"
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      मोबाइल नंबर (Phone - Optional)
                    </label>
                    <input
                      type="tel"
                      placeholder="10 अंक मोबाइल"
                      value={labourGmailPhone}
                      onChange={(e) => setLabourGmailPhone(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded-lg font-medium text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => handleAddAndVerifyLabourGmail(true)}
                    className="flex items-center space-x-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-lg shadow-sm transition cursor-pointer"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    <span>⚡ Verify &amp; Grant Bill Access (सत्यापित करें व बिल दिखाएं)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleAddAndVerifyLabourGmail(false)}
                    className="flex items-center space-x-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition cursor-pointer border border-slate-300"
                  >
                    <Clock className="w-4 h-4 text-slate-500" />
                    <span>Save as Pending (लंबित रखें - बिल न दिखे)</span>
                  </button>
                </div>
              </div>

              {/* Directory of Connected Labours */}
              <div className="p-4 sm:p-5 bg-white border border-slate-200 rounded-xl shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-slate-100 pb-3">
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-amber-600" />
                    <h4 className="font-black text-sm text-slate-900">
                      लेबर Gmail अनुमति सूची (Labour Gmail Permissions Directory)
                    </h4>
                    <span className="px-2 py-0.5 bg-slate-100 text-slate-800 rounded-full font-black text-[11px]">
                      {filteredLabourAccounts.length}
                    </span>
                  </div>

                  {/* Search Bar */}
                  <div className="flex items-center space-x-2 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-300 min-w-[220px]">
                    <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <input
                      type="text"
                      placeholder="नाम या Gmail खोजें..."
                      value={labourGmailSearch}
                      onChange={(e) => setLabourGmailSearch(e.target.value)}
                      className="w-full bg-transparent border-none text-xs focus:outline-hidden"
                    />
                    {labourGmailSearch && (
                      <button type="button" onClick={() => setLabourGmailSearch('')} className="text-slate-400 hover:text-slate-600">
                        <X className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>

                {filteredLabourAccounts.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 space-y-2">
                    <User className="w-8 h-8 text-slate-400 mx-auto" />
                    <p className="font-bold">कोई लेबर Gmail खाता नहीं मिला।</p>
                    <p className="text-[11px]">ऊपर दिए फॉर्म से लेबर का नाम और Gmail ID जोड़कर Verify करें।</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {filteredLabourAccounts.map((acc) => {
                      const isApproved = (acc.status === 'approved' || acc.isVerifiedByOwner === true) && acc.status !== 'rejected';
                      return (
                        <div
                          key={acc.id}
                          className={`p-4 rounded-xl border transition flex flex-col justify-between space-y-3 ${
                            isApproved
                              ? 'bg-emerald-50/40 border-emerald-200'
                              : 'bg-amber-50/40 border-amber-200'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-start space-x-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 font-black text-sm border ${
                                isApproved ? 'bg-emerald-100 text-emerald-800 border-emerald-300' : 'bg-amber-100 text-amber-800 border-amber-300'
                              }`}>
                                {acc.name.charAt(0).toUpperCase()}
                              </div>
                              <div className="min-w-0">
                                <h5 className="font-black text-slate-900 text-sm truncate flex items-center gap-1.5">
                                  <span>{acc.name}</span>
                                  {acc.mappedLabourName && acc.mappedLabourName !== acc.name && (
                                    <span className="text-[10px] bg-slate-200 text-slate-700 px-1.5 py-0.2 rounded font-normal">
                                      Map: {acc.mappedLabourName}
                                    </span>
                                  )}
                                </h5>
                                <span className="font-mono text-xs text-slate-600 block truncate font-medium">
                                  {acc.email}
                                </span>
                                <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500">
                                  <span className="font-bold text-slate-700">₹{acc.ratePerSqft || 12}/sqft</span>
                                  {acc.phone && <span>&bull; {acc.phone}</span>}
                                  {acc.specialization && <span>&bull; {acc.specialization}</span>}
                                </div>
                              </div>
                            </div>

                            {/* Status Badge */}
                            <div>
                              {isApproved ? (
                                <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-emerald-600 text-white rounded-full font-black text-[10px] shadow-xs">
                                  <CheckCircle2 className="w-3 h-3" />
                                  <span>VERIFIED (बिल दृश्य)</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center space-x-1 px-2.5 py-1 bg-amber-500 text-slate-950 rounded-full font-black text-[10px] shadow-xs">
                                  <Clock className="w-3 h-3" />
                                  <span>PENDING (बिल छुपा)</span>
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Verification Meta Details */}
                          <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px]">
                            <div className="text-slate-500 truncate max-w-[200px]">
                              {isApproved ? (
                                <span className="text-emerald-800 font-medium">
                                  ✓ Owner द्वारा सत्यापित ({acc.verifiedByEmail || acc.approvedBy || 'ssre07860@gmail.com'})
                                </span>
                              ) : (
                                <span className="text-amber-800 font-medium">
                                  ⏳ Owner का सत्यापन बाकी है
                                </span>
                              )}
                            </div>

                            <div className="flex items-center space-x-2 shrink-0">
                              <button
                                type="button"
                                onClick={() => handleToggleLabourVerification(acc)}
                                className={`px-2.5 py-1 rounded-md font-black text-[11px] transition flex items-center space-x-1 ${
                                  isApproved
                                    ? 'bg-rose-100 text-rose-700 hover:bg-rose-200 border border-rose-200'
                                    : 'bg-emerald-600 text-white hover:bg-emerald-500 shadow-xs'
                                }`}
                                title={isApproved ? 'लेबर की बिल देखने की अनुमति हटाएं' : 'लेबर को बिल देखने की अनुमति दें'}
                              >
                                {isApproved ? (
                                  <>
                                    <Lock className="w-3 h-3" />
                                    <span>Revoke (रोकें)</span>
                                  </>
                                ) : (
                                  <>
                                    <ShieldCheck className="w-3 h-3" />
                                    <span>Verify (स्वीकृत करें)</span>
                                  </>
                                )}
                              </button>

                              <button
                                type="button"
                                onClick={() => {
                                  setConfirmDialogState({
                                    isOpen: true,
                                    title: 'लेबर खाता हटाएं (Delete Account)',
                                    message: `क्या आप वाकई लेबर "${acc.name}" (${acc.email}) का खाता हटाना चाहते हैं?`,
                                    confirmText: 'हाँ, हटाएं',
                                    itemDetails: [
                                      { label: 'Name', value: acc.name },
                                      { label: 'Gmail', value: acc.email },
                                      { label: 'Rate', value: `₹${acc.ratePerSqft || 12}/sqft` },
                                    ],
                                    onConfirm: async () => {
                                      await onDeleteUserAccount(acc.id);
                                    },
                                  });
                                }}
                                className="p-1 text-slate-400 hover:text-rose-600 rounded transition"
                                title="खाता हटाएं"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 0: SUPERVISOR WORK REQUESTS */}
          {activeTab === 'requests' && (
            <div className="space-y-5">
              {bulkActionFeedback && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl font-bold flex items-center space-x-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{bulkActionFeedback}</span>
                </div>
              )}

              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 p-4 bg-amber-50 border border-amber-200 rounded-xl">
                <div>
                  <h4 className="font-extrabold text-sm text-amber-950 uppercase tracking-wide flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-amber-700" />
                    <span>Pending Work Approvals ({pendingRequests.length})</span>
                  </h4>
                  <p className="text-[11px] text-amber-800 mt-1">
                    These are work updates recorded by site supervisors. Once approved, they are added to the labour's verified record for monthly invoice generation.
                  </p>
                </div>
                {pendingRequests.length > 0 && (
                  <button
                    type="button"
                    onClick={handleApproveAllRequests}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-black rounded-lg transition shadow-sm whitespace-nowrap self-start sm:self-center"
                  >
                    Approve All {pendingRequests.length} Work Entries
                  </button>
                )}
              </div>

              {pendingRequests.length === 0 ? (
                <div className="text-center py-12 bg-slate-50 rounded-xl border border-dashed border-slate-300">
                  <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                  <h5 className="font-black text-slate-800 text-sm">All Work Entries Approved</h5>
                  <p className="text-slate-500 text-xs mt-1">There are no pending supervisor work entries awaiting approval.</p>
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-xl shadow-xs overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-slate-50 text-slate-700 uppercase text-[10px] tracking-wider font-extrabold border-b border-slate-200">
                          <th className="py-3 px-4">Tower &amp; Floor</th>
                          <th className="py-3 px-4">Unit / Flat Type</th>
                          <th className="py-3 px-4">Assigned Labour</th>
                          <th className="py-3 px-4 text-right">Dimension (Sqft)</th>
                          <th className="py-3 px-4 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-slate-700">
                        {pendingRequests.map((req, idx) => (
                          <tr key={`${req.floorId}-${req.unitKey}-${idx}`} className="hover:bg-slate-50/50 transition">
                            <td className="py-3 px-4">
                              <span className="font-black text-slate-900 block">{req.towerNo}</span>
                              <span className="text-[10px] text-slate-500 font-bold uppercase">{req.floorNo} Floor</span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="px-2 py-0.5 bg-slate-100 border border-slate-200 rounded-full font-bold text-slate-800 capitalize">
                                {req.unitLabel}
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <span className="font-black text-amber-950 block">{req.labourName}</span>
                              <span className="text-[10px] text-slate-500">Registered</span>
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                              {req.sqft.toLocaleString('en-IN')} sqft
                            </td>
                            <td className="py-3 px-4 text-right">
                              <button
                                type="button"
                                onClick={() => handleApproveRequest(req.floor, req.unitKey)}
                                className="px-3 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-extrabold rounded-lg border border-emerald-300 transition"
                              >
                                Approve Work
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 1: USERS & PERMISSIONS */}
          {activeTab === 'users' && (
            <div className="space-y-5">
              {userFeedback && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl font-bold flex items-center space-x-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{userFeedback}</span>
                </div>
              )}

              {/* Quick Action Button for Full Profile */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                <div className="space-y-1">
                  <h4 className="font-extrabold text-xs text-amber-950 uppercase tracking-wide">Register Detailed Labour/Contractor Profile</h4>
                  <p className="text-[11px] text-amber-800">Add Full Name, Contact, Permanent Address, Verified Aadhaar/PAN, and Face Photo Identification.</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedLabourForEdit(null);
                    setIsLabourModalOpen(true);
                  }}
                  className="w-full sm:w-auto px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-black rounded-lg transition shrink-0 flex items-center justify-center space-x-1.5 cursor-pointer shadow-sm"
                >
                  <PlusCircle className="w-3.5 h-3.5 text-amber-400" />
                  <span>Register Labour (with Photo)</span>
                </button>
              </div>

              {/* Add New User Form */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 shadow-xs">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-2">
                    <UserPlus className="w-4 h-4 text-amber-600" />
                    <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                      Add New User / Assign Supervisor &amp; Labour
                    </h3>
                  </div>
                  <span className="text-[11px] text-slate-500">
                    Saves directly to Firebase Cloud
                  </span>
                </div>

                <form onSubmit={handleCreateUser} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Adil Ahmad / Site Supervisor"
                      value={newUserName}
                      onChange={(e) => setNewUserName(e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Gmail Address *
                    </label>
                    <input
                      type="email"
                      required
                      placeholder="e.g. user@gmail.com"
                      value={newUserEmail}
                      onChange={(e) => setNewUserEmail(e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Role Privilege *
                    </label>
                    <select
                      value={newUserRole}
                      onChange={(e) => setNewUserRole(e.target.value as UserRole)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    >
                      <option value="supervisor">Site Supervisor (Daily Floor Entry &amp; Sign)</option>
                      <option value="labour">Labour / Mistri (View Team Bill &amp; Sqft)</option>
                      <option value="owner">Owner / Contractor (Full Admin Authority)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Phone Number (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. +91 9876543210"
                      value={newUserPhone}
                      onChange={(e) => setNewUserPhone(e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Assigned Tower
                    </label>
                    <select
                      value={newUserTower}
                      onChange={(e) => setNewUserTower(e.target.value)}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                    >
                      <option value="All Towers">All Towers</option>
                      {availableTowers.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                  </div>

                  {newUserRole === 'labour' ? (
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        Rate per Sqft (₹)
                      </label>
                      <input
                        type="number"
                        step="0.5"
                        value={newUserRate}
                        onChange={(e) => setNewUserRate(parseFloat(e.target.value) || 12)}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                      />
                    </div>
                  ) : (
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1">
                        Designation / Specialization
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Senior Site Engineer"
                        value={newUserSpecialization}
                        onChange={(e) => setNewUserSpecialization(e.target.value)}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                      />
                    </div>
                  )}

                  <div className="sm:col-span-2 md:col-span-3 flex justify-end mt-1">
                    <button
                      type="submit"
                      className="flex items-center space-x-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-slate-950 font-black rounded-lg shadow-sm transition cursor-pointer"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>Save User to Database</span>
                    </button>
                  </div>
                </form>
              </div>

              {/* Existing Users Table */}
              <div className="rounded-xl border border-slate-200 overflow-hidden">
                <div className="p-3 bg-slate-900 text-white flex items-center justify-between">
                  <h4 className="font-bold text-xs">
                    Registered Users &amp; Team Access ({accounts.length})
                  </h4>
                  <span className="text-[11px] text-slate-400">
                    Owner can activate, approve, or delete any account
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 text-slate-700 font-bold uppercase text-[10px] border-b border-slate-200">
                      <tr>
                        <th className="p-2.5">User / Name</th>
                        <th className="p-2.5">Gmail ID</th>
                        <th className="p-2.5">Role</th>
                        <th className="p-2.5">Tower / Specs</th>
                        <th className="p-2.5">Permissions</th>
                        <th className="p-2.5 text-center">Status</th>
                        <th className="p-2.5 text-center">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                       {accounts.map((acc) => (
                        <tr key={acc.id} className="hover:bg-slate-50 transition">
                          <td className="p-2.5 font-bold text-slate-900">
                            <div className="flex items-center space-x-2.5">
                              <div className="w-8 h-8 rounded-full border border-slate-200 overflow-hidden shrink-0 bg-slate-100 flex items-center justify-center">
                                {acc.photoUrl ? (
                                  <img
                                    src={acc.photoUrl}
                                    alt=""
                                    className="w-full h-full object-cover"
                                    referrerPolicy="no-referrer"
                                  />
                                ) : (
                                  <User className="w-4 h-4 text-slate-400" />
                                )}
                              </div>
                              <div>
                                <span className="font-extrabold text-slate-900 block">{acc.name}</span>
                                {acc.phone && <span className="text-[10px] text-slate-500 font-normal">{acc.phone}</span>}
                              </div>
                            </div>
                          </td>
                          <td className="p-2.5 font-mono text-slate-600 text-[11px]">
                            {acc.email}
                          </td>
                          <td className="p-2.5">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                                acc.role === 'owner'
                                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                                  : acc.role === 'supervisor'
                                  ? 'bg-sky-100 text-sky-900 border border-sky-300'
                                  : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                              }`}
                            >
                              {acc.role}
                            </span>
                          </td>
                          <td className="p-2.5 text-slate-600">
                            <div>{acc.assignedTower || 'All Towers'}</div>
                            {acc.ratePerSqft && (
                              <div className="text-[10px] text-emerald-700 font-bold">₹{acc.ratePerSqft}/sqft</div>
                            )}
                          </td>
                          <td className="p-2.5 text-[11px]">
                            {acc.role === 'owner' ? (
                              <span className="text-amber-800 font-bold">Full Admin (Edit, Delete, Approve)</span>
                            ) : acc.role === 'supervisor' ? (
                              <span className="text-sky-800 font-medium">Daily Floors, Status Toggles, Sign</span>
                            ) : (
                              <span className="text-slate-500">View Team Measurements &amp; Vouchers</span>
                            )}
                          </td>
                          <td className="p-2.5 text-center">
                            <button
                              type="button"
                              onClick={() => handleToggleUserStatus(acc)}
                              className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition cursor-pointer ${
                                acc.status === 'approved'
                                  ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                                  : 'bg-rose-100 text-rose-800 hover:bg-rose-200'
                              }`}
                            >
                              {acc.status}
                            </button>
                          </td>
                          <td className="p-2.5 text-center">
                            <div className="flex items-center justify-center space-x-1">
                              <button
                                type="button"
                                onClick={() => {
                                  setSelectedLabourForEdit(acc);
                                  setIsLabourModalOpen(true);
                                }}
                                className="p-1 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded transition"
                                title="Edit profile details, photo, & verification documents"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleDeleteUser(acc.id, acc.name, acc.role)}
                                className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                                title="Delete user profile"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SITES & TOWERS */}
          {activeTab === 'sites' && (
            <div className="space-y-5">
              {siteFeedback && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl font-bold flex items-center space-x-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{siteFeedback}</span>
                </div>
              )}

              {/* Site Details Edit Form */}
              <form onSubmit={handleSaveSiteDetails} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                    Project &amp; Sub-Contractor Master Details
                  </h3>
                  <button
                    type="submit"
                    className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-black rounded-lg text-xs shadow-xs transition"
                  >
                    Save Site Details
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Sub Contractor (Your Agency)
                    </label>
                    <input
                      type="text"
                      value={siteHeaderForm.scName}
                      onChange={(e) => setSiteHeaderForm({ ...siteHeaderForm, scName: e.target.value })}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Project Site Name
                    </label>
                    <input
                      type="text"
                      value={siteHeaderForm.projectName}
                      onChange={(e) => setSiteHeaderForm({ ...siteHeaderForm, projectName: e.target.value })}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Work Category / Type
                    </label>
                    <input
                      type="text"
                      value={siteHeaderForm.workType}
                      onChange={(e) => setSiteHeaderForm({ ...siteHeaderForm, workType: e.target.value })}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold focus:ring-2 focus:ring-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1">
                      Site Address / Location
                    </label>
                    <input
                      type="text"
                      value={siteHeaderForm.address}
                      onChange={(e) => setSiteHeaderForm({ ...siteHeaderForm, address: e.target.value })}
                      className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold focus:ring-2 focus:ring-amber-500"
                    />
                  </div>
                </div>
              </form>

              {/* Tower Management */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                      Manage Towers &amp; Floors Range
                    </h3>
                    <p className="text-[11px] text-slate-500">
                      Add extra towers or remove existing towers
                    </p>
                  </div>
                </div>

                {/* Add Tower Bar */}
                <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-200">
                  <input
                    type="text"
                    placeholder="New Tower Name (e.g. Tower No 3)"
                    value={newTowerName}
                    onChange={(e) => setNewTowerName(e.target.value)}
                    className="px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold flex-1 min-w-[180px]"
                  />
                  <div className="flex items-center space-x-1">
                    <span className="text-[11px] font-bold text-slate-600">Floors:</span>
                    <select
                      value={newTowerFloorsCount}
                      onChange={(e) => setNewTowerFloorsCount(parseInt(e.target.value, 10))}
                      className="px-2 py-1.5 border border-slate-300 rounded-lg text-xs font-bold bg-white"
                    >
                      <option value={26}>Ground to 26 Floors</option>
                      <option value={28}>Ground to 28 Floors</option>
                      <option value={32}>Ground to 32 Floors</option>
                      <option value={15}>Ground to 15 Floors</option>
                    </select>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddNewTower}
                    className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition"
                  >
                    + Add Tower
                  </button>
                </div>

                {/* Active Towers Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pt-2">
                  {availableTowers.map((tower) => {
                    const towerFloors = floors.filter((f) => f.towerNo === tower);
                    const completedFloors = towerFloors.filter(
                      (f) => Number(f.releaseQuantity || 0) >= 1000
                    ).length;

                    return (
                      <div
                        key={tower}
                        className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs flex flex-col justify-between"
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-black text-sm text-slate-900">{tower}</span>
                            <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 text-[10px] font-bold">
                              {towerFloors.length} Floors
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500">
                            Completed: <strong className="text-emerald-700">{completedFloors}</strong> / {towerFloors.length}
                          </div>
                        </div>

                        <div className="pt-2 mt-2 border-t border-slate-100 flex justify-end">
                          <button
                            type="button"
                            onClick={() => handleDeleteTower(tower)}
                            className="text-rose-600 hover:text-rose-700 font-bold text-[11px] flex items-center space-x-1"
                          >
                            <Trash2 className="w-3 h-3" />
                            <span>Delete Tower</span>
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: BILL APPROVALS & PAYOUTS */}
          {activeTab === 'bills' && (
            <div className="space-y-4">
              <div className="p-3 bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200 rounded-xl flex items-start space-x-3">
                <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-black text-amber-950 text-xs">
                    Official Owner Billing Certification &amp; Signatures
                  </h4>
                  <p className="text-[11px] text-amber-900/90 mt-0.5">
                    As Owner, you can officially certify bills for payment release, apply the digital contractor stamp, and mark retention hold releases.
                  </p>
                </div>
              </div>

              {/* Monthly Ledger Approvals */}
              <div className="rounded-xl border border-slate-200 overflow-hidden bg-white shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 text-white font-bold uppercase text-[10px]">
                    <tr>
                      <th className="p-3">Month / Period</th>
                      <th className="p-3">Labour / Team</th>
                      <th className="p-3 text-right">Certified Sqft</th>
                      <th className="p-3 text-right">Rate</th>
                      <th className="p-3 text-right">Gross (₹)</th>
                      <th className="p-3 text-right">Hold (₹)</th>
                      <th className="p-3 text-right font-black text-emerald-400">Net Payable (₹)</th>
                      <th className="p-3 text-center">Status</th>
                      <th className="p-3 text-center">Owner Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {computedLabourBills.map((bill) => {
                      const m = bill.monthYear;
                      const status = bill.status;

                      return (
                        <tr key={bill.id} className="hover:bg-slate-50 transition-colors">
                          <td className="p-3 font-bold text-slate-900">
                            {new Date(`${m}-01`).toLocaleString('default', { month: 'long', year: 'numeric' })}
                          </td>
                          <td className="p-3">
                            <span className="font-extrabold text-slate-800 block">{bill.labourName}</span>
                            <span className="text-[10px] text-slate-400 block">{bill.email || 'No email mapped'}</span>
                          </td>
                          <td className="p-3 text-right font-mono font-bold text-slate-700">
                            {bill.totalSqft.toLocaleString('en-IN')} Sqft
                          </td>
                          <td className="p-3 text-right font-mono text-slate-500">
                            ₹{bill.ratePerSqft}/Sqft
                          </td>
                          <td className="p-3 text-right font-mono font-bold text-slate-700">
                            ₹{bill.grossAmount.toLocaleString('en-IN')}
                          </td>
                          <td className="p-3 text-right font-mono text-rose-600">
                            ₹{bill.holdAmount.toLocaleString('en-IN')}
                          </td>
                          <td className="p-3 text-right font-mono font-black text-emerald-700 bg-emerald-50/40">
                            ₹{bill.netPayable.toLocaleString('en-IN')}
                          </td>
                          <td className="p-3 text-center">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase inline-block border ${
                                status === 'approved'
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                                  : status === 'rejected'
                                  ? 'bg-rose-50 text-rose-700 border-rose-200'
                                  : 'bg-amber-50 text-amber-700 border-amber-200'
                              }`}
                            >
                              {status === 'approved' ? 'Approved' : status === 'rejected' ? 'Rejected' : 'Pending'}
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {status === 'approved' ? (
                                <>
                                  <span className="text-[10px] text-emerald-700 font-bold flex items-center space-x-0.5">
                                    <Check className="w-3 h-3" />
                                    <span>Certified</span>
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => handleTriggerOtpFlow(m, bill.labourName, 'reject', bill)}
                                    className="px-1.5 py-0.5 bg-rose-50 hover:bg-rose-100 text-rose-700 hover:text-rose-800 font-bold text-[10px] rounded border border-rose-200 transition cursor-pointer"
                                    title="Revoke or reject approval status"
                                  >
                                    Revoke
                                  </button>
                                </>
                              ) : (
                                <>
                                  <button
                                    type="button"
                                    onClick={() => handleTriggerOtpFlow(m, bill.labourName, 'approve', bill)}
                                    className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-[10px] rounded-md shadow-xs transition cursor-pointer"
                                  >
                                    Approve
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleTriggerOtpFlow(m, bill.labourName, 'reject', bill)}
                                    className="px-2 py-1 bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-[10px] rounded-md shadow-xs transition cursor-pointer"
                                  >
                                    Reject
                                  </button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: MASTER FLOORS (EDIT / BATCH DELETE / CONTROLS) */}
          {activeTab === 'master_floors' && (
            <div className="space-y-3">
              {bulkActionFeedback && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl font-bold flex items-center space-x-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{bulkActionFeedback}</span>
                </div>
              )}

              {/* Search & Bulk Action Toolbar */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex flex-wrap items-center justify-between gap-2.5">
                <div className="flex items-center space-x-2 flex-1 min-w-[220px]">
                  <input
                    type="text"
                    placeholder="Search Floor No, Flats or Labour..."
                    value={floorSearch}
                    onChange={(e) => setFloorSearch(e.target.value)}
                    className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-medium"
                  />
                  <select
                    value={selectedTowerFilter}
                    onChange={(e) => setSelectedTowerFilter(e.target.value)}
                    className="px-2.5 py-1.5 border border-slate-300 rounded-lg text-xs font-bold bg-white"
                  >
                    <option value="all">All Towers</option>
                    {availableTowers.map((t) => (
                      <option key={t} value={t}>
                        {t}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Batch Action Buttons */}
                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={selectAllFiltered}
                    className="px-2.5 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-lg text-xs font-bold"
                  >
                    {selectedFloorIds.length === filteredFloorsList.length
                      ? 'Deselect All'
                      : `Select All (${filteredFloorsList.length})`}
                  </button>

                  <button
                    type="button"
                    disabled={selectedFloorIds.length === 0}
                    onClick={handleBatchMarkSelectedDone}
                    className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-white rounded-lg text-xs font-bold flex items-center space-x-1"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Mark Done ({selectedFloorIds.length})</span>
                  </button>

                  <button
                    type="button"
                    disabled={selectedFloorIds.length === 0}
                    onClick={handleBatchResetSelected}
                    className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-500 disabled:opacity-40 text-white rounded-lg text-xs font-bold flex items-center space-x-1"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Reset Units</span>
                  </button>

                  <button
                    type="button"
                    disabled={selectedFloorIds.length === 0}
                    onClick={handleBatchDeleteSelectedFloors}
                    className="px-2.5 py-1.5 bg-rose-600 hover:bg-rose-500 disabled:opacity-40 text-white rounded-lg text-xs font-bold flex items-center space-x-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Selected ({selectedFloorIds.length})</span>
                  </button>
                </div>
              </div>

              {/* Master Table */}
              <div className="rounded-xl border border-slate-200 overflow-hidden max-h-96 overflow-y-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-900 text-white font-bold uppercase text-[10px] sticky top-0 z-10">
                    <tr>
                      <th className="p-2 text-center w-8">
                        <input
                          type="checkbox"
                          checked={
                            filteredFloorsList.length > 0 &&
                            selectedFloorIds.length === filteredFloorsList.length
                          }
                          onChange={selectAllFiltered}
                          className="rounded text-amber-600"
                        />
                      </th>
                      <th className="p-2.5">Tower</th>
                      <th className="p-2.5">Floor No</th>
                      <th className="p-2.5">Flats</th>
                      <th className="p-2.5">Labour Name</th>
                      <th className="p-2.5 text-right">Release Sqft</th>
                      <th className="p-2.5 text-right">80% Paid</th>
                      <th className="p-2.5 text-center">Units Done</th>
                      <th className="p-2.5 text-center">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredFloorsList.map((floor) => {
                      const isSelected = selectedFloorIds.includes(floor.id);
                      const doneUnitsCount = [
                        floor.unit1,
                        floor.unit2,
                        floor.unit3,
                        floor.unit4,
                        floor.unit5,
                        floor.unit6,
                        floor.unit7,
                        floor.unit8,
                        floor.lobby,
                        floor.starc1,
                        floor.starc2,
                      ].filter((u) => u === 'paid').length;

                      return (
                        <tr
                          key={floor.id}
                          className={`hover:bg-slate-50 transition ${
                            isSelected ? 'bg-amber-50/70' : ''
                          }`}
                        >
                          <td className="p-2 text-center">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => toggleSelectFloor(floor.id)}
                              className="rounded text-amber-600"
                            />
                          </td>
                          <td className="p-2.5 font-semibold text-slate-700">{floor.towerNo}</td>
                          <td className="p-2.5 font-bold text-slate-900">{floor.floorNo}</td>
                          <td className="p-2.5 text-slate-600">{floor.flatsNo}</td>
                          <td className="p-2.5 text-slate-700">{floor.labourName || '—'}</td>
                          <td className="p-2.5 text-right font-mono font-bold text-slate-900">
                            {floor.releaseQuantity}
                          </td>
                          <td className="p-2.5 text-right font-mono font-bold text-emerald-700">
                            {floor.paidQuantity}
                          </td>
                          <td className="p-2.5 text-center">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                doneUnitsCount === 11
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : doneUnitsCount > 0
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-slate-100 text-slate-500'
                              }`}
                            >
                              {doneUnitsCount} / 11
                            </span>
                          </td>
                          <td className="p-2.5 text-center whitespace-nowrap">
                            <div className="flex items-center justify-center space-x-1">
                              <button
                                type="button"
                                onClick={() => onEditFloorClick(floor)}
                                className="p-1 text-sky-600 hover:bg-sky-50 rounded"
                                title="Edit full floor measurements"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => handleRequestDeleteSingleFloor(floor)}
                                className="p-1 text-rose-600 hover:bg-rose-50 rounded"
                                title="Delete floor"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 5: SQFT DIMENSIONS & RATES */}
          {activeTab === 'rates' && (
            <form onSubmit={handleSaveRates} className="space-y-4">
              {ratesFeedback && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl font-bold flex items-center space-x-2 animate-in fade-in">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{ratesFeedback}</span>
                </div>
              )}

              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                    Unit Area Dimensions (Standard Base Units)
                  </h3>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-black rounded-lg text-xs shadow-xs transition cursor-pointer"
                  >
                    Save All Dimensions
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {UNIT_CONFIG_MAP.map((info) => {
                    const isInactive = (sqftForm.inactiveUnits || []).includes(String(info.key));
                    return (
                      <div key={info.key} className={`p-3 rounded-xl border transition ${isInactive ? 'bg-slate-100/70 border-slate-200 opacity-60' : 'bg-white border-slate-200 shadow-xs'}`}>
                        <div className="flex items-center justify-between mb-2">
                          <span className={`text-xs font-black ${isInactive ? 'text-slate-400 line-through' : 'text-slate-900'}`}>
                            {info.label} Area
                          </span>
                          <button
                            type="button"
                            onClick={() => handleToggleBaseUnitStatus(String(info.key))}
                            className={`px-2 py-0.5 rounded text-[10px] font-bold cursor-pointer ${isInactive ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' : 'bg-rose-100 text-rose-800 hover:bg-rose-200'}`}
                          >
                            {isInactive ? 'Reactivate' : 'Delete'}
                          </button>
                        </div>
                        <div className="relative">
                          <input
                            type="number"
                            step="0.1"
                            disabled={isInactive}
                            value={typeof sqftForm[info.configKey as keyof UnitSqftConfig] === 'number' ? (sqftForm[info.configKey as keyof UnitSqftConfig] as number) : 0}
                            onChange={(e) =>
                              setSqftForm({
                                ...sqftForm,
                                [info.configKey]: parseFloat(e.target.value) || 0,
                              })
                            }
                            className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:ring-2 focus:ring-amber-500 disabled:bg-slate-50 disabled:text-slate-400"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Extra Custom Units Section */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
                <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                  Custom Extra Units / Areas
                </h3>

                {/* List of current custom extra units */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {(sqftForm.extraUnits || []).map((ex) => (
                    <div key={ex.key} className="p-3 bg-white rounded-xl border border-slate-200 shadow-xs">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-xs font-black text-slate-900">
                          {ex.label} ({ex.key})
                        </span>
                        <button
                          type="button"
                          onClick={() => handleDeleteExtraUnit(ex.key)}
                          className="px-2 py-0.5 bg-rose-100 text-rose-800 hover:bg-rose-200 rounded text-[10px] font-bold cursor-pointer"
                        >
                          Delete
                        </button>
                      </div>
                      <input
                        type="number"
                        step="0.1"
                        value={ex.sqft || 0}
                        onChange={(e) => {
                          const updatedVal = parseFloat(e.target.value) || 0;
                          const nextExtra = (sqftForm.extraUnits || []).map((u) =>
                            u.key === ex.key ? { ...u, sqft: updatedVal } : u
                          );
                          setSqftForm({ ...sqftForm, extraUnits: nextExtra });
                        }}
                        className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs font-bold text-slate-900 focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                  ))}

                  {/* Empty state */}
                  {(!sqftForm.extraUnits || sqftForm.extraUnits.length === 0) && (
                    <div className="col-span-full py-4 text-center text-slate-400 text-xs font-semibold">
                      No custom extra units added yet. Use the form below to add.
                    </div>
                  )}
                </div>

                {/* Add new custom extra unit form */}
                <div className="p-4 bg-amber-50/50 border border-amber-200 rounded-xl space-y-3">
                  <span className="text-[11px] font-black text-amber-900 uppercase tracking-wide block">
                    + Add New Custom Unit / Area
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Unit Key (Alphanumeric only, e.g., balcony1)
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. balcony1"
                        value={extraUnitKey}
                        onChange={(e) => setExtraUnitKey(e.target.value)}
                        className="w-full px-3 py-1.5 border border-slate-300 bg-white rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Unit Label / Display Name
                      </label>
                      <input
                        type="text"
                        placeholder="e.g. Balcony Type-1"
                        value={extraUnitLabel}
                        onChange={(e) => setExtraUnitLabel(e.target.value)}
                        className="w-full px-3 py-1.5 border border-slate-300 bg-white rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-amber-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Standard Area Sqft
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="number"
                          step="0.1"
                          placeholder="0"
                          value={extraUnitSqft}
                          onChange={(e) => setExtraUnitSqft(parseFloat(e.target.value) || 0)}
                          className="flex-1 px-3 py-1.5 border border-slate-300 bg-white rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-amber-500"
                        />
                        <button
                          type="button"
                          onClick={handleAddExtraUnit}
                          className="px-4 py-1.5 bg-amber-600 hover:bg-amber-500 text-slate-950 font-black rounded-lg transition shrink-0 cursor-pointer"
                        >
                          Add Unit
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          )}
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
          <div className="flex items-center space-x-2 text-slate-600">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="font-bold">
              SSR Enterprises • Permanent Cloud Firestore Synchronization Active
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg transition"
          >
            Close Admin Center
          </button>
        </div>
      </div>

      {isLabourModalOpen && (
        <LabourRegistrationModal
          isOpen={isLabourModalOpen}
          onClose={() => {
            setIsLabourModalOpen(false);
            setSelectedLabourForEdit(null);
          }}
          userAccess={userAccess}
          accounts={accounts}
          onSaveUserAccount={onSaveUserAccount}
          onDeleteUserAccount={onDeleteUserAccount}
          initialAccount={selectedLabourForEdit}
        />
      )}

      {/* 2FA OTP Verification Modal */}
      {otpModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden flex flex-col p-6 animate-in zoom-in-95 duration-200">
            {/* Header */}
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center shrink-0">
                <Lock className="w-5 h-5 text-amber-600" />
              </div>
              <div>
                <h3 className="text-base font-black text-slate-900">
                  Two-Factor Verification
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  {otpTargetAction === 'approve'
                    ? 'Verify your identity to approve this bill'
                    : 'Verify your identity to reject this bill'}
                </p>
              </div>
            </div>

            {/* Content info */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 mb-5 space-y-1.5 text-xs text-slate-600">
              <div className="flex justify-between">
                <span>Labour Name:</span>
                <span className="font-black text-slate-900">
                  {otpTargetLabour}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Month / Period:</span>
                <span className="font-bold text-slate-900">
                  {new Date(`${otpTargetMonth}-01`).toLocaleString('default', { month: 'long', year: 'numeric' })}
                </span>
              </div>
              <div className="flex justify-between">
                <span>Action:</span>
                <span className={`font-bold uppercase ${otpTargetAction === 'approve' ? 'text-emerald-700' : 'text-rose-700'}`}>
                  {otpTargetAction === 'approve' ? 'Approve & Release Payment' : 'Reject / Revoke Certification'}
                </span>
              </div>
              <div className="flex justify-between pt-1 border-t border-slate-200/60">
                <span>Verification Email:</span>
                <span className="font-mono font-bold text-slate-900">
                  {currentUser?.email || 'ssre07860@gmail.com'}
                </span>
              </div>
            </div>

            {/* OTP Input Form */}
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-black text-slate-700 block text-center uppercase tracking-wider">
                  Enter 6-Digit OTP Code
                </label>
                <input
                  type="text"
                  maxLength={6}
                  value={enteredOtp}
                  onChange={(e) => {
                    const val = e.target.value.replace(/\D/g, '');
                    setEnteredOtp(val);
                    if (otpError) setOtpError(null);
                  }}
                  placeholder="0 0 0 0 0 0"
                  className="w-full text-center text-2xl font-mono font-black tracking-widest py-3 border-2 border-slate-200 rounded-xl bg-slate-50 text-slate-900 focus:bg-white focus:border-amber-500 focus:ring-4 focus:ring-amber-500/15 outline-none transition"
                />
              </div>

              {/* Error state */}
              {otpError && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-800 rounded-xl font-bold text-xs flex items-center space-x-2 animate-in shake">
                  <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{otpError}</span>
                </div>
              )}

              {/* Countdown Timer */}
              <div className="text-center">
                {otpCountdown > 0 ? (
                  <p className="text-xs text-slate-600 font-medium flex items-center justify-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span>OTP expires in</span>
                    <strong className="font-mono text-slate-900">
                      {Math.floor(otpCountdown / 60)}:{String(otpCountdown % 60).padStart(2, '0')}
                    </strong>
                  </p>
                ) : (
                  <p className="text-xs text-rose-600 font-bold">
                    OTP expired, please resend.
                  </p>
                )}
              </div>

              {/* Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={handleVerifyAndApplyAction}
                  disabled={enteredOtp.length !== 6}
                  className="w-full py-3 bg-amber-600 hover:bg-amber-500 disabled:opacity-50 disabled:hover:bg-amber-600 text-slate-950 font-black text-xs rounded-xl shadow-md transition uppercase tracking-wider flex items-center justify-center space-x-2 cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-slate-950" />
                  <span>Confirm and Save Action</span>
                </button>

                <div className="flex items-center justify-between text-xs pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setOtpModalOpen(false);
                      setShowSmtpAlert(false);
                    }}
                    className="text-slate-500 hover:text-slate-800 font-bold transition"
                  >
                    Cancel
                  </button>

                  {resendCooldown > 0 ? (
                    <span className="text-slate-400 font-semibold font-mono">
                      Resend OTP in {resendCooldown}s
                    </span>
                  ) : (
                    <button
                      type="button"
                      onClick={handleResendOtp}
                      className="text-amber-700 hover:text-amber-800 font-black flex items-center space-x-1 transition cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Resend OTP</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Interactive SMTP Simulated Delivery Toast Alert */}
      {showSmtpAlert && (
        <div className="fixed top-4 right-4 z-[110] max-w-sm bg-slate-900 border-2 border-amber-500 rounded-xl shadow-2xl p-4 text-white animate-in slide-in-from-top duration-300">
          <div className="flex items-start space-x-3">
            <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center shrink-0">
              <Mail className="w-5 h-5 text-slate-950" />
            </div>
            <div className="flex-1 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black uppercase text-amber-400 tracking-wider">
                  SMTP Delivery Simulator
                </span>
                <span className="text-[9px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-bold uppercase">
                  Realtime Active
                </span>
              </div>
              <p className="text-[11px] text-slate-300 font-medium">
                Email securely routed to <span className="text-white font-bold">{currentUser?.email || 'ssre07860@gmail.com'}</span>
              </p>
              <div className="bg-slate-950 rounded-lg p-2 flex items-center justify-between border border-slate-800/80 mt-1.5">
                <div className="space-y-0.5">
                  <span className="text-[10px] text-slate-500 font-bold block uppercase tracking-wide">Secure OTP Code:</span>
                  <span className="font-mono font-black text-amber-300 text-base tracking-widest">{generatedOtp}</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setEnteredOtp(generatedOtp);
                    setOtpError(null);
                  }}
                  className="px-2 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-[10px] rounded-md transition shadow-sm uppercase tracking-wide cursor-pointer"
                >
                  Auto-fill
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Dialog for Destructive Admin Actions */}
      <ConfirmationDialog
        isOpen={confirmDialogState.isOpen}
        title={confirmDialogState.title}
        message={confirmDialogState.message}
        confirmText={confirmDialogState.confirmText}
        itemDetails={confirmDialogState.itemDetails}
        onConfirm={confirmDialogState.onConfirm}
        onCancel={() => setConfirmDialogState((prev) => ({ ...prev, isOpen: false }))}
      />
    </div>
  );
};
