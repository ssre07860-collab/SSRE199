import { FloorEntry, UnitSqftConfig, UnitStatus, LabourWorkItem, LabourBillSummary } from '../types';

export const DEFAULT_LABOUR_SUGGESTIONS = [
  'Adil Ahmad',
  'Ramesh Mistri & Team',
  'Mohan Lal Gypsum Work',
  'Sunil Yadav & Group',
  'Munna Ansari',
  'Deepak Kumar',
  'Md. Rizwan Team',
  'Shahabuddin Gypsum Finishers',
  'Munna Mistri Team',
  'Salim Contractor Group',
  'Imran Khan & Co.',
];

export const UNIT_KEYS: Array<{ key: string; label: string; configKey: keyof UnitSqftConfig }> = [
  { key: 'unit1', label: 'Unit 1', configKey: 'unit1' },
  { key: 'unit2', label: 'Unit 2', configKey: 'unit2' },
  { key: 'unit3', label: 'Unit 3', configKey: 'unit3' },
  { key: 'unit4', label: 'Unit 4', configKey: 'unit4' },
  { key: 'unit5', label: 'Unit 5', configKey: 'unit5' },
  { key: 'unit6', label: 'Unit 6', configKey: 'unit6' },
  { key: 'unit7', label: 'Unit 7', configKey: 'unit7' },
  { key: 'unit8', label: 'Unit 8', configKey: 'unit8' },
  { key: 'lobby', label: 'Lobby', configKey: 'lobby' },
  { key: 'starc1', label: 'Starc 1', configKey: 'starc1' },
  { key: 'starc2', label: 'Starc 2', configKey: 'starc2' },
];

/**
 * Extract all unique labour names from the current floor entries
 */
export const getUniqueLabourNames = (floors: FloorEntry[]): string[] => {
  const names = new Set<string>();
  floors.forEach((f) => {
    if (f.labourName && f.labourName.trim()) {
      names.add(f.labourName.trim());
    }
    if (f.unitLabours) {
      Object.values(f.unitLabours).forEach((val) => {
        if (val && val.trim()) {
          names.add(val.trim());
        }
      });
    }
  });
  return Array.from(names).sort();
};

/**
 * Get assigned labour name for a specific unit of a floor
 */
export const getUnitLabourName = (floor: FloorEntry, unitKey: string): string => {
  if (floor.unitLabours && floor.unitLabours[unitKey] && floor.unitLabours[unitKey].trim()) {
    return floor.unitLabours[unitKey].trim();
  }
  if (floor.labourName && floor.labourName.trim()) {
    return floor.labourName.trim();
  }
  return '';
};

/**
 * Check if all units on this floor have the exact same labour assigned
 */
export const isAllUnitsSameLabour = (floor: FloorEntry): { same: boolean; labour: string } => {
  const primary = (floor.labourName || '').trim();
  if (!floor.unitLabours || Object.keys(floor.unitLabours).length === 0) {
    return { same: Boolean(primary), labour: primary };
  }
  const assignedLabours = UNIT_KEYS.map((u) => getUnitLabourName(floor, u.key)).filter(Boolean);
  if (assignedLabours.length === 0) {
    return { same: Boolean(primary), labour: primary };
  }
  const first = assignedLabours[0];
  const allMatch = assignedLabours.every((l) => l === first);
  return { same: allMatch, labour: allMatch ? first : '' };
};

/**
 * Assign a single labour name to ALL units of a floor entry
 */
export const applySameLabourToAllUnits = (floor: FloorEntry, labourName: string): FloorEntry => {
  const cleanName = labourName.trim();
  const unitLabours: Record<string, string> = {};
  UNIT_KEYS.forEach((u) => {
    unitLabours[u.key] = cleanName;
  });
  return {
    ...floor,
    labourName: cleanName,
    unitLabours,
  };
};

/**
 * Extract all work items performed by labours across all floors
 */
export const getAllLabourWorkItems = (
  floors: FloorEntry[],
  sqftConfig: UnitSqftConfig
): LabourWorkItem[] => {
  const items: LabourWorkItem[] = [];
  floors.forEach((floor) => {
    UNIT_KEYS.forEach((u) => {
      const status = (floor[u.key as keyof FloorEntry] as UnitStatus) || 'none';
      const labour = getUnitLabourName(floor, u.key);
      const sqft = Number(sqftConfig[u.configKey] || 0);
      if (labour) {
          items.push({
            floorId: floor.id,
            floorNo: floor.floorNo,
            unitKey: u.key,
            unitLabel: u.label,
            status,
            sqft,
            labourName: labour,
            date: floor.date || floor.createdAt || '',
          });
      }
    });
  });
  return items;
};

/**
 * Calculate Labour Bill Summary for a specific labour (or all labours)
 */
export const calculateLabourBill = (
  floors: FloorEntry[],
  sqftConfig: UnitSqftConfig,
  targetLabourName: string,
  ratePerSqft: number = 7.0,
  holdPercentage: number = 10,
  advanceDeduction: number = 0,
  paidUnitsOnly: boolean = true
): LabourBillSummary => {
  const allItems = getAllLabourWorkItems(floors, sqftConfig);
  const matchedItems = allItems.filter((item) => {
    const nameMatch =
      targetLabourName === '__ALL__' ||
      item.labourName.toLowerCase() === targetLabourName.toLowerCase();
    if (!nameMatch) return false;
    if (paidUnitsOnly) {
      return item.status === 'paid';
    }
    return item.status === 'paid' || item.status === 'pending';
  });

  const totalSqft = matchedItems.reduce((acc, it) => acc + it.sqft, 0);
  const grossAmount = Math.round(totalSqft * ratePerSqft);
  const holdAmount = Math.round((grossAmount * holdPercentage) / 100);
  const netPayable = Math.max(0, grossAmount - holdAmount - advanceDeduction);
  const uniqueFloors = Array.from(new Set(matchedItems.map((i) => i.floorNo)));

  return {
    labourName: targetLabourName === '__ALL__' ? 'All Labourers Combined' : targetLabourName,
    totalSqft,
    ratePerSqft,
    grossAmount,
    holdPercentage,
    holdAmount,
    advanceDeduction,
    netPayable,
    items: matchedItems,
    floorsCount: uniqueFloors.length,
    floorsList: uniqueFloors,
  };
};

/**
 * Number to Indian words converter for rupee amounts
 */
export const numberToIndianWords = (num: number): string => {
  const a = [
    '',
    'One ',
    'Two ',
    'Three ',
    'Four ',
    'Five ',
    'Six ',
    'Seven ',
    'Eight ',
    'Nine ',
    'Ten ',
    'Eleven ',
    'Twelve ',
    'Thirteen ',
    'Fourteen ',
    'Fifteen ',
    'Sixteen ',
    'Seventeen ',
    'Eighteen ',
    'Nineteen ',
  ];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  const nStr = Math.round(Math.abs(num)).toString();
  if (nStr.length > 9) return `${num} Rupees`;
  const padded = ('000000000' + nStr).slice(-9);
  const match = padded.match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
  if (!match) return `${num} Rupees`;

  let str = '';
  str += Number(match[1]) !== 0 ? (a[Number(match[1])] || b[Number(match[1][0])] + ' ' + a[Number(match[1][1])]) + 'Crore ' : '';
  str += Number(match[2]) !== 0 ? (a[Number(match[2])] || b[Number(match[2][0])] + ' ' + a[Number(match[2][1])]) + 'Lakh ' : '';
  str += Number(match[3]) !== 0 ? (a[Number(match[3])] || b[Number(match[3][0])] + ' ' + a[Number(match[3][1])]) + 'Thousand ' : '';
  str += Number(match[4]) !== 0 ? (a[Number(match[4])] || b[Number(match[4][0])] + ' ' + a[Number(match[4][1])]) + 'Hundred ' : '';
  str +=
    Number(match[5]) !== 0
      ? (str !== '' ? 'and ' : '') +
        (a[Number(match[5])] || b[Number(match[5][0])] + ' ' + a[Number(match[5][1])]) +
        'Rupees Only'
      : (str ? 'Rupees Only' : 'Zero Rupees Only');

  return str.trim();
};
