import { FloorEntry, UnitSqftConfig, UnitStatus } from '../types';

export interface GenerateTowerOptions {
  towerNo: string;
  scName: string;
  floorTemplate: 'standard32' | 'custom' | 'single';
  customFloorCount?: number;
  initialStatus: 'pending' | 'paid20' | 'clone';
  cloneFromFloors?: FloorEntry[];
  sqftConfig: UnitSqftConfig;
}

/**
 * Extract clean, normalized unique tower names from existing floors and bill header
 */
export function getUniqueTowers(floors: FloorEntry[], headerTowerNo?: string): string[] {
  const set = new Set<string>();
  if (headerTowerNo && headerTowerNo.trim()) {
    set.add(headerTowerNo.trim());
  }
  floors.forEach((f) => {
    if (f.towerNo && f.towerNo.trim()) {
      set.add(f.towerNo.trim());
    }
  });
  if (set.size === 0) {
    set.add('Tower No 2');
  }
  // Sort logically (e.g. Tower 1 before Tower 2, Tower A before Tower B)
  return Array.from(set).sort((a, b) => {
    const numA = parseInt(a.replace(/\D/g, ''), 10);
    const numB = parseInt(b.replace(/\D/g, ''), 10);
    if (!isNaN(numA) && !isNaN(numB) && numA !== numB) {
      return numA - numB;
    }
    return a.localeCompare(b);
  });
}

/**
 * Deduplicate floor entries to ensure absolute React key uniqueness and data integrity.
 * Deduplicates by unique ID AND by (towerNo + floorNo) composite key.
 */
export function deduplicateFloors(floorsList: FloorEntry[]): FloorEntry[] {
  if (!floorsList || !Array.isArray(floorsList)) return [];
  const seenIds = new Set<string>();
  const seenTowerFloor = new Set<string>();
  const result: FloorEntry[] = [];
  for (const floor of floorsList) {
    if (!floor) continue;
    const cleanId = (floor.id || '').trim();
    const cleanTower = (floor.towerNo || 'tower-default').trim().toLowerCase();
    const cleanFloorNo = (floor.floorNo || '').trim().toLowerCase();
    const towerFloorKey = `${cleanTower}::${cleanFloorNo}`;

    // Skip if ID was already seen
    if (cleanId && seenIds.has(cleanId)) {
      continue;
    }
    // Skip if exact same tower and floor combination was already seen
    if (cleanFloorNo && seenTowerFloor.has(towerFloorKey)) {
      continue;
    }

    if (cleanId) seenIds.add(cleanId);
    if (cleanFloorNo) seenTowerFloor.add(towerFloorKey);
    result.push(floor);
  }
  return result;
}

/**
 * Generate floor entries for a newly added tower
 */
export function generateFloorsForNewTower(options: GenerateTowerOptions): FloorEntry[] {
  const {
    towerNo,
    scName,
    floorTemplate,
    customFloorCount = 32,
    initialStatus,
    cloneFromFloors,
    sqftConfig,
  } = options;

  const cleanTower = towerNo.trim() || 'Tower New';
  const cleanSC = scName.trim() || 'SSR ENTERPRISES';
  const timestamp = Date.now();

  // Determine floor labels to create
  let floorLabels: string[] = [];
  if (floorTemplate === 'single') {
    floorLabels = ['1'];
  } else if (floorTemplate === 'custom') {
    const count = Math.max(1, Math.min(60, customFloorCount));
    floorLabels = ['Ground', ...Array.from({ length: count }, (_, i) => `${i + 1}`)];
  } else {
    // standard 32 floors (Ground + 1 to 32)
    floorLabels = ['Ground', ...Array.from({ length: 32 }, (_, i) => `${i + 1}`)];
  }

  // Calculate standard single floor total sqft
  const totalFloorSqft =
    Number(sqftConfig.unit1 || 0) +
    Number(sqftConfig.unit2 || 0) +
    Number(sqftConfig.unit3 || 0) +
    Number(sqftConfig.unit4 || 0) +
    Number(sqftConfig.unit5 || 0) +
    Number(sqftConfig.unit6 || 0) +
    Number(sqftConfig.unit7 || 0) +
    Number(sqftConfig.unit8 || 0) +
    Number(sqftConfig.lobby || 0) +
    Number(sqftConfig.starc1 || 0) +
    Number(sqftConfig.starc2 || 0);

  const entries: FloorEntry[] = floorLabels.map((floorNo, idx) => {
    const randomEntropy = Math.random().toString(36).substring(2, 8);
    const id = `floor-${cleanTower.toLowerCase().replace(/[^a-z0-9]/g, '-')}-${floorNo.toLowerCase()}-${timestamp}-${randomEntropy}-${idx}`;

    // If cloning from existing tower floors
    if (initialStatus === 'clone' && cloneFromFloors && cloneFromFloors.length > 0) {
      const match = cloneFromFloors.find(
        (f) => f.floorNo.toLowerCase().trim() === floorNo.toLowerCase().trim()
      );
      if (match) {
        return {
          ...match,
          id,
          towerNo: cleanTower,
          scName: cleanSC,
        };
      }
    }

    // Default status setup
    const isPaid20 = initialStatus === 'paid20';
    const unitState: UnitStatus = isPaid20 ? 'paid' : 'pending';
    const releaseQty = isPaid20 ? totalFloorSqft : 0;
    const holdQty = isPaid20 ? Math.round(totalFloorSqft * 0.2) : 0;
    const paidQty = isPaid20 ? releaseQty - holdQty : 0;

    return {
      id,
      scName: cleanSC,
      towerNo: cleanTower,
      floorNo,
      flatsNo: 'Unit No 1,2,3,4,5,6,7,8',
      unit1: unitState,
      unit2: unitState,
      unit3: unitState,
      unit4: unitState,
      unit5: unitState,
      unit6: unitState,
      unit7: unitState,
      unit8: unitState,
      lobby: unitState,
      starc1: unitState,
      starc2: unitState,
      releaseQuantity: releaseQty,
      holdQuantity: holdQty,
      paidQuantity: paidQty,
      gypsumRunningFlats: isPaid20 ? 8 : 0,
      gypsumRunningLobby: isPaid20 ? 1 : 0,
      starches1WC: isPaid20 ? 1 : 0,
      starches2WC: isPaid20 ? 1 : 0,
      verifyFlats: isPaid20 ? 8 : 0,
      verifyLobby: isPaid20 ? 1 : 0,
      verifyStar1: isPaid20 ? 1 : 0,
      verifyStar2: isPaid20 ? 1 : 0,
      remarks: '',
      signature: '',
      labourName: '',
      unitLabours: {},
    };
  });

  return deduplicateFloors(entries);
}
