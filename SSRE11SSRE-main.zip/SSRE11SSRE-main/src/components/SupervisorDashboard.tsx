import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Building,
  Users,
  CheckCircle2,
  Clock,
  PlusCircle,
  Search,
  CheckSquare,
  ClipboardList,
  UserPlus,
  ArrowRight,
  Info,
  AlertCircle,
  TrendingUp,
  Sliders,
  Sparkles,
  User,
  Edit2,
  Trash2,
  Lock,
  CreditCard,
  MapPin,
  Mail,
  Phone,
} from 'lucide-react';
import { FloorEntry, UnitSqftConfig, UnitStatus, BillHeader, UserAccessInfo, UserAccount, LabourMonthlyApproval } from '../types';
import { DEFAULT_LABOUR_SUGGESTIONS, getUniqueLabourNames } from '../utils/labourBillHelper';
import { toggleFloorCompletedStatus } from '../utils/floorCalculationHelper';
import { LabourRegistrationModal } from './LabourRegistrationModal';
import { LabourProfileDetailModal } from './LabourProfileDetailModal';

// Unit config helper matching standard configuration
const UNIT_KEYS = [
  { key: 'unit1', label: 'Unit 1', configKey: 'unit1' },
  { key: 'unit2', label: 'Unit 2', configKey: 'unit2' },
  { key: 'unit3', label: 'Unit 3', configKey: 'unit3' },
  { key: 'unit4', label: 'Unit 4', configKey: 'unit4' },
  { key: 'unit5', label: 'Unit 5', configKey: 'unit5' },
  { key: 'unit6', label: 'Unit 6', configKey: 'unit6' },
  { key: 'unit7', label: 'Unit 7', configKey: 'unit7' },
  { key: 'unit8', label: 'Unit 8', configKey: 'unit8' },
  { key: 'lobby', label: 'Lobby', configKey: 'lobby' },
  { key: 'starc1', label: 'Star C1', configKey: 'starc1' },
  { key: 'starc2', label: 'Star C2', configKey: 'starc2' },
] as const;

interface SupervisorDashboardProps {
  floors: FloorEntry[];
  sqftConfig: UnitSqftConfig;
  header: BillHeader;
  userAccess: UserAccessInfo;
  onUpdateFloor: (updated: FloorEntry) => void;
  availableTowers: string[];
  accounts: UserAccount[];
  onSaveUserAccount: (account: UserAccount) => Promise<void>;
  onDeleteUserAccount?: (accountId: string) => Promise<void>;
  monthlyApprovals?: LabourMonthlyApproval[];
}

interface SupervisorLog {
  id: string;
  timestamp: string;
  towerNo: string;
  floorNo: string;
  details: string;
  labourName: string;
  date: string;
}

export const SupervisorDashboard: React.FC<SupervisorDashboardProps> = ({
  floors,
  sqftConfig,
  header,
  userAccess,
  onUpdateFloor,
  availableTowers,
  accounts,
  onSaveUserAccount,
  onDeleteUserAccount,
  monthlyApprovals = [],
}) => {
  // State for selected tower
  const [activeTower, setActiveTower] = useState<string>(availableTowers[0] || 'Tower 2');
  const [subTab, setSubTab] = useState<'daily-entry' | 'progress-grid' | 'labour-assignment'>('daily-entry');

  // Labour registration modal states
  const [isLabourModalOpen, setIsLabourModalOpen] = useState(false);
  const [selectedLabourForEdit, setSelectedLabourForEdit] = useState<UserAccount | null>(null);
  const [selectedProfileForView, setSelectedProfileForView] = useState<UserAccount | null>(null);

  // Search/Filter states
  const [floorSearch, setFloorSearch] = useState<string>('');
  const [labourSearch, setLabourSearch] = useState<string>('');

  // Form states for Daily Work Entry
  const [formFloorNo, setFormFloorNo] = useState<string>('');
  const [selectedUnits, setSelectedUnits] = useState<Record<string, boolean>>({
    unit1: false,
    unit2: false,
    unit3: false,
    unit4: false,
    unit5: false,
    unit6: false,
    unit7: false,
    unit8: false,
    lobby: false,
    starc1: false,
    starc2: false,
  });
  const [formStatus, setFormStatus] = useState<UnitStatus>('pending');
  const [formLabourName, setFormLabourName] = useState<string>('Adil Ahmad');
  const [formDate, setFormDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [formRemarks, setFormRemarks] = useState<string>('');
  const [formSignature, setFormSignature] = useState<string>(header.supervisorSignature || 'Adel');

  // Status feedback state
  const [feedback, setFeedback] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  // Local supervisor activity logs
  const [logs, setLogs] = useState<SupervisorLog[]>(() => {
    const cached = localStorage.getItem('supervisor_daily_logs_v1');
    return cached ? JSON.parse(cached) : [];
  });

  // Calculate unique labour names list for autocomplete
  const uniqueLabours = useMemo(() => {
    const registeredNames = accounts.filter(acc => acc.role === 'labour').map(acc => acc.name);
    const combined = new Set([...registeredNames, ...getUniqueLabourNames(floors), ...DEFAULT_LABOUR_SUGGESTIONS]);
    return Array.from(combined).sort();
  }, [floors, accounts]);

  // Filter floors for the active tower
  const towerFloors = useMemo(() => {
    return floors.filter((f) => (f.towerNo || 'Tower 2').toLowerCase() === activeTower.toLowerCase());
  }, [floors, activeTower]);

  // Unique floors available for dropdown based on active tower floors
  const floorOptions = useMemo(() => {
    return towerFloors.map((f) => f.floorNo).sort((a, b) => {
      const numA = parseInt(a) || 0;
      const numB = parseInt(b) || 0;
      return numA - numB;
    });
  }, [towerFloors]);

  // Handle setting a custom feedback notification
  const triggerFeedback = (message: string, type: 'success' | 'error' = 'success') => {
    setFeedback({ message, type });
    setTimeout(() => {
      setFeedback(null);
    }, 4500);
  };

  // Helper function to recalculate quantities and update a floor
  const applyRecalculatedQuantities = (floor: FloorEntry): FloorEntry => {
    const updated = { ...floor };
    const holdPercent = 20; // Default 20% hold

    // Recount flat and area running units
    let flatsCount = 0;
    ['unit1', 'unit2', 'unit3', 'unit4', 'unit5', 'unit6', 'unit7', 'unit8'].forEach((k) => {
      if (updated[k as keyof FloorEntry] === 'paid') flatsCount++;
    });

    const lobbyCount = updated.lobby === 'paid' ? 1 : 0;
    const s1Count = updated.starc1 === 'paid' ? 1 : 0;
    const s2Count = updated.starc2 === 'paid' ? 1 : 0;

    updated.gypsumRunningFlats = flatsCount;
    updated.gypsumRunningLobby = lobbyCount;
    updated.starches1WC = s1Count;
    updated.starches2WC = s2Count;
    updated.verifyFlats = flatsCount;
    updated.verifyLobby = lobbyCount;
    updated.verifyStar1 = s1Count;
    updated.verifyStar2 = s2Count;

    // Calculate Completed Sqft based on config
    let completedSqft = 0;
    UNIT_KEYS.forEach(({ key, configKey }) => {
      if (updated[key as keyof FloorEntry] === 'paid') {
        completedSqft += Number(sqftConfig[configKey] || 0);
      }
    });

    // Calculate full floor sqft based on configuration
    const fullSqft =
      (sqftConfig.unit1 || 3700) +
      (sqftConfig.unit2 || 1934) +
      (sqftConfig.unit3 || 2334) +
      (sqftConfig.unit4 || 2334) +
      (sqftConfig.unit5 || 2465) +
      (sqftConfig.unit6 || 2465) +
      (sqftConfig.unit7 || 2465) +
      (sqftConfig.unit8 || 1665) +
      (sqftConfig.lobby || 1500) +
      (sqftConfig.starc1 || 480) +
      (sqftConfig.starc2 || 480);

    const releaseQty = floor.releaseQuantity > 0 ? floor.releaseQuantity : fullSqft;

    if (flatsCount === 8 && lobbyCount === 1 && s1Count === 1 && s2Count === 1) {
      const holdQty = Math.round((releaseQty * holdPercent) / 100);
      updated.releaseQuantity = releaseQty;
      updated.holdQuantity = holdQty;
      updated.paidQuantity = releaseQty - holdQty;
    } else if (flatsCount === 0 && lobbyCount === 0 && s1Count === 0 && s2Count === 0) {
      updated.releaseQuantity = releaseQty;
      updated.holdQuantity = releaseQty;
      updated.paidQuantity = 0;
    } else {
      // Partial completion
      const calculatedPaid = Math.max(0, Math.round(completedSqft * (1 - holdPercent / 100)));
      updated.releaseQuantity = releaseQty;
      updated.paidQuantity = calculatedPaid;
      updated.holdQuantity = Math.max(0, releaseQty - calculatedPaid);
    }

    updated.updatedAt = new Date().toISOString();
    return updated;
  };

  // 1. Submit Daily Entry
  const handleDailyEntrySubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate if Labour exists in Registered Labours list (accounts with role === 'labour')
    const registeredLabours = accounts.filter(acc => acc.role === 'labour');
    const isValidLabour = registeredLabours.some(
      (acc) => acc.name.trim().toLowerCase() === formLabourName.trim().toLowerCase()
    );

    if (!formLabourName || !isValidLabour) {
      alert("Error: Please select a registered Labour name.");
      triggerFeedback("Error: Please select a registered Labour name.", "error");
      return;
    }

    if (!formFloorNo) {
      triggerFeedback('Please select a valid floor for this site.', 'error');
      return;
    }

    // Check if any unit is selected
    const selectedKeys = Object.entries(selectedUnits)
      .filter(([_, isSelected]) => isSelected)
      .map(([key]) => key);

    if (selectedKeys.length === 0) {
      triggerFeedback('Please select at least one unit/flat to update.', 'error');
      return;
    }

    // Find existing floor entry
    const existingFloor = towerFloors.find(
      (f) => f.floorNo.toLowerCase() === formFloorNo.toLowerCase()
    );

    if (!existingFloor) {
      triggerFeedback(`Floor "${formFloorNo}" not found in ${activeTower}.`, 'error');
      return;
    }

    // Prepare updated floor entry
    let updatedFloor: FloorEntry = { ...existingFloor };

    // Update selected units and set their individual labour mapping
    const nextUnitLabours = { ...(updatedFloor.unitLabours || {}) };
    selectedKeys.forEach((key) => {
      // Set status
      (updatedFloor[key as keyof FloorEntry] as any) = formStatus;
      // Assign labourer
      nextUnitLabours[key] = formLabourName;
    });

    updatedFloor.unitLabours = nextUnitLabours;
    updatedFloor.labourName = formLabourName; // Set as primary/last supervisor assignment
    updatedFloor.date = formDate;
    updatedFloor.month = formDate.slice(0, 7); // Calculate month (YYYY-MM)
    if (formRemarks) {
      updatedFloor.remarks = formRemarks;
    }
    if (formSignature) {
      updatedFloor.signature = formSignature;
    }

    // Recalculate quantities properly
    updatedFloor = applyRecalculatedQuantities(updatedFloor);

    // Save and Sync
    onUpdateFloor(updatedFloor);

    // Log the action
    const newLog: SupervisorLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      towerNo: activeTower,
      floorNo: formFloorNo,
      details: `Set status of [${selectedKeys.map((k) => k.toUpperCase()).join(', ')}] to "${formStatus.toUpperCase()}"`,
      labourName: formLabourName,
      date: formDate,
    };

    const nextLogs = [newLog, ...logs].slice(0, 50); // Keep last 50 logs
    setLogs(nextLogs);
    localStorage.setItem('supervisor_daily_logs_v1', JSON.stringify(nextLogs));

    // Clear form selection & trigger success message
    setSelectedUnits({
      unit1: false,
      unit2: false,
      unit3: false,
      unit4: false,
      unit5: false,
      unit6: false,
      unit7: false,
      unit8: false,
      lobby: false,
      starc1: false,
      starc2: false,
    });
    setFormRemarks('');

    triggerFeedback(`Daily progress updated for ${activeTower} - ${formFloorNo} Floor successfully!`);
  };

  // 2. Inline Unit Toggle in Interactive Grid
  const handleGridUnitToggle = (floorId: string, unitKey: string) => {
    const floor = floors.find((f) => f.id === floorId);
    if (!floor) return;

    const currentStatus = (floor[unitKey as keyof FloorEntry] as UnitStatus) || 'none';
    let nextStatus: UnitStatus = 'none';
    if (currentStatus === 'none') nextStatus = 'pending';
    else if (currentStatus === 'pending') nextStatus = 'paid';
    else nextStatus = 'none';

    let updated: FloorEntry = {
      ...floor,
      [unitKey]: nextStatus,
    };

    // If setting to pending/paid, ensure a default labour is set if missing
    if (nextStatus !== 'none' && !updated.labourName) {
      updated.labourName = 'Adil Ahmad';
    }

    updated = applyRecalculatedQuantities(updated);
    onUpdateFloor(updated);

    const newLog: SupervisorLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      towerNo: floor.towerNo || activeTower,
      floorNo: floor.floorNo,
      details: `Grid Toggle: [${unitKey.toUpperCase()}] changed from "${currentStatus}" to "${nextStatus}"`,
      labourName: updated.labourName || 'Unassigned',
      date: new Date().toISOString().slice(0, 10),
    };
    const nextLogs = [newLog, ...logs].slice(0, 50);
    setLogs(nextLogs);
    localStorage.setItem('supervisor_daily_logs_v1', JSON.stringify(nextLogs));

    triggerFeedback(`Updated ${floor.floorNo} Floor - ${unitKey.toUpperCase()} to ${nextStatus}.`);
  };

  // 3. Mark Entire Floor Done / Pending in Grid
  const handleFloorBatchStatus = (floorId: string, markCompleted: boolean) => {
    const floor = floors.find((f) => f.id === floorId);
    if (!floor) return;

    let updated = toggleFloorCompletedStatus(floor, sqftConfig, markCompleted);
    if (markCompleted && !updated.labourName) {
      updated.labourName = 'Adil Ahmad';
    }

    onUpdateFloor(updated);

    const newLog: SupervisorLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      towerNo: floor.towerNo || activeTower,
      floorNo: floor.floorNo,
      details: `Batch Update: Marked whole floor as ${markCompleted ? 'DONE' : 'PENDING'}`,
      labourName: updated.labourName || 'Unassigned',
      date: new Date().toISOString().slice(0, 10),
    };
    const nextLogs = [newLog, ...logs].slice(0, 50);
    setLogs(nextLogs);
    localStorage.setItem('supervisor_daily_logs_v1', JSON.stringify(nextLogs));

    triggerFeedback(`Marked ${floor.floorNo} Floor as ${markCompleted ? 'Fully Completed' : 'Pending Work'}.`);
  };

  // 4. Update Floor Labour Assignment
  const handleFloorLabourAssign = (floorId: string, name: string) => {
    const floor = floors.find((f) => f.id === floorId);
    if (!floor) return;

    let updated: FloorEntry = {
      ...floor,
      labourName: name,
    };

    // If the applySameLabour flag is implicitly supported, we can copy to all active units
    const nextUnitLabours = { ...(updated.unitLabours || {}) };
    UNIT_KEYS.forEach(({ key }) => {
      if (updated[key as keyof FloorEntry] !== 'none') {
        nextUnitLabours[key] = name;
      }
    });
    updated.unitLabours = nextUnitLabours;

    updated = applyRecalculatedQuantities(updated);
    onUpdateFloor(updated);

    const newLog: SupervisorLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toLocaleTimeString(),
      towerNo: floor.towerNo || activeTower,
      floorNo: floor.floorNo,
      details: `Reassigned primary labourer to "${name}"`,
      labourName: name,
      date: new Date().toISOString().slice(0, 10),
    };
    const nextLogs = [newLog, ...logs].slice(0, 50);
    setLogs(nextLogs);
    localStorage.setItem('supervisor_daily_logs_v1', JSON.stringify(nextLogs));

    triggerFeedback(`Assigned ${name} to ${floor.floorNo} Floor.`);
  };

  // Filtered Floors for the interactive list
  const filteredGridFloors = useMemo(() => {
    return towerFloors.filter((f) => {
      const matchFl = f.floorNo.toLowerCase().includes(floorSearch.toLowerCase()) ||
                     (f.remarks || '').toLowerCase().includes(floorSearch.toLowerCase());
      const matchLab = (f.labourName || '').toLowerCase().includes(labourSearch.toLowerCase()) ||
                       Object.values(f.unitLabours || {}).some(val => val.toLowerCase().includes(labourSearch.toLowerCase()));
      return matchFl && matchLab;
    });
  }, [towerFloors, floorSearch, labourSearch]);

  // Overall Statistics for Selected Tower
  const towerStats = useMemo(() => {
    let totalFloors = towerFloors.length;
    let completedFloors = 0;
    let inProgressFloors = 0;
    let totalUnitsCount = 0;
    let completedUnitsCount = 0;

    towerFloors.forEach((f) => {
      let fCompleted = true;
      let fStarted = false;

      UNIT_KEYS.forEach(({ key }) => {
        totalUnitsCount++;
        const status = f[key as keyof FloorEntry] as UnitStatus;
        if (status === 'paid') {
          completedUnitsCount++;
          fStarted = true;
        } else {
          fCompleted = false;
          if (status === 'pending') {
            fStarted = true;
          }
        }
      });

      if (fCompleted && totalFloors > 0) completedFloors++;
      else if (fStarted) inProgressFloors++;
    });

    const completionRate = totalUnitsCount > 0 ? Math.round((completedUnitsCount / totalUnitsCount) * 100) : 0;

    return {
      totalFloors,
      completedFloors,
      inProgressFloors,
      pendingFloors: Math.max(0, totalFloors - completedFloors - inProgressFloors),
      completionRate,
      totalUnitsCount,
      completedUnitsCount,
    };
  }, [towerFloors]);

  return (
    <div className="space-y-6 mb-12">
      {/* Top Welcome & Site Selector */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-black text-slate-900 flex items-center space-x-2">
            <Sliders className="w-5 h-5 text-sky-600" />
            <span>Supervisor Site Management Portal</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Log daily gypsum progress, assign labour details, and toggle unit status for all sites (towers).
          </p>
        </div>

        {/* Site Selector buttons */}
        <div className="flex items-center space-x-2">
          <span className="text-xs font-bold text-slate-600">Active Site:</span>
          <div className="flex bg-slate-100 p-1 rounded-lg border border-slate-200">
            {availableTowers.map((tower) => (
              <button
                key={tower}
                type="button"
                onClick={() => {
                  setActiveTower(tower);
                  setFormFloorNo('');
                }}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition ${
                  activeTower === tower
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tower}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Overview Statistics Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-2xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Site Completion</div>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-black text-slate-900">{towerStats.completionRate}%</span>
            <span className="text-xs text-emerald-600 font-bold">Progress Rate</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-1.5 mt-2.5 overflow-hidden">
            <div
              className="bg-emerald-500 h-1.5 rounded-full transition-all duration-500"
              style={{ width: `${towerStats.completionRate}%` }}
            />
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-2xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Floors Completed</div>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-black text-slate-900">
              {towerStats.completedFloors} <span className="text-xs text-slate-400 font-medium">/ {towerStats.totalFloors}</span>
            </span>
            <span className="text-xs text-emerald-600 font-semibold uppercase">Done</span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-2xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">In Progress Floors</div>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-black text-amber-600">
              {towerStats.inProgressFloors} <span className="text-xs text-slate-400 font-medium">floors</span>
            </span>
            <span className="text-xs text-amber-600 font-semibold">Active Work</span>
          </div>
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-2xs">
          <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Units Certified</div>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-2xl font-black text-slate-900">
              {towerStats.completedUnitsCount} <span className="text-xs text-slate-400 font-medium">/ {towerStats.totalUnitsCount}</span>
            </span>
            <span className="text-xs text-sky-600 font-semibold">Flats / Areas</span>
          </div>
        </div>
      </div>

      {/* Sub Navigation Tabs */}
      <div className="border-b border-slate-200 flex space-x-6 text-sm">
        <button
          type="button"
          onClick={() => setSubTab('daily-entry')}
          className={`pb-2.5 font-bold transition flex items-center space-x-1.5 border-b-2 ${
            subTab === 'daily-entry'
              ? 'border-sky-600 text-sky-700 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ClipboardList className="w-4.5 h-4.5" />
          <span>Daily Work Entry Form</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('progress-grid')}
          className={`pb-2.5 font-bold transition flex items-center space-x-1.5 border-b-2 ${
            subTab === 'progress-grid'
              ? 'border-sky-600 text-sky-700 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <CheckSquare className="w-4.5 h-4.5" />
          <span>Interactive Progress Grid</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab('labour-assignment')}
          className={`pb-2.5 font-bold transition flex items-center space-x-1.5 border-b-2 ${
            subTab === 'labour-assignment'
              ? 'border-sky-600 text-sky-700 font-black'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4.5 h-4.5" />
          <span>Labour Assignments & Details</span>
        </button>
      </div>

      {/* Notification Toast */}
      {feedback && (
        <div
          className={`fixed bottom-4 right-4 z-50 p-4 rounded-xl shadow-lg border text-xs font-semibold flex items-center space-x-2.5 max-w-sm transition-all duration-300 ${
            feedback.type === 'success'
              ? 'bg-emerald-50 text-emerald-900 border-emerald-300'
              : 'bg-rose-50 text-rose-900 border-rose-300'
          }`}
        >
          {feedback.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          )}
          <span>{feedback.message}</span>
        </div>
      )}

      {/* Dynamic Sub-Tab Views */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* TAB 1: DAILY WORK ENTRY FORM */}
        {subTab === 'daily-entry' && (
          <>
            {/* Form Column */}
            <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200">
                <h3 className="font-bold text-slate-900 flex items-center space-x-1.5">
                  <PlusCircle className="w-4 h-4 text-sky-600" />
                  <span>Log New Daily Progress Entry ({activeTower})</span>
                </h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Update work status and assign primary labourer for selected flats of a floor.
                </p>
              </div>

              <form onSubmit={handleDailyEntrySubmit} className="p-5 space-y-4">
                {/* Floor Selector */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Select Floor <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={formFloorNo}
                    onChange={(e) => setFormFloorNo(e.target.value)}
                    required
                    className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:border-sky-500 focus:ring-1 focus:ring-sky-500 outline-none"
                  >
                    <option value="">-- Choose Floor --</option>
                    {floorOptions.map((fNo) => (
                      <option key={fNo} value={fNo}>
                        {fNo} Floor
                      </option>
                    ))}
                  </select>
                </div>

                {/* Units Checkbox Matrix */}
                <div>
                  <div className="flex justify-between items-center mb-1.5">
                    <label className="block text-xs font-bold text-slate-700">
                      Flats / Areas Worked On <span className="text-rose-500">*</span>
                    </label>
                    <div className="flex space-x-2">
                      <button
                        type="button"
                        onClick={() => {
                          const allSelected: Record<string, boolean> = {};
                          UNIT_KEYS.forEach(({ key }) => { allSelected[key] = true; });
                          setSelectedUnits(allSelected);
                        }}
                        className="text-[10px] text-sky-600 hover:text-sky-800 font-extrabold"
                      >
                        Select All
                      </button>
                      <span className="text-slate-300">|</span>
                      <button
                        type="button"
                        onClick={() => {
                          const noneSelected: Record<string, boolean> = {};
                          UNIT_KEYS.forEach(({ key }) => { noneSelected[key] = false; });
                          setSelectedUnits(noneSelected);
                        }}
                        className="text-[10px] text-slate-500 hover:text-slate-700 font-semibold"
                      >
                        Clear
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5 p-3.5 bg-slate-50 rounded-xl border border-slate-200/60">
                    {UNIT_KEYS.map(({ key, label }) => (
                      <label
                        key={key}
                        className={`flex items-center space-x-2 p-2 rounded-lg border text-xs font-bold cursor-pointer transition ${
                          selectedUnits[key]
                            ? 'bg-sky-50 border-sky-300 text-sky-950 ring-1 ring-sky-300'
                            : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={selectedUnits[key] || false}
                          onChange={(e) =>
                            setSelectedUnits({ ...selectedUnits, [key]: e.target.checked })
                          }
                          className="rounded text-sky-600 focus:ring-sky-500 w-3.5 h-3.5"
                        />
                        <span>{label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                {/* Status & Labour */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Status Selection */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Work Completion Status
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setFormStatus('paid')}
                        className={`py-2 px-3 rounded-lg text-xs font-bold border transition flex items-center justify-center space-x-1.5 ${
                          formStatus === 'paid'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-900 ring-1 ring-emerald-300'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                        <span>Completed (Paid)</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setFormStatus('pending')}
                        className={`py-2 px-3 rounded-lg text-xs font-bold border transition flex items-center justify-center space-x-1.5 ${
                          formStatus === 'pending'
                            ? 'bg-amber-50 border-amber-300 text-amber-900 ring-1 ring-amber-300'
                            : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                        <span>In Progress (Pending)</span>
                      </button>
                    </div>
                  </div>

                  {/* Labour details mapping */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Assign Labour Name
                    </label>
                    <div className="relative">
                      <input
                        type="text"
                        value={formLabourName}
                        onChange={(e) => setFormLabourName(e.target.value)}
                        placeholder="Enter or select labour"
                        className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:border-sky-500 focus:outline-none"
                        list="supervisor-labours-list"
                        required
                      />
                      <datalist id="supervisor-labours-list">
                        {uniqueLabours.map((name) => (
                          <option key={name} value={name} />
                        ))}
                      </datalist>
                    </div>
                  </div>
                </div>

                {/* Date & Signature details */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Entry Date
                    </label>
                    <div className="relative">
                      <input
                        type="date"
                        value={formDate}
                        onChange={(e) => setFormDate(e.target.value)}
                        className="w-full text-xs font-medium bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:border-sky-500 focus:outline-none"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Supervisor Signature Stamp
                    </label>
                    <input
                      type="text"
                      value={formSignature}
                      onChange={(e) => setFormSignature(e.target.value)}
                      placeholder="Supervisor Signature e.g. Adel"
                      className="w-full text-xs font-semibold bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:border-sky-500 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Remarks */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Daily Progress Remarks (Optional)
                  </label>
                  <textarea
                    rows={2}
                    value={formRemarks}
                    onChange={(e) => setFormRemarks(e.target.value)}
                    placeholder="e.g. Lobby moulding started, unit flats completed"
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg p-2.5 focus:border-sky-500 focus:outline-none"
                  />
                </div>

                {/* Submit button */}
                <button
                  type="submit"
                  className="w-full py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs transition shadow-sm flex items-center justify-center space-x-1.5"
                >
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <span>Update & Save Daily Progress Entry</span>
                </button>
              </form>
            </div>

            {/* Quick Helper & Activity Logs Column */}
            <div className="lg:col-span-5 space-y-6">
              {/* Guidance Info Card */}
              <div className="bg-sky-50 rounded-xl border border-sky-200 p-4 shadow-3xs space-y-2.5 text-xs">
                <h4 className="font-black text-sky-950 flex items-center space-x-1.5 uppercase tracking-wider text-[10px]">
                  <Info className="w-4 h-4 text-sky-600 shrink-0" />
                  <span>Supervisor Guidance Rules</span>
                </h4>
                <p className="text-sky-900 leading-relaxed">
                  Supervisor modifications automatically update the **Main Bill Records** and **Labour billing ledgers**.
                </p>
                <ul className="space-y-1.5 text-sky-850 list-disc list-inside">
                  <li>
                    Status <span className="font-bold text-emerald-800">Completed (Paid)</span> represents certified, billable completed areas.
                  </li>
                  <li>
                    Status <span className="font-bold text-amber-800">In Progress (Pending)</span> is for ongoing daily activities.
                  </li>
                  <li>
                    Square footage quantities are automatically calculated inside the core Firestore schema upon form submission.
                  </li>
                </ul>
              </div>

              {/* Session Activity Logs */}
              <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
                <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <h3 className="font-bold text-slate-900 flex items-center space-x-1.5">
                    <Clock className="w-4 h-4 text-slate-500" />
                    <span>Recent Daily Work Logs</span>
                  </h3>
                  {logs.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setLogs([]);
                        localStorage.removeItem('supervisor_daily_logs_v1');
                      }}
                      className="text-[10px] text-rose-600 hover:text-rose-800 font-extrabold"
                    >
                      Clear Logs
                    </button>
                  )}
                </div>

                <div className="p-4 max-h-[340px] overflow-y-auto divide-y divide-slate-100 scrollbar-thin">
                  {logs.length === 0 ? (
                    <div className="py-8 text-center text-slate-400 text-xs">
                      No daily entries recorded in this session yet.
                    </div>
                  ) : (
                    logs.map((log) => (
                      <div key={log.id} className="py-2.5 first:pt-0 last:pb-0 text-xs">
                        <div className="flex justify-between items-center mb-1">
                          <span className="font-black text-slate-900">
                            {log.towerNo} &bull; {log.floorNo} Floor
                          </span>
                          <span className="text-[10px] text-slate-400 font-semibold">{log.timestamp}</span>
                        </div>
                        <p className="text-slate-600 text-[11px] leading-tight">
                          {log.details}
                        </p>
                        <div className="flex items-center space-x-2 mt-1 text-[10px] text-slate-500">
                          <span className="font-bold text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded">
                            Labour: {log.labourName}
                          </span>
                          <span>&bull;</span>
                          <span>Date: {log.date}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </>
        )}

        {/* TAB 2: INTERACTIVE PROGRESS GRID */}
        {subTab === 'progress-grid' && (
          <div className="lg:col-span-12 space-y-4">
            {/* Grid Filters */}
            <div className="bg-white rounded-xl border border-slate-200 p-3 shadow-xs flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-3">
                {/* Search Floor */}
                <div className="relative w-48">
                  <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={floorSearch}
                    onChange={(e) => setFloorSearch(e.target.value)}
                    placeholder="Search Floor or Remarks..."
                    className="w-full text-xs font-semibold pl-8 pr-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                  />
                </div>

                {/* Search Labour */}
                <div className="relative w-48">
                  <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
                  <input
                    type="text"
                    value={labourSearch}
                    onChange={(e) => setLabourSearch(e.target.value)}
                    placeholder="Search Labour Assigned..."
                    className="w-full text-xs font-semibold pl-8 pr-2.5 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:outline-none"
                  />
                </div>
              </div>

              <div className="text-[11px] text-slate-500 font-medium">
                Showing <span className="font-extrabold text-slate-800">{filteredGridFloors.length}</span> of {towerFloors.length} floor records.
              </div>
            </div>

            {/* Grid Main Layout */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-900 text-white font-extrabold uppercase tracking-wider text-[10px] divide-x divide-slate-800">
                      <th className="p-3">Floor No</th>
                      {UNIT_KEYS.map((uk) => (
                        <th key={uk.key} className="p-3 text-center min-w-[70px]">
                          {uk.label}
                        </th>
                      ))}
                      <th className="p-3 text-center min-w-[150px]">Supervisor Batch Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {filteredGridFloors.length === 0 ? (
                      <tr>
                        <td colSpan={13} className="p-8 text-center text-slate-400 text-xs font-medium">
                          No matching floor records found for this tower.
                        </td>
                      </tr>
                    ) : (
                      filteredGridFloors.map((floor) => (
                        <tr key={floor.id} className="hover:bg-slate-50 divide-x divide-slate-100 transition">
                          <td className="p-3 font-black text-slate-900 bg-slate-50/50">
                            {floor.floorNo} Floor
                            <div className="text-[9px] text-slate-400 font-normal mt-0.5 max-w-[80px] truncate">
                              {floor.labourName || 'No primary'}
                            </div>
                          </td>

                          {UNIT_KEYS.map((uk) => {
                            const status = floor[uk.key as keyof FloorEntry] as UnitStatus || 'none';
                            const specLabour = floor.unitLabours?.[uk.key] || floor.labourName || '';

                            return (
                              <td key={uk.key} className="p-1.5 text-center align-middle">
                                <button
                                  type="button"
                                  onClick={() => handleGridUnitToggle(floor.id, uk.key)}
                                  className={`w-full py-2.5 rounded-lg border text-[10px] font-extrabold flex flex-col items-center justify-center space-y-0.5 transition focus:outline-none select-none ${
                                    status === 'paid'
                                      ? 'bg-emerald-500 text-white border-emerald-600 shadow-xs'
                                      : status === 'pending'
                                      ? 'bg-amber-100 text-amber-950 border-amber-300'
                                      : 'bg-white text-slate-400 border-slate-200 hover:bg-slate-100'
                                  }`}
                                  title={`Click to toggle. Current: ${status.toUpperCase()} | Labour: ${specLabour || 'None'}`}
                                >
                                  <span>{status === 'paid' ? 'Paid' : status === 'pending' ? 'Pending' : '--'}</span>
                                  {specLabour && (
                                    <span className={`text-[8px] font-medium block truncate max-w-[55px] ${
                                      status === 'paid' ? 'text-emerald-100' : 'text-slate-500'
                                    }`}>
                                      {specLabour.split(' ')[0]}
                                    </span>
                                  )}
                                </button>
                              </td>
                            );
                          })}

                          <td className="p-3 text-center align-middle bg-slate-50/30">
                            <div className="flex items-center justify-center space-x-1.5">
                              <button
                                type="button"
                                onClick={() => handleFloorBatchStatus(floor.id, true)}
                                className="px-2.5 py-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-extrabold rounded-lg text-[10px] border border-emerald-300 transition"
                              >
                                Mark Done
                              </button>
                              <button
                                type="button"
                                onClick={() => handleFloorBatchStatus(floor.id, false)}
                                className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg text-[10px] border border-slate-200 transition"
                              >
                                Reset Pending
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: LABOUR ASSIGNMENTS & DETAILS */}
        {subTab === 'labour-assignment' && (
          <div className="lg:col-span-12 space-y-6">
            
            {/* LABOUR PROFILES GRID DASHBOARD */}
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 bg-slate-900 text-white p-4 rounded-xl shadow-xs">
                <div>
                  <h3 className="text-sm font-black uppercase tracking-wider text-amber-400 flex items-center space-x-2">
                    <Users className="w-4.5 h-4.5 text-amber-400" />
                    <span>👷 Registered Labour &amp; Team Profiles</span>
                  </h3>
                  <p className="text-[11px] text-slate-300 mt-0.5">Manage permanent address details, verified Aadhaar/PAN identity cards, and mobile numbers.</p>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedLabourForEdit(null);
                    setIsLabourModalOpen(true);
                  }}
                  className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs transition flex items-center justify-center space-x-1.5 shrink-0 shadow-xs cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>+ Register New Labourer</span>
                </button>
              </div>

              {/* Grid Layout of Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {accounts.filter(acc => acc.role === 'labour').length === 0 ? (
                  <div className="col-span-full bg-slate-50 border border-slate-200 rounded-xl p-8 text-center text-slate-400 text-xs font-semibold">
                    No verified labour profiles registered in the database yet. Click the button above to add a profile with photo.
                  </div>
                ) : (
                  accounts.filter(acc => acc.role === 'labour').map(acc => (
                    <div key={acc.id} className="bg-white rounded-xl border border-slate-200 shadow-2xs hover:shadow-xs transition overflow-hidden flex flex-col justify-between">
                      {/* Top Header Card Info */}
                      <div className="p-4 space-y-3">
                        <div className="flex items-start space-x-3">
                          {/* Face Avatar */}
                          <div className="w-14 h-14 rounded-full border border-slate-200 overflow-hidden shrink-0 bg-slate-50 flex items-center justify-center shadow-2xs">
                            {acc.photoUrl ? (
                              <img src={acc.photoUrl} alt={acc.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                            ) : (
                              <User className="w-6 h-6 text-slate-400" />
                            )}
                          </div>
                          <div className="space-y-0.5 min-w-0 flex-1">
                            <div className="flex items-center space-x-1.5">
                              <span className="font-extrabold text-slate-900 truncate text-xs">{acc.name}</span>
                              <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase shrink-0 ${
                                acc.status === 'approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                              }`}>
                                {acc.status}
                              </span>
                            </div>
                            <span className="text-[10px] text-slate-400 font-bold block uppercase">{acc.specialization || 'Gypsum Mistri'}</span>
                            <span className="text-[10px] text-emerald-700 font-extrabold block">Rate: ₹{acc.ratePerSqft || 12}/sqft</span>
                          </div>
                        </div>

                        {/* Contact details */}
                        <div className="space-y-1.5 pt-2 border-t border-slate-100 text-[11px] text-slate-600">
                          {acc.phone && (
                            <div className="flex items-center space-x-2">
                              <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <a href={`tel:${acc.phone}`} className="font-semibold text-slate-700 hover:underline hover:text-sky-600">
                                {acc.phone}
                              </a>
                            </div>
                          )}
                          {acc.email && (
                            <div className="flex items-center space-x-2">
                              <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                              <span className="font-mono text-slate-500 truncate">{acc.email}</span>
                            </div>
                          )}
                          {acc.address && (
                            <div className="flex items-start space-x-2">
                              <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                              <span className="text-slate-500 line-clamp-2" title={acc.address}>{acc.address}</span>
                            </div>
                          )}
                        </div>

                        {/* ID Verification Details */}
                        <div className="bg-slate-50 p-2 rounded-lg border border-slate-150 space-y-1 text-[10px]">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-500 font-bold">Aadhaar (आधार):</span>
                            {acc.aadhaarNo ? (
                              <span className="font-mono font-black text-slate-800 tracking-wider">
                                xxxx-xxxx-{acc.aadhaarNo.slice(-4)} ✅
                              </span>
                            ) : (
                              <span className="text-rose-500 font-bold">Not Provided ❌</span>
                            )}
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-slate-500 font-bold">PAN Card:</span>
                            {acc.panNo ? (
                              <span className="font-mono font-black text-slate-800 uppercase">
                                {acc.panNo} ✅
                              </span>
                            ) : (
                              <span className="text-slate-400">Not Provided</span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Actions in Footer of Card */}
                      <div className="px-4 py-2 bg-slate-50 border-t border-slate-100 flex justify-between items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedProfileForView(acc);
                          }}
                          className="px-2.5 py-1 bg-sky-50 border border-sky-200 text-sky-900 rounded-md hover:bg-sky-100 font-bold transition flex items-center space-x-1 cursor-pointer text-[10px]"
                        >
                          <Users className="w-3 h-3 text-sky-600 shrink-0" />
                          <span>View Profile</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setSelectedLabourForEdit(acc);
                            setIsLabourModalOpen(true);
                          }}
                          className="px-2.5 py-1 bg-white border border-slate-300 rounded-md hover:bg-slate-100 font-bold transition flex items-center space-x-1 text-slate-700 cursor-pointer text-[10px]"
                        >
                          <Edit2 className="w-3 h-3 text-amber-600" />
                          <span>Edit Profile</span>
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="bg-sky-50 rounded-xl border border-sky-200 p-4 shadow-3xs flex items-center space-x-3 text-xs text-sky-950">
              <Users className="w-5 h-5 text-sky-600 shrink-0" />
              <div>
                <span className="font-extrabold uppercase text-[10px] tracking-wider block mb-0.5">Quick Guide</span>
                Assigning a primary labourer to a floor updates that contractor's billing entries automatically. You can choose from existing suggestions or input custom names in the dropdown box inside any row.
              </div>
            </div>

            {/* Labour Assignment Grid */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
              <div className="p-4 bg-slate-50 border-b border-slate-200">
                <h3 className="font-bold text-slate-900">Active Labour Allocations per Floor</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">
                  Update primary contractors and review specific flat distributions for {activeTower}.
                </p>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs divide-y divide-slate-200">
                  <thead>
                    <tr className="bg-slate-100 text-slate-800 font-extrabold uppercase tracking-wider text-[10px]">
                      <th className="p-3">Floor No</th>
                      <th className="p-3">Primary Contractor / Labour</th>
                      <th className="p-3">Specific Flat Assignments</th>
                      <th className="p-3 text-center">Quantities (Sqft)</th>
                      <th className="p-3 text-center">Re-assign Primary Contractor</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {towerFloors.map((floor) => {
                      const activeUnitsWithLabours = UNIT_KEYS.filter((uk) => {
                        const status = floor[uk.key as keyof FloorEntry] as UnitStatus;
                        return status !== 'none';
                      });

                      return (
                        <tr key={floor.id} className="hover:bg-slate-50/50 transition">
                          <td className="p-3 font-black text-slate-900">{floor.floorNo} Floor</td>
                          <td className="p-3">
                            <span className="px-2.5 py-1 bg-slate-100 border border-slate-200 rounded-lg font-bold text-slate-800 text-[11px]">
                              {floor.labourName || 'No Contractor Assigned'}
                            </span>
                          </td>
                          <td className="p-3 max-w-sm">
                            {activeUnitsWithLabours.length === 0 ? (
                              <span className="text-slate-400 italic">No flats started yet</span>
                            ) : (
                              <div className="flex flex-wrap gap-1">
                                {activeUnitsWithLabours.map((uk) => {
                                  const specificL = floor.unitLabours?.[uk.key] || floor.labourName || 'Adil';
                                  return (
                                    <span
                                      key={uk.key}
                                      className="px-1.5 py-0.5 bg-sky-50 text-sky-950 border border-sky-100 rounded text-[10px]"
                                      title={`${uk.label}: Assigned to ${specificL}`}
                                    >
                                      {uk.label}: <strong className="font-extrabold">{specificL.split(' ')[0]}</strong>
                                    </span>
                                  );
                                })}
                              </div>
                            )}
                          </td>
                          <td className="p-3 text-center font-bold text-slate-700">
                            {floor.paidQuantity.toLocaleString('en-IN')} sqft paid &bull; {floor.holdQuantity.toLocaleString('en-IN')} sqft hold
                          </td>
                          <td className="p-3 text-center align-middle">
                            <select
                              value={floor.labourName || ''}
                              onChange={(e) => handleFloorLabourAssign(floor.id, e.target.value)}
                              className="bg-slate-50 border border-slate-200 rounded-lg p-1.5 font-bold text-xs focus:outline-none"
                            >
                              <option value="">-- Choose Contractor --</option>
                              {uniqueLabours.map((name) => (
                                <option key={name} value={name}>
                                  {name}
                                </option>
                              ))}
                            </select>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>

      {isLabourModalOpen && (
        <LabourRegistrationModal
          isOpen={isLabourModalOpen}
          onClose={() => {
            setIsLabourModalOpen(false);
            setSelectedLabourForEdit(null);
          }}
          userAccess={userAccess}
          accounts={accounts}
          onSaveUserAccount={onSaveUserAccount}
          onDeleteUserAccount={onDeleteUserAccount}
          initialAccount={selectedLabourForEdit}
        />
      )}

      {selectedProfileForView && (
        <LabourProfileDetailModal
          isOpen={!!selectedProfileForView}
          onClose={() => setSelectedProfileForView(null)}
          account={selectedProfileForView}
          userAccess={userAccess}
          monthlyApprovals={monthlyApprovals}
          onSaveUserAccount={onSaveUserAccount}
          onEditProfile={(account) => {
            setSelectedProfileForView(null);
            setSelectedLabourForEdit(account);
            setIsLabourModalOpen(true);
          }}
        />
      )}
    </div>
  );
};
