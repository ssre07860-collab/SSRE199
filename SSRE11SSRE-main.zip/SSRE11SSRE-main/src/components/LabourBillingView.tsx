import React, { useState, useMemo, useEffect, useRef } from 'react';
import {
  Users,
  Calculator,
  IndianRupee,
  FileDown,
  Printer,
  ShieldCheck,
  CheckCircle,
  Building,
  UserCheck,
  Percent,
  User,
  Mail,
  Phone,
  CreditCard,
  Lock,
  Files,
  Trash2,
  Edit,
  Plus,
  Search,
  Calendar,
  Save,
  Check,
  AlertCircle,
  Sparkles,
  SlidersHorizontal,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import {
  FloorEntry,
  UnitSqftConfig,
  BillHeader,
  UserAccessInfo,
  UserAccount,
  LabourMonthlyApproval,
  LabourDigitalBillRecord,
  LabourBillItem,
} from '../types';
import {
  getUniqueLabourNames,
  calculateLabourBill,
  DEFAULT_LABOUR_SUGGESTIONS,
} from '../utils/labourBillHelper';
import { generateInstantPDF } from '../utils/pdfGenerator';
import { LabourProfileDetailModal } from './LabourProfileDetailModal';
import { DigitalLabourBillSheet } from './DigitalLabourBillSheet';
import { EditLabourBillModal } from './EditLabourBillModal';
import { ConfirmationDialog } from './ConfirmationDialog';
import {
  loadDigitalBillRecords,
  saveDigitalBillRecord,
  deleteDigitalBillRecord,
  buildDigitalBillFromFloors,
  calculateDigitalBillTotals,
} from '../utils/digitalLabourBillHelper';

interface LabourBillingViewProps {
  floors: FloorEntry[];
  sqftConfig: UnitSqftConfig;
  header: BillHeader;
  userAccess: UserAccessInfo;
  accounts?: UserAccount[];
  monthlyApprovals?: LabourMonthlyApproval[];
  onSaveUserAccount?: (account: UserAccount) => Promise<void>;
}

export const LabourBillingView: React.FC<LabourBillingViewProps> = ({
  floors,
  sqftConfig,
  header,
  userAccess,
  accounts = [],
  monthlyApprovals = [],
  onSaveUserAccount,
}) => {
  // Primary Dashboard Tab
  const [activeTab, setActiveTab] = useState<'digital-bill' | 'all-records' | 'rates-ledger'>('digital-bill');

  // Digital Bill Records state
  const [digitalBills, setDigitalBills] = useState<LabourDigitalBillRecord[]>([]);
  const [isLoadingBills, setIsLoadingBills] = useState<boolean>(true);
  const [saveSuccessMsg, setSaveSuccessMsg] = useState<string | null>(null);

  // Available Labour list
  const availableLabours = useMemo(() => {
    if (userAccess.isLabour && userAccess.labourName) {
      return [userAccess.labourName];
    }
    const list = getUniqueLabourNames(floors);
    DEFAULT_LABOUR_SUGGESTIONS.forEach((s) => {
      if (!list.includes(s)) list.push(s);
    });
    // Also include labours from existing bills
    digitalBills.forEach((b) => {
      if (!list.includes(b.labourName)) list.push(b.labourName);
    });
    return list;
  }, [floors, userAccess.isLabour, userAccess.labourName, digitalBills]);

  // Selected Labour for Digital Bill
  const [selectedLabour, setSelectedLabour] = useState<string>(
    userAccess.isLabour && userAccess.labourName ? userAccess.labourName : 'SSR BILL'
  );

  // Active working digital bill in editor / studio
  const [currentBill, setCurrentBill] = useState<LabourDigitalBillRecord | null>(null);

  // Bill customizer open/collapse
  const [showCustomizer, setShowCustomizer] = useState<boolean>(false);

  // Modals state
  const [editingBill, setEditingBill] = useState<LabourDigitalBillRecord | null>(null);
  const [billToDelete, setBillToDelete] = useState<LabourDigitalBillRecord | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState<boolean>(false);

  // PDF Generation States
  const [isGeneratingPdf, setIsGeneratingPdf] = useState<boolean>(false);
  const [isGeneratingBatchPdf, setIsGeneratingBatchPdf] = useState<boolean>(false);

  // Filter states for "All Labour Monthly Bill Records"
  const [recordsSearch, setRecordsSearch] = useState<string>('');
  const [monthFilter, setMonthFilter] = useState<string>('all');

  // Rates ledger state
  const [ratePerSqft, setRatePerSqft] = useState<number>(header.defaultLabourRate || 7.0);
  const [holdPercentage, setHoldPercentage] = useState<number>(10);
  const [advanceDeduction, setAdvanceDeduction] = useState<number>(0);
  const [dailyExpenses, setDailyExpenses] = useState<number>(0);
  const [paidOnlyFilter, setPaidOnlyFilter] = useState<boolean>(true);

  // Load digital bills from Firestore / local storage on mount
  useEffect(() => {
    let isMounted = true;
    const fetchBills = async () => {
      try {
        setIsLoadingBills(true);
        const bills = await loadDigitalBillRecords();
        if (isMounted) {
          const filteredBills = userAccess.isLabour
            ? bills.filter((b) => b.status === 'approved')
            : bills;

          setDigitalBills(filteredBills);
          // Set initial bill
          if (filteredBills.length > 0) {
            const initial = userAccess.isLabour && userAccess.labourName
              ? filteredBills.find((b) => b.labourName.toLowerCase() === userAccess.labourName!.toLowerCase()) || filteredBills[0]
              : filteredBills[0];
            setCurrentBill(initial);
            setSelectedLabour(initial.labourName);
          } else {
            setCurrentBill(null);
          }
        }
      } catch (err) {
        console.error('Failed to load digital bills:', err);
      } finally {
        if (isMounted) setIsLoadingBills(false);
      }
    };
    fetchBills();
    return () => {
      isMounted = false;
    };
  }, [userAccess.isLabour, userAccess.labourName]);

  // When selected labour changes in digital bill tab
  const handleSelectLabour = (labourName: string) => {
    setSelectedLabour(labourName);
    // Find existing saved bill for this labour
    const existing = digitalBills.find(
      (b) => b.labourName.toLowerCase() === labourName.toLowerCase()
    );
    if (existing) {
      setCurrentBill(existing);
    } else if (!userAccess.isLabour) {
      // Build from verified floors - ONLY ALLOWED FOR OWNER/SUPERVISOR
      const generated = buildDigitalBillFromFloors(labourName, floors, sqftConfig, header, {
        ratePerSqft: ratePerSqft,
      });
      setCurrentBill(generated);
    } else {
      // Labourer cannot create new bills
      setCurrentBill(null);
    }
  };

  // Quick field changes inside current working bill
  const handleCurrentBillFieldChange = (field: keyof LabourDigitalBillRecord, value: any) => {
    if (!currentBill) return;
    const updated = { ...currentBill, [field]: value };
    if (field === 'totalKharcha' || field === 'items') {
      const totals = calculateDigitalBillTotals(updated.items, Number(updated.totalKharcha) || 0);
      updated.totalWorkAmount = totals.totalWorkAmount;
      updated.netBalancePayable = totals.netBalancePayable;
      updated.amountInWords = totals.amountInWords;
    }
    setCurrentBill(updated);
  };

  // Quick item changes in current working bill
  const handleCurrentBillItemChange = (index: number, field: keyof LabourBillItem, value: any) => {
    if (!currentBill) return;
    const newItems = [...currentBill.items];
    const item = { ...newItems[index], [field]: value };
    if (field === 'quantity' || field === 'rate') {
      const q = field === 'quantity' ? Number(value) || 0 : Number(item.quantity) || 0;
      const r = field === 'rate' ? Number(value) || 0 : Number(item.rate) || 0;
      item.total = Math.round(q * r);
    }
    newItems[index] = item;
    const totals = calculateDigitalBillTotals(newItems, Number(currentBill.totalKharcha) || 0);
    setCurrentBill({
      ...currentBill,
      items: newItems,
      totalWorkAmount: totals.totalWorkAmount,
      netBalancePayable: totals.netBalancePayable,
      amountInWords: totals.amountInWords,
    });
  };

  const handleAddCurrentBillItem = () => {
    if (!currentBill) return;
    const newItem: LabourBillItem = {
      id: `item-${Date.now()}`,
      towerOrFloor: currentBill.items[0]?.towerOrFloor || 'T=1/PLF',
      description: 'New Floor Work Item',
      quantity: 1,
      rate: 120,
      total: 120,
    };
    const newItems = [...currentBill.items, newItem];
    const totals = calculateDigitalBillTotals(newItems, Number(currentBill.totalKharcha) || 0);
    setCurrentBill({
      ...currentBill,
      items: newItems,
      totalWorkAmount: totals.totalWorkAmount,
      netBalancePayable: totals.netBalancePayable,
      amountInWords: totals.amountInWords,
    });
  };

  const handleDeleteCurrentBillItem = (index: number) => {
    if (!currentBill) return;
    const newItems = currentBill.items.filter((_, i) => i !== index);
    const totals = calculateDigitalBillTotals(newItems, Number(currentBill.totalKharcha) || 0);
    setCurrentBill({
      ...currentBill,
      items: newItems,
      totalWorkAmount: totals.totalWorkAmount,
      netBalancePayable: totals.netBalancePayable,
      amountInWords: totals.amountInWords,
    });
  };

  // Save current bill to Cloud Firestore & LocalStorage
  const handleSaveCurrentBill = async () => {
    if (!currentBill) return;
    try {
      await saveDigitalBillRecord(currentBill);
      const updated = await loadDigitalBillRecords();
      setDigitalBills(updated);
      setSaveSuccessMsg(`Bill #${currentBill.billNo} saved successfully!`);
      setTimeout(() => setSaveSuccessMsg(null), 3500);
    } catch (err: any) {
      alert(`Could not save bill: ${err?.message || err}`);
    }
  };

  // Generate Single Labour Digital Bill PDF
  const handleDownloadSinglePDF = async () => {
    if (!currentBill) return;
    setIsGeneratingPdf(true);
    try {
      const filename = `Digital_Bill_${currentBill.billNo}_${currentBill.labourName.replace(/\s+/g, '_')}.pdf`;
      await generateInstantPDF('active-digital-bill-sheet', filename, 'portrait', {
        fitToPage: true,
        margin: 6,
        scale: 2.5,
      });
    } catch (err) {
      console.error('PDF export failed:', err);
      window.print();
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // Generate Batch PDF for All Labours Monthly
  const handleDownloadBatchPDF = async () => {
    if (digitalBills.length === 0) {
      alert('No monthly labour bills found to generate batch PDF.');
      return;
    }
    setIsGeneratingBatchPdf(true);
    try {
      const elementIds = digitalBills.map((b) => `batch-bill-${b.id}`);
      await generateInstantPDF(elementIds, 'All_Labour_Monthly_Digital_Bills.pdf', 'portrait', {
        fitToPage: true,
        margin: 6,
        scale: 2.5,
      });
    } catch (err) {
      console.error('Batch PDF generation failed:', err);
      window.print();
    } finally {
      setIsGeneratingBatchPdf(false);
    }
  };

  // Handle Owner Saving an Edited Bill Record
  const handleSaveEditedBill = async (updatedBill: LabourDigitalBillRecord) => {
    await saveDigitalBillRecord(updatedBill);
    const updated = await loadDigitalBillRecords();
    setDigitalBills(updated);
    if (currentBill && currentBill.id === updatedBill.id) {
      setCurrentBill(updatedBill);
    }
  };

  // Handle Owner Deleting a Bill Record
  const handleConfirmDeleteBill = async () => {
    if (!billToDelete) return;
    try {
      await deleteDigitalBillRecord(billToDelete.id);
      const updated = await loadDigitalBillRecords();
      setDigitalBills(updated);
      if (currentBill && currentBill.id === billToDelete.id) {
        setCurrentBill(updated[0] || null);
      }
      setBillToDelete(null);
    } catch (err: any) {
      alert(`Delete failed: ${err?.message || err}`);
    }
  };

  // Filtered bill records for "All Labour Monthly Bill Records" table
  const filteredRecords = useMemo(() => {
    return digitalBills.filter((b) => {
      const matchesSearch =
        recordsSearch === '' ||
        b.billNo.toLowerCase().includes(recordsSearch.toLowerCase()) ||
        b.labourName.toLowerCase().includes(recordsSearch.toLowerCase()) ||
        (b.labourAadhaar && b.labourAadhaar.includes(recordsSearch));
      const matchesMonth = monthFilter === 'all' || b.monthYear === monthFilter;
      return matchesSearch && matchesMonth;
    });
  }, [digitalBills, recordsSearch, monthFilter]);

  // Aggregate stats across all records
  const allRecordsStats = useMemo(() => {
    let totalGross = 0;
    let totalKharcha = 0;
    let totalNet = 0;
    digitalBills.forEach((b) => {
      totalGross += Number(b.totalWorkAmount) || 0;
      totalKharcha += Number(b.totalKharcha) || 0;
      totalNet += Number(b.netBalancePayable) || 0;
    });
    return {
      count: digitalBills.length,
      totalGross,
      totalKharcha,
      totalNet,
    };
  }, [digitalBills]);

  // Format currency
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 }).format(val);
  };

  return (
    <div className="space-y-6 mb-12">
      {/* 1. Header Banner & View Tabs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3.5">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-md border border-amber-400/50 shrink-0">
            <Calculator className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg sm:text-xl font-black text-white tracking-wide">
                Labour Billing &amp; Digital Bill Dashboard
              </h2>
              <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                Official Bill Format
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Online Digital Bill Generator &bull; Monthly PDF by Labour &bull; Owner Record Management (Edit / Delete)
            </p>
          </div>
        </div>

        {/* Dashboard View Switcher Tabs */}
        <div className="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-bold shrink-0 self-start md:self-auto overflow-x-auto">
          <button
            type="button"
            onClick={() => setActiveTab('digital-bill')}
            className={`px-3 py-2 rounded-lg transition flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'digital-bill'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Digital Bill Generator</span>
          </button>

          {!userAccess.isLabour && (
            <button
              type="button"
              onClick={() => setActiveTab('all-records')}
              className={`px-3 py-2 rounded-lg transition flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
                activeTab === 'all-records'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Files className="w-3.5 h-3.5" />
              <span>All Monthly Records ({digitalBills.length})</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setActiveTab('rates-ledger')}
            className={`px-3 py-2 rounded-lg transition flex items-center space-x-2 whitespace-nowrap cursor-pointer ${
              activeTab === 'rates-ledger'
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white hover:bg-slate-900'
            }`}
          >
            <IndianRupee className="w-3.5 h-3.5" />
            <span>Rates &amp; Ledger</span>
          </button>
        </div>
      </div>

      {/* Save Success Toast */}
      {saveSuccessMsg && (
        <div className="p-3 bg-emerald-950/80 border border-emerald-500 rounded-xl text-emerald-200 text-xs flex items-center justify-between shadow-lg animate-in fade-in duration-200">
          <div className="flex items-center space-x-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span className="font-bold">{saveSuccessMsg}</span>
          </div>
          <button
            type="button"
            onClick={() => setSaveSuccessMsg(null)}
            className="text-emerald-400 hover:text-white text-xs font-bold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Labour Verified Status Banner */}
      {userAccess.isLabour && (
        <div className="p-3.5 bg-emerald-950/60 border border-emerald-500/60 rounded-xl text-emerald-200 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-md">
          <div className="flex items-center space-x-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <span className="font-bold text-white block">
                ✓ Verified Labour Account &bull; {userAccess.labourName}
              </span>
              <span className="text-[11px] text-emerald-300">
                Owner द्वारा आपकी Gmail ID सत्यापित है। आपका पूरा डिजिटल बिल, कार्य यूनिट्स और कुल भुगतान राशि नीचे उपलब्ध है।
              </span>
            </div>
          </div>
          <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-black rounded-lg border border-emerald-400/40 self-start sm:self-auto">
            {userAccess.email || 'Verified Gmail'}
          </span>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1: DIGITAL BILL STUDIO & PDF GENERATOR                                */}
      {/* ========================================================================= */}
      {activeTab === 'digital-bill' && (
        <div className="space-y-6">
          {/* Action Toolbar */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md flex flex-wrap items-center justify-between gap-3">
            {/* Labour Selector */}
            <div className="flex items-center space-x-2 flex-1 min-w-[240px]">
              <label className="text-xs font-bold text-slate-400 whitespace-nowrap">Select Labour:</label>
              <select
                value={selectedLabour}
                onChange={(e) => handleSelectLabour(e.target.value)}
                disabled={userAccess.isLabour}
                className="bg-slate-950 border border-slate-700 text-amber-400 font-black text-xs rounded-xl px-3 py-2 focus:border-amber-400 focus:outline-none flex-1 max-w-xs cursor-pointer"
              >
                {availableLabours.map((labour) => (
                  <option key={labour} value={labour}>
                    {labour}
                  </option>
                ))}
              </select>

              {!userAccess.isLabour && (
                <button
                  type="button"
                  onClick={() => setShowCustomizer(!showCustomizer)}
                  className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700 transition"
                  title="Toggle Bill Customizer & Edit Inputs"
                >
                  <SlidersHorizontal className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Actions: Download PDF, Batch PDF, Print, Save */}
            <div className="flex items-center flex-wrap gap-2">
              {/* Single Labour PDF */}
              <button
                type="button"
                onClick={handleDownloadSinglePDF}
                disabled={isGeneratingPdf || !currentBill}
                className="flex items-center space-x-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition disabled:opacity-50 cursor-pointer"
                title="Download Single Labour PDF (Exact Layout)"
              >
                <FileDown className="w-4 h-4" />
                <span>{isGeneratingPdf ? 'Generating...' : 'Download Labour PDF'}</span>
              </button>

              {/* Batch PDF: All Labour Monthly */}
              {!userAccess.isLabour && (
                <button
                  type="button"
                  onClick={handleDownloadBatchPDF}
                  disabled={isGeneratingBatchPdf || digitalBills.length === 0}
                  className="flex items-center space-x-1.5 px-3.5 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-xl shadow-md transition disabled:opacity-50 cursor-pointer"
                  title="Generate multi-page PDF containing all monthly labour bills"
                >
                  <Files className="w-4 h-4" />
                  <span>{isGeneratingBatchPdf ? 'Building Batch...' : 'All Labour Monthly PDF'}</span>
                </button>
              )}

              {/* Print preview */}
              <button
                type="button"
                onClick={() => window.print()}
                className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl border border-slate-700 transition cursor-pointer"
                title="Browser Print Preview"
              >
                <Printer className="w-4 h-4" />
              </button>

              {/* Save to Cloud (Owner only) */}
              {userAccess.isOwner && currentBill && (
                <button
                  type="button"
                  onClick={handleSaveCurrentBill}
                  className="flex items-center space-x-1.5 px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition cursor-pointer"
                  title="Save current bill into Firestore and records"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Record</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick Customizer Drawer (if expanded) */}
          {showCustomizer && currentBill && (
            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-4 animate-in fade-in duration-150 text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-slate-300 uppercase tracking-wide">
                  Quick Bill Adjuster: {currentBill.billNo}
                </span>
                <button
                  type="button"
                  onClick={() => setShowCustomizer(false)}
                  className="text-slate-400 hover:text-white font-bold text-xs"
                >
                  Close &times;
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Pay Bill No</label>
                  <input
                    type="text"
                    value={currentBill.billNo}
                    onChange={(e) => handleCurrentBillFieldChange('billNo', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 font-mono font-bold focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Billing Date</label>
                  <input
                    type="text"
                    value={currentBill.billingDate}
                    onChange={(e) => handleCurrentBillFieldChange('billingDate', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Payment Date</label>
                  <input
                    type="text"
                    value={currentBill.paymentDate}
                    onChange={(e) => handleCurrentBillFieldChange('paymentDate', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Labour Aadhaar</label>
                  <input
                    type="text"
                    value={currentBill.labourAadhaar || ''}
                    onChange={(e) => handleCurrentBillFieldChange('labourAadhaar', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 font-mono focus:border-amber-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-slate-400 block mb-1 font-semibold">Kharcha / Advance (₹)</label>
                  <input
                    type="number"
                    value={currentBill.totalKharcha}
                    onChange={(e) => handleCurrentBillFieldChange('totalKharcha', Number(e.target.value) || 0)}
                    className="w-full bg-slate-900 border border-amber-400 text-amber-300 font-bold rounded-lg px-2.5 py-1.5 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Items quick adder */}
              <div className="pt-2 flex justify-between items-center">
                <span className="text-slate-400 font-semibold">
                  Items in Bill: {currentBill.items.length} Rows &bull; Gross: ₹
                  {currentBill.totalWorkAmount.toLocaleString('en-IN')} &bull; Net: ₹
                  {currentBill.netBalancePayable.toLocaleString('en-IN')}
                </span>
                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={handleAddCurrentBillItem}
                    className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-bold text-xs transition"
                  >
                    + Add Item Row
                  </button>
                  <button
                    type="button"
                    onClick={() => setEditingBill(currentBill)}
                    className="px-3 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg font-black text-xs transition"
                  >
                    Full Table Editor &rarr;
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Live Digital Bill Sheet Preview (Matching Photo) */}
          <div className="bg-slate-950 p-4 sm:p-8 rounded-2xl border border-slate-800 shadow-2xl flex justify-center overflow-x-auto">
            {currentBill ? (
              <DigitalLabourBillSheet
                id="active-digital-bill-sheet"
                bill={currentBill}
                isPrintMode={false}
              />
            ) : (
              <div className="py-12 text-center text-slate-500">
                <p>
                  {userAccess.isLabour
                    ? 'No approved bill is available at this time. Please wait for owner approval.'
                    : 'Loading digital bill preview...'}
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: ALL LABOUR MONTHLY BILL RECORDS (OWNER EDIT & DELETE)              */}
      {/* ========================================================================= */}
      {activeTab === 'all-records' && !userAccess.isLabour && (
        <div className="space-y-6">
          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xs">
              <div className="text-xs text-slate-400 font-bold">Total Monthly Bills</div>
              <div className="text-2xl font-black text-white mt-1">{allRecordsStats.count}</div>
              <div className="text-[10px] text-slate-500 mt-0.5">Recorded in Cloud</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xs">
              <div className="text-xs text-amber-400 font-bold">Total Work Amount (Gross)</div>
              <div className="text-2xl font-black text-amber-300 mt-1 font-mono">
                ₹{formatCurrency(allRecordsStats.totalGross)}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">All Labours Combined</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xs">
              <div className="text-xs text-rose-400 font-bold">Total Kharcha Deductions</div>
              <div className="text-2xl font-black text-rose-300 mt-1 font-mono">
                ₹{formatCurrency(allRecordsStats.totalKharcha)}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Advance &amp; Expenses</div>
            </div>

            <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-xs">
              <div className="text-xs text-emerald-400 font-bold">Net Balance Payable</div>
              <div className="text-2xl font-black text-emerald-300 mt-1 font-mono">
                ₹{formatCurrency(allRecordsStats.totalNet)}
              </div>
              <div className="text-[10px] text-slate-500 mt-0.5">Final Release Due</div>
            </div>
          </div>

          {/* Search & Filter Toolbar */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 shadow-md flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center space-x-2 flex-1 min-w-[200px] max-w-md">
              <Search className="w-4 h-4 text-slate-500" />
              <input
                type="text"
                placeholder="Search by Labour Name, Bill No (SSR01)..."
                value={recordsSearch}
                onChange={(e) => setRecordsSearch(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 text-white rounded-xl px-3 py-2 focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={handleDownloadBatchPDF}
                disabled={isGeneratingBatchPdf || digitalBills.length === 0}
                className="flex items-center space-x-1.5 px-3 py-2 bg-sky-600 hover:bg-sky-500 text-white font-bold rounded-xl shadow-xs transition"
              >
                <Files className="w-3.5 h-3.5" />
                <span>Batch PDF All Labours</span>
              </button>

              {userAccess.isOwner && (
                <button
                  type="button"
                  onClick={() => {
                    const newBill = buildDigitalBillFromFloors('New Labour', floors, sqftConfig, header);
                    setEditingBill(newBill);
                  }}
                  className="flex items-center space-x-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black rounded-xl shadow-xs transition cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Create New Bill</span>
                </button>
              )}
            </div>
          </div>

          {/* Records Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-950 text-slate-400 font-bold border-b border-slate-800 uppercase tracking-wider text-[11px]">
                    <th className="p-3 w-24">Bill No</th>
                    <th className="p-3">Labour Name &amp; Aadhaar</th>
                    <th className="p-3">Billing Date</th>
                    <th className="p-3 text-right">Gross Work (₹)</th>
                    <th className="p-3 text-right">Kharcha / Adv (₹)</th>
                    <th className="p-3 text-right">Net Payable (₹)</th>
                    <th className="p-3 text-center">Status</th>
                    <th className="p-3 text-right w-44">Owner Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/70">
                  {filteredRecords.length > 0 ? (
                    filteredRecords.map((record) => (
                      <tr key={record.id} className="hover:bg-slate-800/40 transition">
                        <td className="p-3 font-mono font-black text-amber-300">
                          <span className="bg-amber-950/80 px-2 py-1 rounded border border-amber-600/50">
                            {record.billNo}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-white">
                          <div className="flex items-center space-x-2">
                            <span>{record.labourName}</span>
                          </div>
                          {record.labourAadhaar && (
                            <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                              Aadhaar: {record.labourAadhaar}
                            </div>
                          )}
                        </td>
                        <td className="p-3 text-slate-300 font-medium">
                          {record.billingDate}
                          <div className="text-[10px] text-slate-500">Pay: {record.paymentDate}</div>
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-slate-200">
                          ₹{formatCurrency(record.totalWorkAmount)}
                        </td>
                        <td className="p-3 text-right font-mono font-bold text-rose-300">
                          ₹{formatCurrency(record.totalKharcha)}
                        </td>
                        <td className="p-3 text-right font-mono font-black">
                          <span
                            className={
                              record.netBalancePayable >= 0 ? 'text-emerald-400' : 'text-rose-400'
                            }
                          >
                            ₹{record.netBalancePayable < 0 ? '-' : ''}
                            {formatCurrency(Math.abs(record.netBalancePayable))}
                          </span>
                        </td>
                        <td className="p-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                            {record.status || 'Approved'}
                          </span>
                        </td>
                        <td className="p-3 text-right">
                          <div className="flex items-center justify-end space-x-1.5">
                            {/* View in Digital Generator */}
                            <button
                              type="button"
                              onClick={() => {
                                setCurrentBill(record);
                                setSelectedLabour(record.labourName);
                                setActiveTab('digital-bill');
                              }}
                              title="View & Generate Digital Bill"
                              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-sky-400 rounded-lg transition"
                            >
                              <FileDown className="w-3.5 h-3.5" />
                            </button>

                            {/* Owner Edit Action */}
                            {userAccess.isOwner && (
                              <button
                                type="button"
                                onClick={() => setEditingBill(record)}
                                title="Edit Bill Record (Owner)"
                                className="p-1.5 bg-slate-800 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 rounded-lg transition cursor-pointer"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                            )}

                            {/* Owner Delete Action */}
                            {userAccess.isOwner && (
                              <button
                                type="button"
                                onClick={() => setBillToDelete(record)}
                                title="Delete Bill Record (Owner)"
                                className="p-1.5 bg-slate-800 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-lg transition cursor-pointer"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-500">
                        No labour monthly bill records found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: RATES & ADVANCE LEDGER                                             */}
      {/* ========================================================================= */}
      {activeTab === 'rates-ledger' && (
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg space-y-6">
          <div className="border-b border-slate-800 pb-3 flex items-center justify-between">
            <div>
              <h3 className="text-base font-black text-white">Labour Rates &amp; Advance Ledger</h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Manage default rates per sqft, hold retention percentage, and personal advance ledgers
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <label className="font-bold text-slate-300 block">Default Labour Rate Per Sqft</label>
              <div className="flex items-center space-x-2">
                <span className="text-slate-400">₹</span>
                <input
                  type="number"
                  step="0.5"
                  value={ratePerSqft}
                  disabled={!userAccess.isOwner}
                  onChange={(e) => setRatePerSqft(Number(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-bold w-24 focus:outline-none"
                />
                <span className="text-slate-500">/ sqft</span>
              </div>
              <p className="text-[11px] text-slate-500">Applied automatically when generating new bills.</p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <label className="font-bold text-slate-300 block">Quality Retention (Hold %)</label>
              <div className="flex items-center space-x-2">
                <input
                  type="number"
                  value={holdPercentage}
                  disabled={!userAccess.isOwner}
                  onChange={(e) => setHoldPercentage(Number(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-bold w-24 focus:outline-none"
                />
                <span className="text-slate-500">% retention hold</span>
              </div>
              <p className="text-[11px] text-slate-500">Released upon final snag inspection.</p>
            </div>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
              <label className="font-bold text-slate-300 block">Direct Site Daily Kharcha</label>
              <div className="flex items-center space-x-2">
                <span className="text-slate-400">₹</span>
                <input
                  type="number"
                  value={dailyExpenses}
                  disabled={!userAccess.isOwner}
                  onChange={(e) => setDailyExpenses(Number(e.target.value) || 0)}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-bold w-32 focus:outline-none"
                />
              </div>
              <p className="text-[11px] text-slate-500">Deducted from net balance payable.</p>
            </div>
          </div>
        </div>
      )}

      {/* Hidden container for rendering all batch bills for multi-page PDF generation */}
      <div
        id="batch-pdf-hidden-container"
        className="fixed left-[-9999px] top-[-9999px] w-[800px] pointer-events-none opacity-0"
        aria-hidden="true"
      >
        {digitalBills.map((bill) => (
          <div key={bill.id} id={`batch-bill-${bill.id}`} className="mb-8">
            <DigitalLabourBillSheet bill={bill} isPrintMode={true} />
          </div>
        ))}
      </div>

      {/* Owner Edit Bill Modal */}
      {editingBill && (
        <EditLabourBillModal
          isOpen={Boolean(editingBill)}
          onClose={() => setEditingBill(null)}
          bill={editingBill}
          onSave={handleSaveEditedBill}
        />
      )}

      {/* Owner Delete Bill Confirmation Dialog */}
      {billToDelete && (
        <ConfirmationDialog
          isOpen={Boolean(billToDelete)}
          title="Delete Labour Monthly Bill Record"
          message={`Are you sure you want to permanently delete bill "${billToDelete.billNo}" for ${billToDelete.labourName}? This record will be removed from Firestore cloud database.`}
          confirmText="Yes, Delete Bill Record"
          cancelText="Cancel"
          isDestructive={true}
          itemDetails={[
            { label: 'Pay Bill No', value: billToDelete.billNo },
            { label: 'Labour Name', value: billToDelete.labourName },
            { label: 'Work Amount', value: `₹${formatCurrency(billToDelete.totalWorkAmount)}` },
            { label: 'Kharcha Advance', value: `₹${formatCurrency(billToDelete.totalKharcha)}` },
            { label: 'Net Payable', value: `₹${formatCurrency(billToDelete.netBalancePayable)}` },
          ]}
          onConfirm={handleConfirmDeleteBill}
          onCancel={() => setBillToDelete(null)}
        />
      )}
    </div>
  );
};
