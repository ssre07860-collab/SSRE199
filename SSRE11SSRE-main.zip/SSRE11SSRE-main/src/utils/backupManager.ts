import { BillHeader, FloorEntry, UnitSqftConfig } from '../types';

export const BACKUP_LAST_DATE_KEY = 'prestige_tower2_last_backup_timestamp';
export const BACKUP_DISMISSED_KEY = 'prestige_tower2_backup_dismissed_until';
export const BACKUP_START_TRACKING_KEY = 'prestige_tower2_backup_start_tracking';

export interface BackupDataPayload {
  version: string;
  application: string;
  project: string;
  tower: string;
  workDescription: string;
  backupTimestamp: string;
  backupDateReadable: string;
  totalFloorsCount: number;
  header: BillHeader;
  sqftConfig?: UnitSqftConfig;
  floors: FloorEntry[];
  summaryStats?: {
    totalReleaseSqft: number;
    totalPaidSqft: number;
    totalHoldSqft: number;
  };
}

export interface BackupStatus {
  lastBackupDate: Date | null;
  daysSinceLastBackup: number | null;
  isDue: boolean;
  isDismissed: boolean;
  daysRemaining: number;
}

export const getLastBackupTimestamp = (): number | null => {
  try {
    const val = localStorage.getItem(BACKUP_LAST_DATE_KEY);
    if (!val) return null;
    const num = parseInt(val, 10);
    return isNaN(num) ? null : num;
  } catch (e) {
    console.warn('Could not read last backup timestamp', e);
    return null;
  }
};

export const ensureTrackingStarted = (): number => {
  try {
    const start = localStorage.getItem(BACKUP_START_TRACKING_KEY);
    if (!start) {
      const now = Date.now();
      localStorage.setItem(BACKUP_START_TRACKING_KEY, now.toString());
      return now;
    }
    return parseInt(start, 10) || Date.now();
  } catch {
    return Date.now();
  }
};

export const getBackupStatus = (intervalDays = 7): BackupStatus => {
  const now = Date.now();
  const lastTs = getLastBackupTimestamp();
  let isDismissed = false;

  try {
    const dismissedUntil = localStorage.getItem(BACKUP_DISMISSED_KEY);
    if (dismissedUntil) {
      const dismissedTime = parseInt(dismissedUntil, 10);
      if (!isNaN(dismissedTime) && now < dismissedTime) {
        isDismissed = true;
      }
    }
  } catch {
    // ignore
  }

  if (!lastTs) {
    const trackingStart = ensureTrackingStarted();
    const daysSinceStart = (now - trackingStart) / (1000 * 60 * 60 * 24);
    const isDue = daysSinceStart >= intervalDays;
    const daysRemaining = Math.max(0, Math.ceil(intervalDays - daysSinceStart));
    return {
      lastBackupDate: null,
      daysSinceLastBackup: null,
      isDue,
      isDismissed,
      daysRemaining,
    };
  }

  const elapsedMs = now - lastTs;
  const daysSince = Math.floor(elapsedMs / (1000 * 60 * 60 * 24));
  const isDue = daysSince >= intervalDays;
  const daysRemaining = Math.max(0, intervalDays - daysSince);

  return {
    lastBackupDate: new Date(lastTs),
    daysSinceLastBackup: daysSince,
    isDue,
    isDismissed,
    daysRemaining,
  };
};

export const recordBackupCompleted = (): void => {
  try {
    localStorage.setItem(BACKUP_LAST_DATE_KEY, Date.now().toString());
    localStorage.removeItem(BACKUP_DISMISSED_KEY);
  } catch (e) {
    console.error('Failed to record backup timestamp', e);
  }
};

export const dismissBackupReminder = (hours = 24): void => {
  try {
    const until = Date.now() + hours * 60 * 60 * 1000;
    localStorage.setItem(BACKUP_DISMISSED_KEY, until.toString());
  } catch (e) {
    console.warn('Failed to dismiss backup reminder', e);
  }
};

export const simulateBackupDue = (): void => {
  try {
    const eightDaysAgo = Date.now() - 8 * 24 * 60 * 60 * 1000;
    localStorage.setItem(BACKUP_LAST_DATE_KEY, eightDaysAgo.toString());
    localStorage.removeItem(BACKUP_DISMISSED_KEY);
  } catch (e) {
    console.warn('Failed to simulate backup due', e);
  }
};

export const downloadJsonBackup = (
  floors: FloorEntry[],
  header: BillHeader,
  sqftConfig?: UnitSqftConfig
): { success: boolean; filename: string } => {
  try {
    let totalRelease = 0;
    let totalPaid = 0;
    let totalHold = 0;
    floors.forEach((f) => {
      totalRelease += Number(f.releaseQuantity || 0);
      totalPaid += Number(f.paidQuantity || 0);
      totalHold += Number(f.holdQuantity || 0);
    });

    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10);
    const timeStr = now.toTimeString().slice(0, 8).replace(/:/g, '-');
    const filename = `Prestige_Tower2_SummaryBill_Backup_${dateStr}_${timeStr}.json`;

    const payload: BackupDataPayload = {
      version: '1.0',
      application: 'Prestige Lavender Field Tower 2 Summary Bill Record & Digital Entry',
      project: header.projectName || 'Prestige Lavender Field',
      tower: header.towerNo || 'Tower No 2',
      workDescription: header.workType || 'Gypsum Finishing Work',
      backupTimestamp: now.toISOString(),
      backupDateReadable: now.toLocaleString(),
      totalFloorsCount: floors.length,
      header,
      sqftConfig,
      floors,
      summaryStats: {
        totalReleaseSqft: totalRelease,
        totalPaidSqft: totalPaid,
        totalHoldSqft: totalHold,
      },
    };

    const jsonString = JSON.stringify(payload, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    recordBackupCompleted();
    return { success: true, filename };
  } catch (err) {
    console.error('Failed to trigger JSON backup download', err);
    return { success: false, filename: '' };
  }
};

export const parseBackupFile = (
  fileContent: string
): { valid: boolean; floors?: FloorEntry[]; header?: BillHeader; message?: string } => {
  try {
    const data = JSON.parse(fileContent);
    let parsedFloors: FloorEntry[] = [];
    let parsedHeader: BillHeader | undefined = undefined;

    if (Array.isArray(data)) {
      parsedFloors = data;
    } else if (data && typeof data === 'object') {
      if (Array.isArray(data.floors)) {
        parsedFloors = data.floors;
      }
      if (data.header && typeof data.header === 'object') {
        parsedHeader = data.header;
      }
    }

    if (!parsedFloors || parsedFloors.length === 0) {
      return {
        valid: false,
        message: 'Invalid backup file: No floor records found.',
      };
    }

    const hasValidFields = parsedFloors.every(
      (f) => typeof f === 'object' && f.floorNo !== undefined && f.paidQuantity !== undefined
    );

    if (!hasValidFields) {
      return {
        valid: false,
        message: 'Invalid floor data structure in backup file.',
      };
    }

    return {
      valid: true,
      floors: parsedFloors,
      header: parsedHeader,
      message: `Successfully validated ${parsedFloors.length} floor records.`,
    };
  } catch (err: any) {
    return {
      valid: false,
      message: `Failed to parse backup JSON: ${err?.message || 'Syntax error'}`,
    };
  }
};

export const resetBackupCycle = (): void => {
  recordBackupCompleted();
};

export const checkBackupStatus = getBackupStatus;
export const recordBackupDownloaded = recordBackupCompleted;
export const triggerJsonDownload = downloadJsonBackup;
export const exportDataAsBackupJSON = (
  floors: FloorEntry[],
  header: BillHeader,
  sqftConfig?: UnitSqftConfig,
  accounts?: any[]
) => {
  return downloadJsonBackup(floors, header, sqftConfig);
};

export const restoreBackupFromJSON = async (
  file: File
): Promise<{ success: boolean; data?: { floors?: FloorEntry[]; header?: BillHeader; sqftConfig?: UnitSqftConfig }; error?: string }> => {
  try {
    const text = await file.text();
    const parsed = parseBackupFile(text);
    if (!parsed.valid || !parsed.floors) {
      return { success: false, error: parsed.message || 'Invalid backup structure' };
    }
    const rawData = JSON.parse(text);
    return {
      success: true,
      data: {
        floors: parsed.floors,
        header: parsed.header,
        sqftConfig: rawData?.sqftConfig,
      },
    };
  } catch (err: any) {
    return { success: false, error: err?.message || 'File read error' };
  }
};
