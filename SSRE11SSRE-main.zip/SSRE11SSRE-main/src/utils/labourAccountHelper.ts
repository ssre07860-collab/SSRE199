import { collection, doc, getDocs, setDoc, deleteDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { UserAccount, LabourAccount, LabourMonthlyApproval, FloorEntry, UnitSqftConfig, UserRole, UserAccessInfo } from '../types';
import { INITIAL_LABOUR_ACCOUNTS, INITIAL_MONTHLY_APPROVALS } from '../data/initialLabourAccounts';
import { getUnitSqftValue } from './monthlySummaryHelper';

const STORAGE_ACCOUNTS_KEY = 'ssr_labour_accounts_v1';
const STORAGE_APPROVALS_KEY = 'ssr_labour_monthly_approvals_v1';

// Owner / Super Admin Email Addresses
export const OWNER_EMAILS = [
  'ssre07860@gmail.com',
  'zrbconstruction222@gmail.com',
  'contractor@gmail.com',
  'admin@gmail.com',
  'ssr.enterprises@gmail.com',
];

/**
 * Check if given email or user is an Owner/Admin
 */
export const isOwnerEmail = (email?: string | null): boolean => {
  if (!email) return false;
  const lower = email.trim().toLowerCase();
  return (
    OWNER_EMAILS.some((admin) => lower === admin.toLowerCase()) ||
    lower.includes('admin') ||
    lower.includes('contractor') ||
    lower.includes('owner') ||
    lower === 'ssre07860@gmail.com' ||
    lower === 'zrbconstruction222@gmail.com'
  );
};

/**
 * Load User / Labour Accounts from Firestore or LocalStorage
 */
export async function loadLabourAccounts(): Promise<UserAccount[]> {
  try {
    const querySnapshot = await getDocs(collection(db, 'labour_accounts'));
    if (!querySnapshot.empty) {
      const accounts: UserAccount[] = [];
      querySnapshot.forEach((d) => {
        accounts.push({ ...(d.data() as UserAccount), id: d.id });
      });
      localStorage.setItem(STORAGE_ACCOUNTS_KEY, JSON.stringify(accounts));
      return accounts;
    }
  } catch (err) {
    console.info('Firestore accounts read fallback to local state:', err);
  }

  // Fallback to local storage
  const cached = localStorage.getItem(STORAGE_ACCOUNTS_KEY);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      // Ignore
    }
  }

  // Default seed
  localStorage.setItem(STORAGE_ACCOUNTS_KEY, JSON.stringify(INITIAL_LABOUR_ACCOUNTS));
  return INITIAL_LABOUR_ACCOUNTS;
}

/**
 * Save / Update a User / Labour Account in Firestore and LocalStorage
 */
export async function saveLabourAccount(account: UserAccount): Promise<void> {
  const updatedAccount: UserAccount = {
    ...account,
    updatedAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'labour_accounts', account.id), updatedAccount, { merge: true });
  } catch (err) {
    console.warn('Could not sync user account to Firestore:', err);
  }

  // Update local cache
  const current = await loadLabourAccounts();
  const index = current.findIndex((a) => a.id === account.id || a.email.toLowerCase() === account.email.toLowerCase());
  let updatedList: UserAccount[];
  if (index >= 0) {
    updatedList = [...current];
    updatedList[index] = updatedAccount;
  } else {
    updatedList = [updatedAccount, ...current];
  }
  localStorage.setItem(STORAGE_ACCOUNTS_KEY, JSON.stringify(updatedList));
}

export const saveUserAccount = saveLabourAccount;

/**
 * Delete a User Account from Firestore and LocalStorage
 */
export async function deleteLabourAccount(accountId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'labour_accounts', accountId));
  } catch (err) {
    console.warn('Could not delete user account from Firestore:', err);
  }

  const current = await loadLabourAccounts();
  const updatedList = current.filter((a) => a.id !== accountId);
  localStorage.setItem(STORAGE_ACCOUNTS_KEY, JSON.stringify(updatedList));
}

export const deleteUserAccount = deleteLabourAccount;

/**
 * Load Monthly Bill Approvals from Firestore or LocalStorage
 */
export async function loadMonthlyApprovals(): Promise<LabourMonthlyApproval[]> {
  try {
    const querySnapshot = await getDocs(collection(db, 'labour_approvals'));
    if (!querySnapshot.empty) {
      const approvals: LabourMonthlyApproval[] = [];
      querySnapshot.forEach((d) => {
        approvals.push({ ...(d.data() as LabourMonthlyApproval), id: d.id });
      });
      localStorage.setItem(STORAGE_APPROVALS_KEY, JSON.stringify(approvals));
      return approvals;
    }
  } catch (err) {
    console.info('Firestore monthly approvals read fallback to local state:', err);
  }

  const cached = localStorage.getItem(STORAGE_APPROVALS_KEY);
  if (cached) {
    try {
      return JSON.parse(cached);
    } catch {
      // Ignore
    }
  }

  localStorage.setItem(STORAGE_APPROVALS_KEY, JSON.stringify(INITIAL_MONTHLY_APPROVALS));
  return INITIAL_MONTHLY_APPROVALS;
}

/**
 * Save or Update Monthly Bill Approval in Firestore & LocalStorage
 */
export async function saveMonthlyApproval(approval: LabourMonthlyApproval): Promise<void> {
  const updated: LabourMonthlyApproval = {
    ...approval,
    updatedAt: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'labour_approvals', approval.id), updated, { merge: true });
  } catch (err) {
    console.warn('Could not sync approval to Firestore:', err);
  }

  const current = await loadMonthlyApprovals();
  const index = current.findIndex((a) => a.id === approval.id);
  let updatedList: LabourMonthlyApproval[];
  if (index >= 0) {
    updatedList = [...current];
    updatedList[index] = updated;
  } else {
    updatedList = [updated, ...current];
  }
  localStorage.setItem(STORAGE_APPROVALS_KEY, JSON.stringify(updatedList));
}

/**
 * Calculate detailed work records for a specific labour
 */
export function calculateLabourWorkRecords(
  labourName: string,
  floors: FloorEntry[],
  sqftConfig: UnitSqftConfig,
  ratePerSqft: number = 12,
  selectedMonth?: string
) {
  const normLabour = labourName.trim().toLowerCase();
  const unitKeys: Array<{ key: string; label: string }> = [
    { key: 'unit1', label: 'Unit 1' },
    { key: 'unit2', label: 'Unit 2' },
    { key: 'unit3', label: 'Unit 3' },
    { key: 'unit4', label: 'Unit 4' },
    { key: 'unit5', label: 'Unit 5' },
    { key: 'unit6', label: 'Unit 6' },
    { key: 'unit7', label: 'Unit 7' },
    { key: 'unit8', label: 'Unit 8' },
    { key: 'lobby', label: 'Lobby' },
    { key: 'starc1', label: 'Star C1' },
    { key: 'starc2', label: 'Star C2' },
  ];

  let totalSqft = 0;
  let paidSqft = 0;
  let pendingSqft = 0;
  let totalUnits = 0;
  let paidUnits = 0;
  let pendingUnits = 0;

  interface DetailedItem {
    floorId: string;
    floorNo: string;
    towerNo: string;
    unitKey: string;
    unitLabel: string;
    sqft: number;
    status: 'paid' | 'pending' | 'none';
    cost: number;
    month?: string;
  }

  const detailedItems: DetailedItem[] = [];
  const floorsSet = new Set<string>();

  floors.forEach((f) => {
    // If month filter is applied
    if (selectedMonth && f.month && f.month !== selectedMonth) {
      return;
    }

    const defaultFloorLabour = (f.labourName || '').trim();

    unitKeys.forEach((u) => {
      const status = (f[u.key as keyof FloorEntry] as 'paid' | 'pending' | 'none') || 'none';
      if (status === 'none') return;

      const unitLabour = (f.unitLabours && f.unitLabours[u.key])
        ? f.unitLabours[u.key].trim()
        : defaultFloorLabour;

      if (!unitLabour || unitLabour.toLowerCase() !== normLabour) {
        return;
      }

      const sqft = getUnitSqftValue(u.key, sqftConfig);
      const cost = sqft * ratePerSqft;

      totalSqft += sqft;
      totalUnits += 1;
      floorsSet.add(f.floorNo);

      if (status === 'paid') {
        paidSqft += sqft;
        paidUnits += 1;
      } else if (status === 'pending') {
        pendingSqft += sqft;
        pendingUnits += 1;
      }

      detailedItems.push({
        floorId: f.id,
        floorNo: f.floorNo,
        towerNo: f.towerNo || 'Tower No 2',
        unitKey: u.key,
        unitLabel: u.label,
        sqft,
        status,
        cost,
        month: f.month || '2026-09',
      });
    });
  });

  const grossAmount = totalSqft * ratePerSqft;
  const holdPercentage = 20; // 20% standard retention hold
  const holdAmount = (grossAmount * holdPercentage) / 100;
  const advanceDeduction = 0;
  const netPayable = grossAmount - holdAmount - advanceDeduction;

  return {
    labourName,
    totalSqft,
    paidSqft,
    pendingSqft,
    totalUnits,
    paidUnits,
    pendingUnits,
    floorsCount: floorsSet.size,
    floorsList: Array.from(floorsSet),
    grossAmount,
    holdPercentage,
    holdAmount,
    advanceDeduction,
    netPayable,
    ratePerSqft,
    detailedItems,
  };
}

/**
 * Determine the user role, permissions, and profile link
 */
export function resolveUserAccess(
  userEmail: string | null | undefined,
  activeRoleOverride?: UserRole | null,
  activeLabourNameOverride?: string | null,
  accounts: UserAccount[] = []
): UserAccessInfo {
  const lowerEmail = userEmail ? userEmail.trim().toLowerCase() : null;

  // 1. If user is authenticated
  if (lowerEmail) {
    const isOwner = isOwnerEmail(lowerEmail);

    if (isOwner) {
      // Owners are allowed full override preview controls
      if (activeRoleOverride === 'supervisor') {
        const matched = accounts.find((a) => a.role === 'supervisor') || {
          id: 'acc-demo-supervisor',
          email: 'supervisor.site@gmail.com',
          name: 'Site Supervisor',
          role: 'supervisor' as UserRole,
          status: 'approved' as const,
          registeredAt: new Date().toISOString(),
        };
        return {
          role: 'supervisor',
          userAccount: matched,
          isOwner: false,
          isSupervisor: true,
          isLabour: false,
          isApproved: true,
          canEdit: true,
          canManageUsers: false,
          canApproveBills: false,
          canManageSites: true,
        };
      }

      if (activeRoleOverride === 'labour') {
        const matched = accounts.find(
          (a) => a.name.toLowerCase() === (activeLabourNameOverride || 'dilshad').toLowerCase()
        ) || {
          id: 'acc-demo-labour',
          email: 'labour@gmail.com',
          name: activeLabourNameOverride || 'Dilshad',
          role: 'labour' as UserRole,
          status: 'approved' as const,
          registeredAt: new Date().toISOString(),
        };
        return {
          role: 'labour',
          userAccount: matched,
          labourAccount: matched,
          labourName: matched.name,
          isOwner: false,
          isSupervisor: false,
          isLabour: true,
          isApproved: matched.status === 'approved',
          canEdit: false,
          canManageUsers: false,
          canApproveBills: false,
          canManageSites: false,
        };
      }

      // Default to owner/super contractor
      return {
        role: 'owner',
        email: userEmail || undefined,
        isOwner: true,
        isSupervisor: true,
        isLabour: false,
        isApproved: true,
        canEdit: true,
        canManageUsers: true,
        canApproveBills: true,
        canManageSites: true,
      };
    }

    // Gmail logged in but is not an owner: Check if owner has added/verified this Gmail
    const matchedAccount = accounts.find(
      (a) => a.email && a.email.trim().toLowerCase() === lowerEmail
    );

    if (matchedAccount) {
      const isVerified = (matchedAccount.isVerifiedByOwner === true || matchedAccount.status === 'approved') && matchedAccount.status !== 'rejected';
      const effectiveLabourName = matchedAccount.mappedLabourName || matchedAccount.name;

      if (matchedAccount.role === 'supervisor') {
        return {
          role: 'supervisor',
          email: userEmail || undefined,
          userAccount: matchedAccount,
          isOwner: false,
          isSupervisor: true,
          isLabour: false,
          isApproved: isVerified,
          isVerifiedByOwner: isVerified,
          verifiedByEmail: matchedAccount.verifiedByEmail || matchedAccount.approvedBy,
          canEdit: isVerified,
          canManageUsers: false,
          canApproveBills: false,
          canManageSites: false,
        };
      }

      return {
        role: 'labour',
        email: userEmail || undefined,
        userAccount: matchedAccount,
        labourAccount: matchedAccount,
        labourName: effectiveLabourName,
        isOwner: false,
        isSupervisor: false,
        isLabour: true,
        isApproved: isVerified,
        isVerifiedByOwner: isVerified,
        verifiedByEmail: matchedAccount.verifiedByEmail || matchedAccount.approvedBy,
        canEdit: false,
        canManageUsers: false,
        canApproveBills: false,
        canManageSites: false,
      };
    }

    // Gmail logged in but not added / verified by owner yet ("usse pahle na dikhe")
    return {
      role: 'labour',
      email: userEmail || undefined,
      labourName: (userEmail || 'Guest').split('@')[0],
      isOwner: false,
      isSupervisor: false,
      isLabour: true,
      isApproved: false,
      isVerifiedByOwner: false,
      canEdit: false,
      canManageUsers: false,
      canApproveBills: false,
      canManageSites: false,
    };
  }

  // 2. Unauthenticated state (No Email provided) - let owner simulation override
  if (activeRoleOverride === 'supervisor') {
    return {
      role: 'supervisor',
      isOwner: false,
      isSupervisor: true,
      isLabour: false,
      isApproved: true,
      canEdit: true,
      canManageUsers: false,
      canApproveBills: false,
      canManageSites: true,
    };
  }

  if (activeRoleOverride === 'labour') {
    const matched = accounts.find(
      (a) => a.name.toLowerCase() === (activeLabourNameOverride || 'dilshad').toLowerCase()
    ) || {
      id: 'acc-demo-labour',
      email: 'labour@gmail.com',
      name: activeLabourNameOverride || 'Dilshad',
      role: 'labour' as UserRole,
      status: 'approved' as const,
      registeredAt: new Date().toISOString(),
    };
    return {
      role: 'labour',
      userAccount: matched,
      labourAccount: matched,
      labourName: matched.name,
      isOwner: false,
      isSupervisor: false,
      isLabour: true,
      isApproved: matched.status === 'approved',
      canEdit: false,
      canManageUsers: false,
      canApproveBills: false,
      canManageSites: false,
    };
  }

  // Master defaults
  return {
    role: 'owner',
    isOwner: true,
    isSupervisor: true,
    isLabour: false,
    isApproved: true,
    canEdit: true,
    canManageUsers: true,
    canApproveBills: true,
    canManageSites: true,
  };
}
