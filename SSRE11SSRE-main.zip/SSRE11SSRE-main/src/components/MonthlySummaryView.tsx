import React, { useState, useMemo } from 'react';
import {
  Calendar,
  CheckCircle2,
  Clock,
  FileDown,
  Building,
  TrendingUp,
  Search,
  User,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  Info,
  ChevronRight,
} from 'lucide-react';
import { FloorEntry, UnitSqftConfig, BillHeader, UserAccessInfo, UserAccount } from '../types';
import { aggregateMonthlySummaries, getFloorDefaultMonth } from '../utils/monthlySummaryHelper';
import { getActiveUnits } from '../utils/floorCalculationHelper';
import { generateInstantPDF } from '../utils/pdfGenerator';

interface MonthlySummaryViewProps {
  floors: FloorEntry[];
  sqftConfig: UnitSqftConfig;
  header: BillHeader;
  userAccess: UserAccessInfo;
  accounts: UserAccount[];
  onSelectMonthFilter: (month: string) => void;
}

export const MonthlySummaryView: React.FC<MonthlySummaryViewProps> = ({
  floors,
  sqftConfig,
  header,
  userAccess,
  accounts,
  onSelectMonthFilter,
}) => {
  const summaries = aggregateMonthlySummaries(floors, sqftConfig);
  const [isExporting, setIsExporting] = useState(false);
  const [expandedMonths, setExpandedMonths] = useState<Record<string, boolean>>({});
  const [ledgerSearch, setLedgerSearch] = useState<string>('');

  const handleExportPDF = async () => {
    setIsExporting(true);
    try {
      await generateInstantPDF('monthly-summary-sheet', 'Monthly_Gypsum_Bill_Summary.pdf', 'landscape');
    } finally {
      setIsExporting(false);
    }
  };

  const toggleMonthExpand = (monthKey: string) => {
    setExpandedMonths((prev) => ({
      ...prev,
      [monthKey]: !prev[monthKey],
    }));
  };

  // Helper to find labour rate per sqft
  const getLabourRate = (labourName: string): number => {
    const cleanName = labourName.trim().toLowerCase();
    const matched = accounts.find(
      (a) => a.name.trim().toLowerCase() === cleanName && a.role === 'labour'
    );
    return matched?.ratePerSqft || 12; // Default rate of ₹12/sqft if not specified
  };

  return (
    <div className="space-y-6 mb-8">
      {/* Top Banner */}
      <div className="bg-white rounded-xl p-4 border border-slate-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-black text-slate-900 flex items-center space-x-2">
            <Calendar className="w-5 h-5 text-emerald-600" />
            <span>Monthly Aggregated Bill Records &amp; Certification</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Audit work progress, unit-by-unit labour logs, and certified earnings release.
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportPDF}
          disabled={isExporting}
          className="flex items-center space-x-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg transition shadow-xs"
        >
          <FileDown className="w-4 h-4 text-emerald-400" />
          <span>{isExporting ? 'Exporting...' : 'Export Monthly PDF'}</span>
        </button>
      </div>

      {/* Monthly Cards Grid */}
      <div id="monthly-summary-sheet" className="grid grid-cols-1 gap-6">
        {summaries.map((summary) => {
          const compRate =
            summary.totalFloors > 0
              ? Math.round((summary.completedFloors / summary.totalFloors) * 100)
              : 0;

          // Get all floors belonging to this month
          const monthFloors = floors.filter(
            (f) => getFloorDefaultMonth(f) === summary.monthKey
          );

          // Build precise unit-by-unit labour work entries for this month
          const activeUnitsList = getActiveUnits(sqftConfig);
          const workEntries = [];

          for (const floor of monthFloors) {
            const labourName = floor.labourName?.trim() || 'Ramesh Mistri';
            const rate = getLabourRate(labourName);

            for (const unit of activeUnitsList) {
              const status = floor[unit.key] || 'none';
              const sqft = typeof sqftConfig[unit.configKey] === 'number' ? (sqftConfig[unit.configKey] as number) : 0;
              
              // Only calculate amount if Verified/Certified ("paid")
              const certifiedAmount = status === 'paid' ? sqft * rate : 0;
              const pendingAmount = status === 'pending' ? sqft * rate : 0;

              workEntries.push({
                id: `${floor.id || floor.floorNo}-${unit.key}`,
                floorNo: floor.floorNo,
                towerNo: floor.towerNo || 'Tower 2',
                labourName,
                unitKey: unit.key,
                unitLabel: unit.label,
                sqft,
                rate,
                status,
                certifiedAmount,
                pendingAmount,
              });
            }
          }

          // Filter entries based on micro search
          const filteredEntries = workEntries.filter((entry) => {
            if (!ledgerSearch) return true;
            const query = ledgerSearch.toLowerCase();
            return (
              entry.labourName.toLowerCase().includes(query) ||
              entry.floorNo.toLowerCase().includes(query) ||
              entry.unitLabel.toLowerCase().includes(query)
            );
          });

          // Compute certified sums vs pending sums
          const totalCertifiedEarnings = filteredEntries.reduce((acc, e) => acc + e.certifiedAmount, 0);
          const totalPendingEarnings = filteredEntries.reduce((acc, e) => acc + e.pendingAmount, 0);

          const isExpanded = !!expandedMonths[summary.monthKey];

          return (
            <div
              key={summary.monthKey}
              className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden hover:border-slate-300 transition"
            >
              {/* Card Header */}
              <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-black text-slate-900">{summary.monthName}</div>
                  <div className="text-[11px] text-slate-500">{summary.monthKey} &bull; {header.projectName || 'Prestige Lavender Field'}</div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase tracking-wide ${
                      summary.status === 'Approved'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-amber-100 text-amber-800 border border-amber-300'
                    }`}
                  >
                    {summary.status}
                  </span>

                  <button
                    type="button"
                    onClick={() => toggleMonthExpand(summary.monthKey)}
                    className="p-1.5 hover:bg-slate-200 rounded-lg text-slate-500 transition"
                  >
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Progress & Quick Totals */}
              <div className="p-4 border-b border-slate-100 grid grid-cols-1 md:grid-cols-12 gap-4">
                <div className="md:col-span-4 space-y-2">
                  <div className="flex justify-between text-xs font-bold text-slate-700">
                    <span>Floor Verification Progress</span>
                    <span>{summary.completedFloors} / {summary.totalFloors} ({compRate}%)</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-emerald-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${compRate}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-400 font-bold">
                    <span>{summary.completedFloors} verified floors</span>
                    <span>{summary.inProgressFloors} pending floors</span>
                  </div>
                </div>

                {/* Amount Certification Banner - Adheres strictly to: "verify hone ke bad amount to Karen" */}
                <div className="md:col-span-8 grid grid-cols-2 sm:grid-cols-3 gap-2">
                  <div className="bg-emerald-50 p-2.5 rounded-lg border border-emerald-200">
                    <div className="text-[9px] text-emerald-800 font-extrabold uppercase tracking-wide flex items-center space-x-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>Certified Amount</span>
                    </div>
                    <div className="text-base font-black text-emerald-950 mt-1">
                      ₹{totalCertifiedEarnings.toLocaleString('en-IN')}
                    </div>
                    <span className="text-[9px] text-emerald-600 font-bold block">
                      Approved &amp; Certified Work
                    </span>
                  </div>

                  <div className="bg-amber-50 p-2.5 rounded-lg border border-amber-200">
                    <div className="text-[9px] text-amber-800 font-extrabold uppercase tracking-wide flex items-center space-x-1">
                      <Clock className="w-3 h-3 text-amber-600" />
                      <span>Awaiting Signoff</span>
                    </div>
                    <div className="text-base font-black text-amber-950 mt-1">
                      ₹0
                    </div>
                    <span className="text-[9px] text-amber-600 font-bold block">
                      ₹{totalPendingEarnings.toLocaleString('en-IN')} is unverified
                    </span>
                  </div>

                  <div className="col-span-2 sm:col-span-1 bg-slate-50 p-2.5 rounded-lg border border-slate-200 flex flex-col justify-center">
                    <div className="text-[9px] text-slate-500 font-bold uppercase">Total Checked Units</div>
                    <div className="text-sm font-black text-slate-900 mt-0.5">
                      {workEntries.filter(e => e.status === 'paid').length} / {workEntries.length}
                    </div>
                  </div>
                </div>
              </div>

              {/* Collapsible Detailed Labour/Unit Ledger */}
              {isExpanded ? (
                <div className="p-4 space-y-4 bg-slate-50/50 animate-in slide-in-from-top-2 duration-200">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div>
                      <h4 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                        Labour &amp; Flat Unit Certification Ledger
                      </h4>
                      <p className="text-[11px] text-slate-400">Unit-by-unit verification status of plastering entries</p>
                    </div>

                    {/* Micro search */}
                    <div className="flex items-center space-x-1.5 bg-white border border-slate-300 rounded-lg px-2.5 py-1.5 w-full sm:w-64 focus-within:border-emerald-500 shadow-2xs">
                      <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <input
                        type="text"
                        placeholder="Search Labour or Flat..."
                        value={ledgerSearch}
                        onChange={(e) => setLedgerSearch(e.target.value)}
                        className="bg-transparent border-none text-xs focus:outline-hidden text-slate-800 font-semibold w-full"
                      />
                    </div>
                  </div>

                  <div className="overflow-x-auto border border-slate-200 rounded-lg bg-white">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="bg-slate-100 text-slate-600 font-bold uppercase text-[9px] border-b border-slate-200">
                          <th className="p-2.5">Floor &amp; Tower</th>
                          <th className="p-2.5">Labour Name</th>
                          <th className="p-2.5">Flat Unit / Item</th>
                          <th className="p-2.5 text-right">Area (Sqft)</th>
                          <th className="p-2.5 text-right">Rate</th>
                          <th className="p-2.5 text-center">Status</th>
                          <th className="p-2.5 text-right font-black text-emerald-800">Certified Amt (₹)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 font-medium">
                        {filteredEntries.map((entry) => (
                          <tr key={entry.id} className="hover:bg-slate-50 transition-colors">
                            <td className="p-2.5 font-bold text-slate-900">
                              {entry.floorNo} <span className="text-[10px] text-slate-400">({entry.towerNo})</span>
                            </td>
                            <td className="p-2.5 text-slate-700 font-bold flex items-center space-x-1">
                              <User className="w-3 h-3 text-slate-400 shrink-0" />
                              <span>{entry.labourName}</span>
                            </td>
                            <td className="p-2.5">
                              <span className="font-extrabold text-slate-800 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200 text-[10px]">
                                {entry.unitLabel}
                              </span>
                            </td>
                            <td className="p-2.5 text-right font-mono font-bold text-slate-600">
                              {entry.sqft} sqft
                            </td>
                            <td className="p-2.5 text-right font-mono text-slate-500">
                              ₹{entry.rate}/sqft
                            </td>
                            <td className="p-2.5 text-center">
                              {entry.status === 'paid' ? (
                                <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[9px] font-black uppercase inline-flex items-center space-x-0.5 border border-emerald-200">
                                  <span>Verified</span>
                                  <CheckCircle2 className="w-2.5 h-2.5 text-emerald-600" />
                                </span>
                              ) : entry.status === 'pending' ? (
                                <span className="px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full text-[9px] font-bold uppercase inline-flex items-center space-x-0.5 border border-amber-200">
                                  <span>Pending Verification</span>
                                  <Clock className="w-2.5 h-2.5 text-amber-600 animate-pulse" />
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 bg-slate-100 text-slate-400 rounded-full text-[9px] font-bold uppercase inline-flex items-center space-x-0.5 border border-slate-200">
                                  <span>Not Started</span>
                                </span>
                              )}
                            </td>
                            <td className="p-2.5 text-right font-mono font-black text-slate-950">
                              {entry.status === 'paid' ? (
                                <span className="text-emerald-700">₹{entry.certifiedAmount.toLocaleString('en-IN')}</span>
                              ) : (
                                <div className="text-slate-400 flex flex-col items-end">
                                  <span>₹0</span>
                                  {entry.status === 'pending' && (
                                    <span className="text-[8px] text-amber-600 font-bold block leading-none mt-0.5">
                                      (₹{entry.pendingAmount.toLocaleString('en-IN')} pending)
                                    </span>
                                  )}
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}

                        {filteredEntries.length === 0 && (
                          <tr>
                            <td colSpan={7} className="p-8 text-center text-slate-400 text-xs font-semibold">
                              No matching labour entries found for this month.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>

                  {/* Audit Footer Disclaimer */}
                  <div className="p-3 bg-emerald-50/50 border border-emerald-200 rounded-xl text-[10px] text-emerald-800 font-bold flex items-start space-x-2">
                    <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>
                      * <strong>Auditing Compliance:</strong> Outstanding balance calculation is restricted strictly to &quot;Verified&quot; (Completed) flats to prevent premature payouts. Pending entries will release to certified only after owner approval signature on the supervisor table.
                    </span>
                  </div>
                </div>
              ) : (
                <div className="px-4 py-3 bg-slate-50/30 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500 font-bold">
                  <span>Contains {workEntries.length} individual flat units logs</span>
                  <button
                    type="button"
                    onClick={() => toggleMonthExpand(summary.monthKey)}
                    className="text-emerald-600 hover:text-emerald-700 flex items-center space-x-0.5"
                  >
                    <span>Show Detailed Labour Work Ledger</span>
                    <ChevronDown className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Filter Floors Button */}
              <div className="p-4 bg-white border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => onSelectMonthFilter(summary.monthKey)}
                  className="w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-lg transition flex items-center justify-center space-x-1"
                >
                  <span>Filter Bill Sheet Floors by {summary.monthName}</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
