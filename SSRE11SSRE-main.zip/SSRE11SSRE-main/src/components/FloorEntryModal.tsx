import React, { useState, useEffect } from 'react';
import {
  X,
  Building,
  User,
  Calculator,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Sparkles,
  FileDown,
  Printer,
} from 'lucide-react';
import { FloorEntry, UnitSqftConfig, UnitStatus, BillHeader, UserAccount } from '../types';
import { UNIT_CONFIG_MAP, toggleSingleUnitStatus, toggleFloorCompletedStatus } from '../utils/floorCalculationHelper';
import { DEFAULT_LABOUR_SUGGESTIONS, applySameLabourToAllUnits, isAllUnitsSameLabour } from '../utils/labourBillHelper';

interface FloorEntryModalProps {
  isOpen: boolean;
  floor: FloorEntry | null;
  onClose: () => void;
  onSave: (floor: FloorEntry) => void;
  sqftConfig: UnitSqftConfig;
  header: BillHeader;
  activeTower: string;
  accounts: UserAccount[];
}

export const FloorEntryModal: React.FC<FloorEntryModalProps> = ({
  isOpen,
  floor,
  onClose,
  onSave,
  sqftConfig,
  header,
  activeTower,
  accounts,
}) => {
  const [formData, setFormData] = useState<FloorEntry>(() => {
    return (
      floor || {
        id: `floor-${Date.now()}`,
        scName: header.scName || 'SSR',
        towerNo: activeTower || header.towerNo || 'Tower 2',
        floorNo: '1st',
        flatsNo: '101 to 108',
        labourName: 'Adil Ahmad',
        unit1: 'paid',
        unit2: 'paid',
        unit3: 'paid',
        unit4: 'paid',
        unit5: 'paid',
        unit6: 'paid',
        unit7: 'paid',
        unit8: 'paid',
        lobby: 'paid',
        starc1: 'paid',
        starc2: 'paid',
        releaseQuantity: 21742,
        holdQuantity: 4348,
        paidQuantity: 17394,
        gypsumRunningFlats: 8,
        gypsumRunningLobby: 1,
        starches1WC: 1,
        starches2WC: 1,
        verifyFlats: 8,
        verifyLobby: 1,
        verifyStar1: 1,
        verifyStar2: 1,
        remarks: '',
        signature: 'Adel',
        month: '2026-09',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    );
  });

  const [applySameLabour, setApplySameLabour] = useState(true);

  useEffect(() => {
    if (floor) {
      setFormData(floor);
      const { same } = isAllUnitsSameLabour(floor);
      setApplySameLabour(same);
    } else {
      setFormData({
        id: `floor-${Date.now()}`,
        scName: header.scName || 'SSR',
        towerNo: activeTower || header.towerNo || 'Tower 2',
        floorNo: 'New',
        flatsNo: '',
        labourName: 'Adil Ahmad',
        unit1: 'pending',
        unit2: 'pending',
        unit3: 'pending',
        unit4: 'pending',
        unit5: 'pending',
        unit6: 'pending',
        unit7: 'pending',
        unit8: 'pending',
        lobby: 'pending',
        starc1: 'pending',
        starc2: 'pending',
        releaseQuantity: 21742,
        holdQuantity: 21742,
        paidQuantity: 0,
        gypsumRunningFlats: 0,
        gypsumRunningLobby: 0,
        starches1WC: 0,
        starches2WC: 0,
        verifyFlats: 0,
        verifyLobby: 0,
        verifyStar1: 0,
        verifyStar2: 0,
        remarks: '',
        signature: '',
        month: '2026-09',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      });
      setApplySameLabour(true);
    }
  }, [floor, activeTower, header]);

  if (!isOpen) return null;

  const handleLabourChange = (name: string) => {
    if (applySameLabour) {
      setFormData(applySameLabourToAllUnits(formData, name));
    } else {
      setFormData({ ...formData, labourName: name });
    }
  };

  const handleUnitToggle = (key: keyof FloorEntry) => {
    const updated = toggleSingleUnitStatus(formData, key, sqftConfig);
    setFormData(updated);
  };

  const handleMarkAllDone = () => {
    const updated = toggleFloorCompletedStatus(formData, sqftConfig, true);
    setFormData(updated);
  };

  const handleMarkAllPending = () => {
    const updated = toggleFloorCompletedStatus(formData, sqftConfig, false);
    setFormData(updated);
  };

  const handleMarkAllNone = () => {
    const updated = { ...formData };
    UNIT_CONFIG_MAP.forEach(({ key }) => {
      (updated[key] as any) = 'none';
    });
    updated.gypsumRunningFlats = 0;
    updated.gypsumRunningLobby = 0;
    updated.starches1WC = 0;
    updated.starches2WC = 0;
    updated.verifyFlats = 0;
    updated.verifyLobby = 0;
    updated.verifyStar1 = 0;
    updated.verifyStar2 = 0;
    updated.releaseQuantity = 0;
    updated.holdQuantity = 0;
    updated.paidQuantity = 0;
    updated.updatedAt = new Date().toISOString();
    setFormData(updated);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const registeredLabours = accounts.filter(acc => acc.role === 'labour');
    const isValidLabour = registeredLabours.some(
      (acc) => acc.name.trim().toLowerCase() === (formData.labourName || '').trim().toLowerCase()
    );

    if (!(formData.labourName || '').trim() || !isValidLabour) {
      alert("Error: Please select a registered Labour name.");
      return;
    }
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl my-8 overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Building className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-black">
              {floor ? `Edit Floor ${floor.floorNo}` : 'Add New Floor Entry'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-4 sm:p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Row 1: Floor & Flats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Floor No (e.g. 1st, 2nd)
              </label>
              <input
                id="modal-floor-no"
                type="text"
                required
                value={formData.floorNo}
                onChange={(e) => setFormData({ ...formData, floorNo: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-sm font-black text-slate-900 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Flats Range (e.g. 101 to 108)
              </label>
              <input
                id="modal-flats-no"
                type="text"
                value={formData.flatsNo}
                onChange={(e) => setFormData({ ...formData, flatsNo: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-sm font-medium text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                Site Tower
              </label>
              <input
                id="modal-tower-no"
                type="text"
                value={formData.towerNo}
                onChange={(e) => setFormData({ ...formData, towerNo: e.target.value })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-sm font-medium text-slate-900"
              />
            </div>
          </div>

          {/* Row 2: Labour Name with suggestions & Unit-Wise Toggle */}
          <div className="bg-amber-50/70 p-3.5 rounded-xl border border-amber-200 space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="block text-xs font-bold text-amber-900 uppercase">
                Primary Labour / Mistri
              </label>
              <div className="flex items-center space-x-3">
                <label className="inline-flex items-center text-xs text-amber-900 font-bold cursor-pointer">
                  <input
                    type="checkbox"
                    checked={applySameLabour}
                    onChange={(e) => {
                      setApplySameLabour(e.target.checked);
                      if (e.target.checked) {
                        setFormData(applySameLabourToAllUnits(formData, formData.labourName || ''));
                      }
                    }}
                    className="rounded text-amber-600 focus:ring-amber-500 h-3.5 w-3.5 mr-1 cursor-pointer"
                  />
                  <span>Same labour for all units</span>
                </label>
              </div>
            </div>

            <div className="relative">
              <input
                id="modal-labour-name"
                type="text"
                value={formData.labourName}
                onChange={(e) => handleLabourChange(e.target.value)}
                placeholder="Enter labourer or contractor name"
                className="w-full bg-white border border-amber-300 rounded-lg p-2 text-sm font-bold text-slate-900 focus:ring-amber-500 focus:border-amber-500"
              />
            </div>

            {/* Quick Labour Suggestions */}
            <div className="flex flex-wrap items-center gap-1">
              <span className="text-[10px] text-amber-800 font-bold mr-1">Registered Labours:</span>
              {accounts.filter(acc => acc.role === 'labour').map((acc) => (
                <button
                  key={acc.id}
                  type="button"
                  onClick={() => handleLabourChange(acc.name)}
                  className="px-2 py-0.5 bg-white hover:bg-amber-100 text-amber-950 rounded text-[11px] font-bold border border-amber-200 transition cursor-pointer"
                >
                  {acc.name}
                </button>
              ))}
              {DEFAULT_LABOUR_SUGGESTIONS.slice(0, 3).map((name) => (
                <button
                  key={name}
                  type="button"
                  onClick={() => handleLabourChange(name)}
                  className="px-2 py-0.5 bg-white/70 hover:bg-amber-100 text-amber-900 rounded text-[10px] font-semibold border border-amber-200 transition cursor-pointer"
                >
                  {name.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Row 3: Unit Status & Labour Name Wise Entry */}
          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="text-xs font-black uppercase text-slate-800 block">
                  Labour-Wise Unit Status &amp; Assignments
                </span>
                <span className="text-[11px] text-slate-500">
                  {applySameLabour
                    ? 'All units currently assigned to primary labour. Uncheck "Same labour" to customize each unit.'
                    : 'Custom Labour Name per Unit active. Set labour name individually for each unit below.'}
                </span>
              </div>
              <div className="space-x-1.5 flex">
                <button
                  type="button"
                  onClick={handleMarkAllDone}
                  className="px-2 py-0.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 font-bold text-xs rounded border border-emerald-300 transition cursor-pointer"
                >
                  All Paid
                </button>
                <button
                  type="button"
                  onClick={handleMarkAllPending}
                  className="px-2 py-0.5 bg-amber-100 hover:bg-amber-200 text-amber-800 font-bold text-xs rounded border border-amber-300 transition cursor-pointer"
                >
                  All Pending
                </button>
                <button
                  type="button"
                  onClick={handleMarkAllNone}
                  className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded border border-slate-300 transition cursor-pointer"
                >
                  Clear All
                </button>
              </div>
            </div>

            {/* Units Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
              {UNIT_CONFIG_MAP.map(({ key, label, configKey }) => {
                const unitKeyStr = String(key);
                const st = (formData[key] as UnitStatus) || 'none';
                const isPaid = st === 'paid';
                const isPending = st === 'pending';
                const isNone = st === 'none';
                const unitLabour = formData.unitLabours?.[unitKeyStr] || formData.labourName || '';

                return (
                  <div
                    key={unitKeyStr}
                    className={`p-2.5 rounded-xl border flex flex-col justify-between transition ${
                      isPaid
                        ? 'bg-emerald-50/70 border-emerald-300 ring-1 ring-emerald-400/20'
                        : isPending
                        ? 'bg-amber-50/70 border-amber-300 ring-1 ring-amber-400/20'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    {/* Top: Unit Label & Status Toggle */}
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-black text-xs text-slate-900">{label}</span>
                      <button
                        type="button"
                        onClick={() => handleUnitToggle(key)}
                        className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase transition cursor-pointer ${
                          isPaid
                            ? 'bg-emerald-600 text-white shadow-xs'
                            : isPending
                            ? 'bg-amber-500 text-slate-950 shadow-xs'
                            : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                        }`}
                      >
                        {isPaid ? 'Pid Bill' : isPending ? 'Pending' : 'None'}
                      </button>
                    </div>

                    <div className="text-[10px] text-slate-500 font-medium mb-1.5">
                      {typeof sqftConfig[configKey] === 'number' ? (sqftConfig[configKey] as number) : 0} sqft
                    </div>

                    {/* Unit-Wise Labour Name Entry */}
                    <div className="mt-auto pt-1 border-t border-slate-200/80">
                      <label className="text-[9px] font-bold text-slate-600 uppercase block mb-0.5">
                        Labour Name:
                      </label>
                      <input
                        type="text"
                        value={unitLabour}
                        disabled={applySameLabour}
                        onChange={(e) => {
                          const newUnitLabours = { ...(formData.unitLabours || {}) };
                          newUnitLabours[unitKeyStr] = e.target.value;
                          setFormData({
                            ...formData,
                            unitLabours: newUnitLabours,
                          });
                        }}
                        placeholder="Labour name..."
                        className={`w-full text-xs font-bold px-2 py-1 rounded border transition ${
                          applySameLabour
                            ? 'bg-slate-100 text-slate-500 border-slate-200 cursor-not-allowed'
                            : 'bg-white text-amber-950 border-amber-300 focus:ring-1 focus:ring-amber-500 focus:outline-hidden'
                        }`}
                      />

                      {!applySameLabour && (
                        <div className="flex flex-wrap gap-0.5 mt-1">
                          {accounts
                            .filter((a) => a.role === 'labour')
                            .slice(0, 2)
                            .map((acc) => (
                              <button
                                key={acc.id}
                                type="button"
                                onClick={() => {
                                  const newUnitLabours = { ...(formData.unitLabours || {}) };
                                  newUnitLabours[unitKeyStr] = acc.name;
                                  setFormData({ ...formData, unitLabours: newUnitLabours });
                                }}
                                className="px-1 py-0.2 bg-white text-[9px] font-bold text-amber-900 rounded border border-amber-200 hover:bg-amber-100 transition cursor-pointer"
                              >
                                {acc.name.split(' ')[0]}
                              </button>
                            ))}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Row 4: Release, Hold, Paid Qty (Auto-computed with manual override) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
            <div>
              <label className="block text-xs font-bold text-sky-800 uppercase mb-1">
                Release Qty (100%)
              </label>
              <input
                id="modal-release-qty"
                type="number"
                value={formData.releaseQuantity}
                onChange={(e) => setFormData({ ...formData, releaseQuantity: Number(e.target.value) })}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-sm font-bold text-sky-950"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-rose-800 uppercase mb-1">
                Hold Qty (20%)
              </label>
              <input
                id="modal-hold-qty"
                type="number"
                value={formData.holdQuantity}
                onChange={(e) => setFormData({ ...formData, holdQuantity: Number(e.target.value) })}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-sm font-bold text-rose-950"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-teal-800 uppercase mb-1">
                Paid Qty (80%)
              </label>
              <input
                id="modal-paid-qty"
                type="number"
                value={formData.paidQuantity}
                onChange={(e) => setFormData({ ...formData, paidQuantity: Number(e.target.value) })}
                className="w-full bg-white border border-slate-300 rounded-lg p-2 text-sm font-black text-teal-950"
              />
            </div>
          </div>

          {/* Row 5: Site Verifications & Remarks */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-0.5">
                Verify Flats
              </label>
              <input
                type="number"
                min="0"
                max="8"
                value={formData.verifyFlats}
                onChange={(e) => setFormData({ ...formData, verifyFlats: Number(e.target.value) })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-center"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-0.5">
                Verify Lobby
              </label>
              <input
                type="number"
                min="0"
                max="1"
                value={formData.verifyLobby}
                onChange={(e) => setFormData({ ...formData, verifyLobby: Number(e.target.value) })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-center"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-0.5">
                Starc 1 WC
              </label>
              <input
                type="number"
                min="0"
                max="1"
                value={formData.verifyStar1}
                onChange={(e) => setFormData({ ...formData, verifyStar1: Number(e.target.value) })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-center"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-0.5">
                Starc 2 WC
              </label>
              <input
                type="number"
                min="0"
                max="1"
                value={formData.verifyStar2}
                onChange={(e) => setFormData({ ...formData, verifyStar2: Number(e.target.value) })}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-1.5 text-xs font-bold text-center"
              />
            </div>
          </div>

          {/* Row 6: Billing & PDF Export / Print Status */}
          <div className="p-3 bg-sky-50/60 rounded-xl border border-sky-200 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase text-sky-950 flex items-center space-x-1.5">
                <FileDown className="w-3.5 h-3.5 text-sky-700" />
                <span>Bill Tracking &amp; Export Status</span>
              </span>
              <span className="text-[10px] text-sky-700 font-semibold">
                Shown as visual badge in Table View
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() =>
                  setFormData({
                    ...formData,
                    billExportStatus: 'pending',
                    isBillExported: false,
                    isBillPrinted: false,
                  })
                }
                className={`p-2 rounded-lg text-center text-xs font-bold border transition ${
                  !formData.billExportStatus || formData.billExportStatus === 'pending'
                    ? 'bg-slate-200 text-slate-800 border-slate-400 shadow-xs'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Clock className="w-3.5 h-3.5 mx-auto mb-1 text-slate-500" />
                <span>Pending Bill</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setFormData({
                    ...formData,
                    billExportStatus: 'exported',
                    isBillExported: true,
                    isBillPrinted: false,
                    billExportDate: formData.billExportDate || new Date().toISOString(),
                  })
                }
                className={`p-2 rounded-lg text-center text-xs font-bold border transition ${
                  formData.billExportStatus === 'exported'
                    ? 'bg-sky-600 text-white border-sky-700 shadow-xs'
                    : 'bg-white text-sky-800 border-sky-200 hover:bg-sky-50'
                }`}
              >
                <FileDown className="w-3.5 h-3.5 mx-auto mb-1" />
                <span>PDF Exported</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setFormData({
                    ...formData,
                    billExportStatus: 'printed',
                    isBillExported: false,
                    isBillPrinted: true,
                    billExportDate: formData.billExportDate || new Date().toISOString(),
                  })
                }
                className={`p-2 rounded-lg text-center text-xs font-bold border transition ${
                  formData.billExportStatus === 'printed'
                    ? 'bg-indigo-600 text-white border-indigo-700 shadow-xs'
                    : 'bg-white text-indigo-800 border-indigo-200 hover:bg-indigo-50'
                }`}
              >
                <Printer className="w-3.5 h-3.5 mx-auto mb-1" />
                <span>Printed</span>
              </button>

              <button
                type="button"
                onClick={() =>
                  setFormData({
                    ...formData,
                    billExportStatus: 'both',
                    isBillExported: true,
                    isBillPrinted: true,
                    billExportDate: formData.billExportDate || new Date().toISOString(),
                  })
                }
                className={`p-2 rounded-lg text-center text-xs font-bold border transition ${
                  formData.billExportStatus === 'both'
                    ? 'bg-emerald-600 text-white border-emerald-700 shadow-xs'
                    : 'bg-white text-emerald-800 border-emerald-200 hover:bg-emerald-50'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5 mx-auto mb-1" />
                <span>PDF &amp; Printed</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <div>
                <label className="block text-[10px] font-bold text-sky-900 uppercase mb-0.5">
                  Bill Reference No.
                </label>
                <input
                  type="text"
                  value={formData.billNumber || ''}
                  onChange={(e) => setFormData({ ...formData, billNumber: e.target.value })}
                  placeholder={`BILL-${formData.towerNo || 'T2'}-FL${formData.floorNo}`}
                  className="w-full bg-white border border-sky-300 rounded-lg p-1.5 text-xs text-slate-900"
                />
              </div>
              <div>
                <label className="block text-[10px] font-bold text-sky-900 uppercase mb-0.5">
                  Export / Print Date
                </label>
                <input
                  type="date"
                  value={formData.billExportDate ? formData.billExportDate.slice(0, 10) : ''}
                  onChange={(e) => setFormData({ ...formData, billExportDate: e.target.value })}
                  className="w-full bg-white border border-sky-300 rounded-lg p-1.5 text-xs text-slate-900"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
              Remarks &amp; Notes
            </label>
            <input
              id="modal-remarks"
              type="text"
              value={formData.remarks || ''}
              onChange={(e) => setFormData({ ...formData, remarks: e.target.value })}
              placeholder="e.g. Gypsum work verified by site supervisor Adel"
              className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-xs text-slate-900"
            />
          </div>

          {/* Form Actions */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-lg transition"
            >
              Cancel
            </button>
            <button
              id="save-floor-entry-btn"
              type="submit"
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-lg shadow-md transition"
            >
              Save Floor Entry
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
