import { FloorEntry, UnitSqftConfig, MonthlyLabourSummaryData, LabourFloorEfficiency } from '../types';

export const getUnitSqftValue = (key: string, sqftConfig: UnitSqftConfig): number => {
  const val = sqftConfig[key as keyof UnitSqftConfig];
  return typeof val === 'number' ? val : Number(val) || 0;
};

// Calculate standard sqft for 1 complete floor (all 11 units)
export const getStandardFloorSqft = (sqftConfig: UnitSqftConfig): number => {
  const sum =
    getUnitSqftValue('unit1', sqftConfig) +
    getUnitSqftValue('unit2', sqftConfig) +
    getUnitSqftValue('unit3', sqftConfig) +
    getUnitSqftValue('unit4', sqftConfig) +
    getUnitSqftValue('unit5', sqftConfig) +
    getUnitSqftValue('unit6', sqftConfig) +
    getUnitSqftValue('unit7', sqftConfig) +
    getUnitSqftValue('unit8', sqftConfig) +
    getUnitSqftValue('lobby', sqftConfig) +
    getUnitSqftValue('starc1', sqftConfig) +
    getUnitSqftValue('starc2', sqftConfig);
  return sum > 0 ? sum : 12608;
};

// Helper to format "2026-09" to "Sep 2026"
export const formatMonthLabel = (monthKey: string): { short: string; full: string } => {
  if (!monthKey) return { short: 'Current', full: 'Current Period' };
  const parts = monthKey.split('-');
  if (parts.length === 2) {
    const year = parts[0];
    const monthIndex = parseInt(parts[1], 10) - 1;
    const date = new Date(parseInt(year, 10), monthIndex, 1);
    if (!isNaN(date.getTime())) {
      const short = date.toLocaleString('en-US', { month: 'short', year: 'numeric' });
      const full = date.toLocaleString('en-US', { month: 'long', year: 'numeric' });
      return { short, full };
    }
  }
  return { short: monthKey, full: monthKey };
};

// Fallback month allocator for realistic timeline if floor has no explicit month
export const getFloorDefaultMonth = (floor: FloorEntry): string => {
  if (floor.month && floor.month.trim()) {
    return floor.month.trim();
  }
  if (floor.date && floor.date.length >= 7) {
    return floor.date.slice(0, 7);
  }
  // Distribution based on floor number for realistic project timeline (May 2026 - Oct 2026)
  const fStr = (floor.floorNo || '').toLowerCase().trim();
  if (fStr.includes('ground') || fStr === 'g' || fStr === '0') return '2026-05';
  const fNum = parseInt(fStr.replace(/\D/g, ''), 10);
  if (isNaN(fNum)) return '2026-09';
  if (fNum <= 5) return '2026-05';
  if (fNum <= 10) return '2026-06';
  if (fNum <= 16) return '2026-07';
  if (fNum <= 22) return '2026-08';
  if (fNum <= 28) return '2026-09';
  return '2026-10';
};

export interface MonthlyAggregationResult {
  monthlyData: MonthlyLabourSummaryData[];
  overallTotals: {
    totalGrossLabourCost: number;
    totalNetLabourCost: number;
    totalPaidAmount: number;
    totalPendingAmount: number;
    totalCompletedSqft: number;
    totalTargetSqft: number;
    overallCompletionRate: number;
    totalFloorsCompleted: number;
    totalUnitsCompleted: number;
    monthsCount: number;
    avgMonthlyCost: number;
    avgMonthlySqft: number;
    avgFloorCompletionRatePerLabour: number;
  };
  labourRanking: Array<{
    labourName: string;
    totalSqft: number;
    totalCost: number;
    unitsDone: number;
    sharePercentage: number;
    totalEquivalentFloors: number;
    distinctFloorsCount: number;
    avgFloorsPerMonth: number;
  }>;
  labourEfficiency: LabourFloorEfficiency[];
}

export const aggregateMonthlySummary = (
  floors: FloorEntry[],
  sqftConfig: UnitSqftConfig,
  defaultRatePerSqft: number = 22,
  towerFilter: string = 'all',
  labourFilter: string = 'all'
): MonthlyAggregationResult => {
  const standardFloorSqft = getStandardFloorSqft(sqftConfig);

  // 1. Filter floors by tower if specified
  const filteredFloors = floors.filter((f) => {
    if (towerFilter === 'all') return true;
    return f.towerNo && f.towerNo.trim().toLowerCase() === towerFilter.trim().toLowerCase();
  });

  // 2. Group by month
  const monthMap: Record<
    string,
    {
      floors: FloorEntry[];
      labourMap: Record<
        string,
        {
          sqft: number;
          cost: number;
          unitsCount: number;
          floorsSet: Set<string>;
        }
      >;
    }
  > = {};

  filteredFloors.forEach((floor) => {
    const monthKey = getFloorDefaultMonth(floor);
    if (!monthMap[monthKey]) {
      monthMap[monthKey] = {
        floors: [],
        labourMap: {},
      };
    }
    monthMap[monthKey].floors.push(floor);

    // Calculate labour work per unit for this floor
    const defaultLabour = floor.labourName?.trim() || 'Ramesh Mistri';
    const unitKeys = [
      { key: 'unit1', label: 'Unit 1', status: floor.unit1 },
      { key: 'unit2', label: 'Unit 2', status: floor.unit2 },
      { key: 'unit3', label: 'Unit 3', status: floor.unit3 },
      { key: 'unit4', label: 'Unit 4', status: floor.unit4 },
      { key: 'unit5', label: 'Unit 5', status: floor.unit5 },
      { key: 'unit6', label: 'Unit 6', status: floor.unit6 },
      { key: 'unit7', label: 'Unit 7', status: floor.unit7 },
      { key: 'unit8', label: 'Unit 8', status: floor.unit8 },
      { key: 'lobby', label: 'Lobby', status: floor.lobby },
      { key: 'starc1', label: 'Starc 1', status: floor.starc1 },
      { key: 'starc2', label: 'Starc 2', status: floor.starc2 },
    ];

    unitKeys.forEach((u) => {
      if (u.status === 'paid') {
        const unitLabour = floor.unitLabours?.[u.key]?.trim() || defaultLabour;
        
        // Filter by labour if specified
        if (labourFilter !== 'all' && unitLabour.toLowerCase() !== labourFilter.toLowerCase()) {
          return;
        }

        const sqft = getUnitSqftValue(u.key, sqftConfig);
        const cost = sqft * defaultRatePerSqft;

        if (!monthMap[monthKey].labourMap[unitLabour]) {
          monthMap[monthKey].labourMap[unitLabour] = {
            sqft: 0,
            cost: 0,
            unitsCount: 0,
            floorsSet: new Set<string>(),
          };
        }
        monthMap[monthKey].labourMap[unitLabour].sqft += sqft;
        monthMap[monthKey].labourMap[unitLabour].cost += cost;
        monthMap[monthKey].labourMap[unitLabour].unitsCount += 1;
        monthMap[monthKey].labourMap[unitLabour].floorsSet.add(floor.floorNo);
      }
    });
  });

  // 3. Sort months chronologically
  const sortedMonthKeys = Object.keys(monthMap).sort();

  let overallGrossCost = 0;
  let overallNetCost = 0;
  let overallPaidAmount = 0;
  let overallCompletedSqft = 0;
  let overallTargetSqft = 0;
  let overallFloorsCompleted = 0;
  let overallUnitsCompleted = 0;

  // Track overall stats per labour across all months
  const allLabourTotalsMap: Record<
    string,
    {
      sqft: number;
      cost: number;
      unitsDone: number;
      floorsSet: Set<string>;
      monthlyHistory: Record<
        string,
        {
          monthKey: string;
          monthLabel: string;
          equivalentFloors: number;
          distinctFloors: number;
          unitsDone: number;
          sqft: number;
          cost: number;
        }
      >;
    }
  > = {};

  const monthlyData: MonthlyLabourSummaryData[] = sortedMonthKeys.map((mKey) => {
    const item = monthMap[mKey];
    const { short, full } = formatMonthLabel(mKey);

    let mCompletedSqft = 0;
    let mTargetSqft = 0;
    let mHoldSqft = 0;
    let mUnitsCount = 0;
    const floorsList: string[] = [];

    item.floors.forEach((f) => {
      floorsList.push(f.floorNo);
      mCompletedSqft += Number(f.paidQuantity || 0);
      mTargetSqft += Number(f.releaseQuantity || 0);
      mHoldSqft += Number(f.holdQuantity || 0);

      // Count completed units
      const paidUnits = [
        f.unit1,
        f.unit2,
        f.unit3,
        f.unit4,
        f.unit5,
        f.unit6,
        f.unit7,
        f.unit8,
        f.lobby,
        f.starc1,
        f.starc2,
      ].filter((s) => s === 'paid').length;
      mUnitsCount += paidUnits;
    });

    const grossLabourCost = mCompletedSqft * defaultRatePerSqft;
    // 20% standard security hold for contractor settlement
    const holdDeductions = Math.round(grossLabourCost * 0.2);
    const netLabourCost = grossLabourCost - holdDeductions;
    // Paid amount (estimate based on completion, 80% cleared)
    const paidAmount = netLabourCost;
    const pendingAmount = grossLabourCost - paidAmount;

    // Convert labour breakdown
    const labourBreakdown = Object.entries(item.labourMap).map(([lName, lData]) => {
      if (!allLabourTotalsMap[lName]) {
        allLabourTotalsMap[lName] = {
          sqft: 0,
          cost: 0,
          unitsDone: 0,
          floorsSet: new Set<string>(),
          monthlyHistory: {},
        };
      }
      allLabourTotalsMap[lName].sqft += lData.sqft;
      allLabourTotalsMap[lName].cost += lData.cost;
      allLabourTotalsMap[lName].unitsDone += lData.unitsCount;
      lData.floorsSet.forEach((fNo) => allLabourTotalsMap[lName].floorsSet.add(fNo));

      // Calculate equivalent floors: standard floor sqft based or 11 units per floor
      const equivalentFloors =
        standardFloorSqft > 0
          ? Number((lData.sqft / standardFloorSqft).toFixed(2))
          : Number((lData.unitsCount / 11).toFixed(2));

      allLabourTotalsMap[lName].monthlyHistory[mKey] = {
        monthKey: mKey,
        monthLabel: short,
        equivalentFloors,
        distinctFloors: lData.floorsSet.size,
        unitsDone: lData.unitsCount,
        sqft: lData.sqft,
        cost: lData.cost,
      };

      return {
        labourName: lName,
        sqft: lData.sqft,
        cost: lData.cost,
        unitsCount: lData.unitsCount,
        equivalentFloors,
        floorsInvolved: lData.floorsSet.size,
        floorsList: Array.from(lData.floorsSet),
      };
    });

    const completionRate = mTargetSqft > 0 ? Number(((mCompletedSqft / mTargetSqft) * 100).toFixed(1)) : 0;

    overallGrossCost += grossLabourCost;
    overallNetCost += netLabourCost;
    overallPaidAmount += paidAmount;
    overallCompletedSqft += mCompletedSqft;
    overallTargetSqft += mTargetSqft;
    overallFloorsCompleted += item.floors.filter((f) => f.paidQuantity > 0).length;
    overallUnitsCompleted += mUnitsCount;

    return {
      monthKey: mKey,
      monthLabel: short,
      fullMonthName: full,
      totalSqft: mCompletedSqft,
      targetSqft: mTargetSqft,
      completionRate,
      floorsCount: item.floors.length,
      floorsList,
      unitsCount: mUnitsCount,
      grossLabourCost,
      advanceDeductions: 0,
      holdDeductions,
      netLabourCost,
      paidAmount,
      pendingAmount,
      labourBreakdown,
    };
  });

  const monthsCount = monthlyData.length || 1;

  // Build Labour Floor Efficiency analytics for all labourers over time
  const labourEfficiency: LabourFloorEfficiency[] = Object.entries(allLabourTotalsMap).map(
    ([labourName, data]) => {
      const distinctFloorsList = Array.from(data.floorsSet).sort((a, b) => {
        const numA = parseInt(a.replace(/\D/g, ''), 10) || 0;
        const numB = parseInt(b.replace(/\D/g, ''), 10) || 0;
        return numA - numB;
      });

      const totalEquivalentFloors =
        standardFloorSqft > 0
          ? Number((data.sqft / standardFloorSqft).toFixed(2))
          : Number((data.unitsDone / 11).toFixed(2));

      const activeMonthsCount = Object.keys(data.monthlyHistory).length || 1;
      const avgFloorsPerMonth = Number((totalEquivalentFloors / activeMonthsCount).toFixed(2));
      const avgSqftPerMonth = Math.round(data.sqft / activeMonthsCount);

      // Monthly rate chronology with change percentage
      const monthlyRates = sortedMonthKeys.map((mKey, idx) => {
        const { short } = formatMonthLabel(mKey);
        const record = data.monthlyHistory[mKey] || {
          monthKey: mKey,
          monthLabel: short,
          equivalentFloors: 0,
          distinctFloors: 0,
          unitsDone: 0,
          sqft: 0,
          cost: 0,
        };

        let changeFromPrevMonthPercent: number | undefined = undefined;
        if (idx > 0) {
          const prevKey = sortedMonthKeys[idx - 1];
          const prevRecord = data.monthlyHistory[prevKey];
          if (prevRecord && prevRecord.equivalentFloors > 0) {
            changeFromPrevMonthPercent = Number(
              (
                ((record.equivalentFloors - prevRecord.equivalentFloors) / prevRecord.equivalentFloors) *
                100
              ).toFixed(0)
            );
          }
        }

        return {
          ...record,
          changeFromPrevMonthPercent,
        };
      });

      // Find peak month
      let peak = { monthLabel: 'N/A', floors: 0, sqft: 0 };
      monthlyRates.forEach((m) => {
        if (m.equivalentFloors > peak.floors) {
          peak = { monthLabel: m.monthLabel, floors: m.equivalentFloors, sqft: m.sqft };
        }
      });

      // Determine pace & status
      let paceStatus = 'Steady Pace';
      let paceColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
      if (avgFloorsPerMonth >= 2.5) {
        paceStatus = 'Fast Track Velocity';
        paceColor = 'text-amber-800 bg-amber-50 border-amber-300';
      } else if (avgFloorsPerMonth >= 1.5) {
        paceStatus = 'High Efficiency';
        paceColor = 'text-teal-800 bg-teal-50 border-teal-300';
      } else if (avgFloorsPerMonth < 0.8) {
        paceStatus = 'Moderate Pace';
        paceColor = 'text-slate-700 bg-slate-100 border-slate-300';
      }

      // Trend analysis
      const nonZeroRates = monthlyRates.filter((m) => m.equivalentFloors > 0);
      let trend: 'improving' | 'stable' | 'declining' = 'stable';
      if (nonZeroRates.length >= 2) {
        const last = nonZeroRates[nonZeroRates.length - 1].equivalentFloors;
        const prev = nonZeroRates[nonZeroRates.length - 2].equivalentFloors;
        if (last > prev * 1.1) trend = 'improving';
        else if (last < prev * 0.9) trend = 'declining';
      }

      const sharePercentage =
        overallCompletedSqft > 0 ? Number(((data.sqft / overallCompletedSqft) * 100).toFixed(1)) : 0;

      return {
        labourName,
        totalEquivalentFloors,
        distinctFloorsCount: data.floorsSet.size,
        distinctFloorsList,
        totalUnitsDone: data.unitsDone,
        totalSqft: data.sqft,
        totalCost: data.cost,
        activeMonthsCount,
        avgFloorsPerMonth,
        avgSqftPerMonth,
        monthlyRates,
        peakMonth: peak,
        paceStatus,
        paceColor,
        trend,
        sharePercentage,
      };
    }
  );

  // Sort labour efficiency by highest total equivalent floors completed
  labourEfficiency.sort((a, b) => b.totalEquivalentFloors - a.totalEquivalentFloors);

  // Calculate labour ranking share
  const labourRanking = labourEfficiency.map((l) => ({
    labourName: l.labourName,
    totalSqft: l.totalSqft,
    totalCost: l.totalCost,
    unitsDone: l.totalUnitsDone,
    sharePercentage: l.sharePercentage,
    totalEquivalentFloors: l.totalEquivalentFloors,
    distinctFloorsCount: l.distinctFloorsCount,
    avgFloorsPerMonth: l.avgFloorsPerMonth,
  }));

  const overallCompletionRate =
    overallTargetSqft > 0 ? Number(((overallCompletedSqft / overallTargetSqft) * 100).toFixed(1)) : 0;

  const totalLabourCount = labourEfficiency.length || 1;
  const avgFloorCompletionRatePerLabour = Number(
    (
      labourEfficiency.reduce((acc, l) => acc + l.avgFloorsPerMonth, 0) / totalLabourCount
    ).toFixed(2)
  );

  return {
    monthlyData,
    overallTotals: {
      totalGrossLabourCost: overallGrossCost,
      totalNetLabourCost: overallNetCost,
      totalPaidAmount: overallPaidAmount,
      totalPendingAmount: Math.max(0, overallGrossCost - overallPaidAmount),
      totalCompletedSqft: overallCompletedSqft,
      totalTargetSqft: overallTargetSqft,
      overallCompletionRate,
      totalFloorsCompleted: overallFloorsCompleted,
      totalUnitsCompleted: overallUnitsCompleted,
      monthsCount,
      avgMonthlyCost: Math.round(overallGrossCost / monthsCount),
      avgMonthlySqft: Math.round(overallCompletedSqft / monthsCount),
      avgFloorCompletionRatePerLabour,
    },
    labourRanking,
    labourEfficiency,
  };
};

export interface MonthlyCardSummary {
  monthKey: string;
  monthName: string;
  totalFloors: number;
  completedFloors: number;
  inProgressFloors: number;
  totalReleaseQty: number;
  totalHoldQty: number;
  totalPaidQty: number;
  verifiedFlats: number;
  gypsumRunningFlats: number;
  gypsumRunningLobby: number;
  status: 'Draft' | 'Submitted' | 'Approved' | 'Paid';
}

export const aggregateMonthlySummaries = (
  floors: FloorEntry[],
  sqftConfig: UnitSqftConfig
): MonthlyCardSummary[] => {
  const groups: Record<string, FloorEntry[]> = {};
  floors.forEach((f) => {
    const m = getFloorDefaultMonth(f);
    if (!groups[m]) groups[m] = [];
    groups[m].push(f);
  });

  const keys = Object.keys(groups).sort();
  return keys.map((k) => {
    const list = groups[k];
    const { full } = formatMonthLabel(k);
    let completed = 0;
    let inProgress = 0;
    let rel = 0;
    let hld = 0;
    let pd = 0;
    let vFlats = 0;
    let rFlats = 0;
    let rLobby = 0;

    list.forEach((f) => {
      const isDone = f.paidQuantity > 0 && f.unit1 === 'paid' && f.unit8 === 'paid';
      if (isDone) completed++;
      else inProgress++;

      rel += Number(f.releaseQuantity || 0);
      hld += Number(f.holdQuantity || 0);
      pd += Number(f.paidQuantity || 0);
      vFlats += Number(f.verifyFlats || 0);
      rFlats += Number(f.gypsumRunningFlats || 0);
      rLobby += Number(f.gypsumRunningLobby || 0);
    });

    const status: 'Draft' | 'Submitted' | 'Approved' | 'Paid' =
      completed > 0 ? (completed === list.length ? 'Approved' : 'Submitted') : 'Draft';

    return {
      monthKey: k,
      monthName: full,
      totalFloors: list.length,
      completedFloors: completed,
      inProgressFloors: inProgress,
      totalReleaseQty: rel,
      totalHoldQty: hld,
      totalPaidQty: pd,
      verifiedFlats: vFlats,
      gypsumRunningFlats: rFlats,
      gypsumRunningLobby: rLobby,
      status,
    };
  });
};
