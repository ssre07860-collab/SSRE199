import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import html2canvas from 'html2canvas-pro';
import { BillHeader, FloorEntry, UnitSqftConfig } from '../types';
import { getUnitLabourName } from './labourBillHelper';
import { deduplicateFloors } from './towerHelper';

export interface PDFGeneratorOptions {
  fitToPage?: boolean;
  margin?: number;
  scale?: number;
  format?: 'a3' | 'a4';
  showLabourInUnits?: boolean;
}

/**
 * Generate a crystal-clear, high-definition Vector PDF with exact status colors and multi-page formatting
 */
export function generateVectorSummaryPDF(
  header: BillHeader,
  sqftConfig: UnitSqftConfig,
  floors: FloorEntry[],
  filename: string = 'Gypsum_Bill_Record_Summary.pdf',
  options: PDFGeneratorOptions = {}
): boolean {
  try {
    const { format = 'a3', showLabourInUnits = true } = options;
    const uniqueFloors = deduplicateFloors(floors);
    const doc = new jsPDF({
      orientation: 'landscape',
      unit: 'mm',
      format: format,
    });

    const pageWidth = doc.internal.pageSize.getWidth();

    // 1. Header Box & Titles
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('GYPSUM BILL RECORD', pageWidth / 2, 12, { align: 'center' });
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text('SUMMARY SHEET (WITH LABOUR-WISE UNIT DETAILS)', pageWidth / 2, 17, { align: 'center' });

    // Left info block
    doc.setFontSize(8.5);
    doc.text(`Subcontractor: ${header.scName || 'SSR ENTERPRISES'}`, 10, 10);
    doc.text(`Work: ${header.workType || 'Gypsum Work'}   |   Tower: ${header.towerNo || 'Tower 2'}`, 10, 14.5);
    doc.setFont('helvetica', 'normal');
    doc.text(`Project: ${header.projectName || 'Prestige Lavender Field'}`, 10, 19);

    // Right info block
    doc.setFont('helvetica', 'bold');
    doc.text(`Date: ${header.date || new Date().toLocaleDateString('en-GB')}`, pageWidth - 10, 10, { align: 'right' });
    doc.setFont('helvetica', 'normal');
    doc.text(`Total Floors: ${uniqueFloors.length}`, pageWidth - 10, 14.5, { align: 'right' });

    // 2. Prepare Table Columns & Headers
    const headRow1 = [
      { content: 'S/C Name', rowSpan: 2 },
      { content: 'Tower', rowSpan: 2 },
      { content: 'Floor', rowSpan: 2 },
      { content: 'Flats No', rowSpan: 2 },
      { content: 'Labour / Mistri', rowSpan: 2 },
      { content: 'UNIT No 1' },
      { content: 'UNIT No 2' },
      { content: 'UNIT No 3' },
      { content: 'UNIT No 4' },
      { content: 'UNIT No 5' },
      { content: 'UNIT No 6' },
      { content: 'UNIT No 7' },
      { content: 'UNIT No 8' },
      { content: 'Lobby' },
      { content: 'Starc 1' },
      { content: 'Starc 2' },
      { content: 'Release Qty (100%)', rowSpan: 2 },
      { content: 'Hold Qty (20%)', rowSpan: 2 },
      { content: 'Paid Qty (80%)', rowSpan: 2 },
      { content: 'Gypsum Ranning Flats', rowSpan: 2 },
      { content: 'Gypsum Ranning Lobby', rowSpan: 2 },
      { content: 'Starches/1 W/C', rowSpan: 2 },
      { content: 'Starches/2 W/C', rowSpan: 2 },
      { content: 'Flats', rowSpan: 2 },
      { content: 'Lobby', rowSpan: 2 },
      { content: 'Star 1', rowSpan: 2 },
      { content: 'Star 2', rowSpan: 2 },
      { content: 'Remarks', rowSpan: 2 },
      { content: 'Signature', rowSpan: 2 },
    ];

    const headRow2 = [
      { content: `Sqft ${sqftConfig.unit1 || 3700}` },
      { content: `Sqft ${sqftConfig.unit2 || 1934}` },
      { content: `Sqft ${sqftConfig.unit3 || 2334}` },
      { content: `Sqft ${sqftConfig.unit4 || 2334}` },
      { content: `Sqft ${sqftConfig.unit5 || 2465}` },
      { content: `Sqft ${sqftConfig.unit6 || 2465}` },
      { content: `Sqft ${sqftConfig.unit7 || 2465}` },
      { content: `Sqft ${sqftConfig.unit8 || 1665}` },
      { content: `Sqft ${sqftConfig.lobby || 1500}` },
      { content: `Sqft ${sqftConfig.starc1 || 480}` },
      { content: `Sqft ${sqftConfig.starc2 || 480}` },
    ];

    // Compute Totals
    let totRel = 0;
    let totHold = 0;
    let totPaid = 0;
    let totRFlats = 0;
    let totRLobby = 0;
    let totRStar1 = 0;
    let totRStar2 = 0;
    let totVFlats = 0;
    let totVLobby = 0;
    let totVStar1 = 0;
    let totVStar2 = 0;

    const unitKeys = [
      'unit1',
      'unit2',
      'unit3',
      'unit4',
      'unit5',
      'unit6',
      'unit7',
      'unit8',
      'lobby',
      'starc1',
      'starc2',
    ] as const;

    // Build Table Body
    const bodyRows = uniqueFloors.map((row) => {
      totRel += Number(row.releaseQuantity || 0);
      totHold += Number(row.holdQuantity || 0);
      totPaid += Number(row.paidQuantity || 0);
      totRFlats += Number(row.gypsumRunningFlats || 0);
      totRLobby += Number(row.gypsumRunningLobby || 0);
      totRStar1 += Number(row.starches1WC || 0);
      totRStar2 += Number(row.starches2WC || 0);
      totVFlats += Number(row.verifyFlats || 0);
      totVLobby += Number(row.verifyLobby || 0);
      totVStar1 += Number(row.verifyStar1 || 0);
      totVStar2 += Number(row.verifyStar2 || 0);

      const unitCells = unitKeys.map((k) => {
        const st = row[k];
        const lab = getUnitLabourName(row, k) || row.labourName || '';
        const isPaid = st === 'paid';
        const isPending = st === 'pending';
        let text = '';
        if (isPaid) {
          text = showLabourInUnits && lab ? `Pid Bill\n${lab}` : 'Pid Bill';
        } else if (isPending) {
          text = showLabourInUnits && lab ? `Pending\n${lab}` : 'Pending';
        }
        return {
          content: text,
          styles: {
            fillColor: isPaid ? ([22, 112, 93] as [number, number, number]) : isPending ? ([254, 240, 138] as [number, number, number]) : ([255, 255, 255] as [number, number, number]),
            textColor: isPaid ? ([255, 255, 255] as [number, number, number]) : ([15, 23, 42] as [number, number, number]),
            fontStyle: (isPaid ? 'bold' : 'normal') as 'bold' | 'normal',
            halign: 'center' as const,
            valign: 'middle' as const,
          },
        };
      });

      return [
        { content: row.scName || header.scName || 'SSR', styles: { fontStyle: 'bold' as const, halign: 'center' as const } },
        { content: row.towerNo || header.towerNo || 'T2', styles: { fontStyle: 'bold' as const, halign: 'center' as const } },
        { content: String(row.floorNo), styles: { fontStyle: 'bold' as const, halign: 'center' as const, fillColor: [248, 250, 252] as [number, number, number] } },
        { content: row.flatsNo || '', styles: { halign: 'left' as const } },
        { content: row.labourName || 'Adil Ahmad', styles: { fontStyle: 'bold' as const, halign: 'center' as const, fillColor: [254, 243, 199] as [number, number, number], textColor: [120, 53, 15] as [number, number, number] } },
        ...unitCells,
        { content: (row.releaseQuantity || 0).toLocaleString('en-IN'), styles: { fillColor: [125, 211, 252] as [number, number, number], halign: 'right' as const, fontStyle: 'bold' as const } },
        { content: (row.holdQuantity || 0).toLocaleString('en-IN'), styles: { fillColor: [252, 165, 165] as [number, number, number], halign: 'right' as const, fontStyle: 'bold' as const } },
        { content: (row.paidQuantity || 0).toLocaleString('en-IN'), styles: { fillColor: [186, 230, 253] as [number, number, number], halign: 'right' as const, fontStyle: 'bold' as const } },
        { content: String(row.gypsumRunningFlats || 0), styles: { halign: 'center' as const, fontStyle: 'bold' as const } },
        { content: String(row.gypsumRunningLobby || 0), styles: { halign: 'center' as const, fontStyle: 'bold' as const } },
        { content: String(row.starches1WC || 0), styles: { halign: 'center' as const, fontStyle: 'bold' as const } },
        { content: String(row.starches2WC || 0), styles: { halign: 'center' as const, fontStyle: 'bold' as const } },
        { content: String(row.verifyFlats || 0), styles: { halign: 'center' as const, fillColor: row.verifyFlats > 0 ? ([187, 247, 208] as [number, number, number]) : ([255, 255, 255] as [number, number, number]), fontStyle: 'bold' as const } },
        { content: String(row.verifyLobby || 0), styles: { halign: 'center' as const, fillColor: row.verifyLobby > 0 ? ([187, 247, 208] as [number, number, number]) : ([255, 255, 255] as [number, number, number]), fontStyle: 'bold' as const } },
        { content: String(row.verifyStar1 || 0), styles: { halign: 'center' as const, fillColor: row.verifyStar1 > 0 ? ([187, 247, 208] as [number, number, number]) : ([255, 255, 255] as [number, number, number]), fontStyle: 'bold' as const } },
        { content: String(row.verifyStar2 || 0), styles: { halign: 'center' as const, fillColor: row.verifyStar2 > 0 ? ([187, 247, 208] as [number, number, number]) : ([255, 255, 255] as [number, number, number]), fontStyle: 'bold' as const } },
        { content: row.remarks || '', styles: { halign: 'center' as const } },
        { content: row.signature || '', styles: { halign: 'center' as const, fontStyle: 'italic' as const } },
      ];
    });

    // Totals Row
    const totalsRow = [
      { content: 'TOTAL', colSpan: 16, styles: { halign: 'right' as const, fontStyle: 'bold' as const, fillColor: [241, 245, 249] as [number, number, number] } },
      { content: totRel.toLocaleString('en-IN'), styles: { fillColor: [125, 211, 252] as [number, number, number], halign: 'right' as const, fontStyle: 'bold' as const } },
      { content: totHold.toLocaleString('en-IN'), styles: { fillColor: [252, 165, 165] as [number, number, number], halign: 'right' as const, fontStyle: 'bold' as const } },
      { content: totPaid.toLocaleString('en-IN'), styles: { fillColor: [186, 230, 253] as [number, number, number], halign: 'right' as const, fontStyle: 'bold' as const } },
      { content: String(totRFlats), styles: { halign: 'center' as const, fontStyle: 'bold' as const } },
      { content: String(totRLobby), styles: { halign: 'center' as const, fontStyle: 'bold' as const } },
      { content: String(totRStar1), styles: { halign: 'center' as const, fontStyle: 'bold' as const } },
      { content: String(totRStar2), styles: { halign: 'center' as const, fontStyle: 'bold' as const } },
      { content: String(totVFlats), styles: { halign: 'center' as const, fillColor: [187, 247, 208] as [number, number, number], fontStyle: 'bold' as const } },
      { content: String(totVLobby), styles: { halign: 'center' as const, fillColor: [187, 247, 208] as [number, number, number], fontStyle: 'bold' as const } },
      { content: String(totVStar1), styles: { halign: 'center' as const, fillColor: [187, 247, 208] as [number, number, number], fontStyle: 'bold' as const } },
      { content: String(totVStar2), styles: { halign: 'center' as const, fillColor: [187, 247, 208] as [number, number, number], fontStyle: 'bold' as const } },
      { content: '', styles: { halign: 'center' as const } },
      { content: '', styles: { halign: 'center' as const } },
    ];

    autoTable(doc, {
      startY: 23,
      head: [headRow1, headRow2],
      body: [...bodyRows, totalsRow],
      theme: 'grid',
      styles: {
        fontSize: format === 'a3' ? 6.5 : 5,
        cellPadding: format === 'a3' ? 1.0 : 0.6,
        lineColor: [0, 0, 0],
        lineWidth: 0.2,
        textColor: [0, 0, 0],
        font: 'helvetica',
      },
      headStyles: {
        fillColor: [255, 255, 255],
        textColor: [0, 0, 0],
        fontStyle: 'bold',
        halign: 'center',
        valign: 'middle',
        lineWidth: 0.2,
        lineColor: [0, 0, 0],
      },
      columnStyles: {
        0: { cellWidth: format === 'a3' ? 14 : 9 }, // S/C Name
        1: { cellWidth: format === 'a3' ? 9 : 6 },  // Tower
        2: { cellWidth: format === 'a3' ? 10 : 7 }, // Floor
        3: { cellWidth: format === 'a3' ? 22 : 14 }, // Flats No
        4: { cellWidth: format === 'a3' ? 18 : 12 }, // Labour Name
      },
      margin: { top: 22, left: 6, right: 6, bottom: 20 },
      pageBreak: 'auto',
      didDrawPage: (data) => {
        // Footer on each page
        const pageCount = doc.getNumberOfPages();
        const currentPg = data.pageNumber;
        doc.setFontSize(7.5);
        doc.setFont('helvetica', 'normal');
        doc.text(
          `Prestige Lavender Field - Gypsum Bill Record | Page ${currentPg} of ${pageCount}`,
          pageWidth / 2,
          doc.internal.pageSize.getHeight() - 6,
          { align: 'center' }
        );
      },
    });

    // Signatures at the end
    const lastPageHeight = doc.internal.pageSize.getHeight();
    // @ts-expect-error autoTable finalY position
    const finalY = (doc.lastAutoTable && doc.lastAutoTable.finalY) || 200;
    if (finalY < lastPageHeight - 25) {
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text(header.supervisorSignature || 'Adel', 15, finalY + 12);
      doc.line(15, finalY + 13.5, 65, finalY + 13.5);
      doc.setFontSize(7.5);
      doc.text('Approved by site supervisor', 15, finalY + 17);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text(header.contractorSignature || 'Rizwan', pageWidth - 65, finalY + 12);
      doc.line(pageWidth - 65, finalY + 13.5, pageWidth - 15, finalY + 13.5);
      doc.setFontSize(7.5);
      doc.text('For SSR ENTERPRISES', pageWidth - 65, finalY + 17);
    }

    doc.save(filename);
    return true;
  } catch (err) {
    console.error('Vector PDF generation error:', err);
    return false;
  }
}

/**
 * Capture a single DOM element to an HTML5 canvas at ultra-high DPI
 */
async function captureElementToCanvas(
  element: HTMLElement,
  scale: number = 3,
  orientation: 'portrait' | 'landscape' = 'landscape'
): Promise<HTMLCanvasElement> {
  const minWidth = orientation === 'landscape' ? 1220 : 820;
  const naturalWidth = Math.max(element.scrollWidth, element.offsetWidth, minWidth);
  const naturalHeight = Math.max(element.scrollHeight, element.offsetHeight);

  return await html2canvas(element, {
    scale: scale,
    useCORS: true,
    allowTaint: true,
    logging: false,
    backgroundColor: '#ffffff',
    width: naturalWidth,
    height: naturalHeight,
    windowWidth: naturalWidth + 60,
    windowHeight: naturalHeight + 60,
    onclone: (_clonedDoc, clonedElement) => {
      clonedElement.style.transform = 'none';
      clonedElement.style.boxShadow = 'none';
      clonedElement.style.margin = '0';
      clonedElement.style.maxWidth = 'none';
      clonedElement.style.width = `${naturalWidth}px`;
      let ancestor = clonedElement.parentElement;
      while (ancestor && ancestor !== _clonedDoc.body) {
        ancestor.style.transform = 'none';
        ancestor.style.overflow = 'visible';
        ancestor.style.boxShadow = 'none';
        ancestor = ancestor.parentElement;
      }
    },
  });
}

/**
 * Generate a high-resolution, perfectly leveled PDF document
 * Supports both single elements and multi-page element arrays
 */
export async function generateInstantPDF(
  elementIds: string | string[],
  filename: string = 'Summary_Bill_Record_Prestige_Tower2.pdf',
  orientation: 'portrait' | 'landscape' = 'landscape',
  options: PDFGeneratorOptions = {}
): Promise<boolean> {
  const ids = Array.isArray(elementIds) ? elementIds : [elementIds];
  const elements = ids.map((id) => document.getElementById(id)).filter(Boolean) as HTMLElement[];

  if (elements.length === 0) {
    console.error(`None of the elements found for IDs:`, elementIds);
    return false;
  }

  const { fitToPage = true, margin = 5, scale = 3 } = options;

  try {
    const pdf = new jsPDF({
      orientation: orientation,
      unit: 'mm',
      format: 'a4',
      compress: true,
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();
    const availWidth = pdfWidth - margin * 2;
    const availHeight = pdfHeight - margin * 2;

    for (let i = 0; i < elements.length; i++) {
      const el = elements[i];
      if (i > 0) {
        pdf.addPage(undefined, orientation);
      }

      const canvas = await captureElementToCanvas(el, scale, orientation);
      const canvasWidth = canvas.width;
      const canvasHeight = canvas.height;
      const canvasAspect = canvasWidth / canvasHeight;
      const pageAspect = availWidth / availHeight;

      if (fitToPage || elements.length > 1 || canvasHeight / canvasWidth <= 1.4) {
        let finalWidth: number;
        let finalHeight: number;

        if (canvasAspect > pageAspect) {
          finalWidth = availWidth;
          finalHeight = availWidth / canvasAspect;
        } else {
          finalHeight = availHeight;
          finalWidth = availHeight * canvasAspect;
        }

        const xOffset = (pdfWidth - finalWidth) / 2;
        const yOffset = (pdfHeight - finalHeight) / 2;

        const imgData = canvas.toDataURL('image/png', 1.0);
        pdf.addImage(imgData, 'PNG', xOffset, yOffset, finalWidth, finalHeight, undefined, 'FAST');
      } else {
        const sliceHeightPx = Math.floor((availHeight / availWidth) * canvasWidth);
        let remainingHeightPx = canvasHeight;
        let currentYPx = 0;
        let pageIndex = 0;

        while (remainingHeightPx > 0) {
          if (pageIndex > 0) {
            pdf.addPage(undefined, orientation);
          }

          const currentSliceHeightPx = Math.min(sliceHeightPx, remainingHeightPx);
          const sliceCanvas = document.createElement('canvas');
          sliceCanvas.width = canvasWidth;
          sliceCanvas.height = currentSliceHeightPx;
          const ctx = sliceCanvas.getContext('2d');
          if (ctx) {
            ctx.fillStyle = '#ffffff';
            ctx.fillRect(0, 0, sliceCanvas.width, sliceCanvas.height);
            ctx.drawImage(
              canvas,
              0,
              currentYPx,
              canvasWidth,
              currentSliceHeightPx,
              0,
              0,
              canvasWidth,
              currentSliceHeightPx
            );

            const sliceImgData = sliceCanvas.toDataURL('image/png', 1.0);
            const sliceRenderHeight = (currentSliceHeightPx / canvasWidth) * availWidth;
            const xOffset = (pdfWidth - availWidth) / 2;
            const yOffset = margin;

            pdf.addImage(sliceImgData, 'PNG', xOffset, yOffset, availWidth, sliceRenderHeight, undefined, 'FAST');
          }

          currentYPx += currentSliceHeightPx;
          remainingHeightPx -= currentSliceHeightPx;
          pageIndex++;
        }
      }
    }

    pdf.save(filename);
    return true;
  } catch (err) {
    console.error('PDF Generation failed:', err);
    window.print();
    return false;
  }
}

/**
 * Generate a single-floor vector PDF summary bill voucher
 */
export function generateSingleFloorVectorPDF(
  header: BillHeader,
  sqftConfig: UnitSqftConfig,
  floor: FloorEntry,
  format: 'a3' | 'a4' = 'a4'
): boolean {
  const safeTower = (floor.towerNo || header.towerNo || 'Tower').replace(/\s+/g, '_');
  const filename = `Gypsum_Bill_${safeTower}_Floor_${floor.floorNo}_${format.toUpperCase()}.pdf`;
  return generateVectorSummaryPDF(header, sqftConfig, [floor], filename, {
    format,
    showLabourInUnits: true,
  });
}

