import React, { useState } from 'react';
import {
  X,
  Shield,
  User,
  CheckCircle2,
  Lock,
  UserCheck,
  AlertCircle,
  Building,
} from 'lucide-react';
import { UserRole, UserAccessInfo, UserAccount } from '../types';
import { isOwnerEmail } from '../utils/labourAccountHelper';

interface UserRoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  userAccess: UserAccessInfo;
  onSwitchRole: (role: UserRole, labourName?: string) => void;
  availableLabours: string[];
  accounts: UserAccount[];
  onApproveAccount?: (accountId: string) => void;
  onOpenOwnerAdminModal?: () => void;
}

export const UserRoleModal: React.FC<UserRoleModalProps> = ({
  isOpen,
  onClose,
  userAccess,
  onSwitchRole,
  availableLabours,
  accounts,
  onApproveAccount,
  onOpenOwnerAdminModal,
}) => {
  // Resolve actual authenticated identity permissions
  const userEmail = userAccess.userAccount?.email || '';
  const isOwner = userEmail ? isOwnerEmail(userEmail) : false;
  const matchedAccount = accounts.find(
    (a) => a.email.trim().toLowerCase() === userEmail.trim().toLowerCase()
  );
  const actualRole = isOwner ? 'owner' : matchedAccount ? matchedAccount.role : null;

  const isLockedAsLabour = actualRole === 'labour';
  const isLockedAsSupervisor = actualRole === 'supervisor';

  const [selectedRole, setSelectedRole] = useState<UserRole>(
    isLockedAsLabour ? 'labour' : userAccess.role
  );
  const [selectedLabourName, setSelectedLabourName] = useState<string>(
    userAccess.labourName || availableLabours[0] || 'Adil Ahmad'
  );

  if (!isOpen) return null;

  const handleApply = () => {
    onSwitchRole(selectedRole, selectedRole === 'labour' ? selectedLabourName : undefined);
    onClose();
  };

  const handleSelectRole = (role: UserRole) => {
    if (isLockedAsLabour) {
      // Strictly locked
      return;
    }
    if (isLockedAsSupervisor && role === 'owner') {
      // Supervisor cannot view owner panel
      return;
    }
    setSelectedRole(role);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-black">Role &amp; Account Access Control</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-5 overflow-y-auto flex-1 text-xs">
          {/* Strict Role Isolation Warning / Label */}
          {isLockedAsLabour && (
            <div className="bg-rose-50 border border-rose-200 text-rose-900 p-3.5 rounded-xl flex items-start space-x-2.5">
              <Lock className="w-4 h-4 text-rose-600 shrink-0 mt-0.5 animate-pulse" />
              <div>
                <span className="font-bold block text-xs">Strict Isolation Mapped (सख्त व्यक्तिगत नियंत्रण)</span>
                <span className="text-[11px] text-rose-700 block mt-0.5">
                  Your Google Profile <span className="font-mono font-bold text-rose-950">{userEmail}</span> is mapped to a verified Field Labour profile. You are restricted strictly to your personal workspace.
                </span>
              </div>
            </div>
          )}

          {isLockedAsSupervisor && (
            <div className="bg-sky-50 border border-sky-200 text-sky-900 p-3.5 rounded-xl flex items-start space-x-2.5">
              <Lock className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold block text-xs">Supervisor Mode (पर्यवेक्षक मोड)</span>
                <span className="text-[11px] text-sky-700 block mt-0.5">
                  Logged in as Site Supervisor. Access restricted to Daily Entry and Labour view-only previews. Owner configuration is locked.
                </span>
              </div>
            </div>
          )}

          {/* Active Status Box */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 flex items-center justify-between">
            <div>
              <span className="text-[11px] text-slate-500 uppercase font-bold block">Current Active Role</span>
              <span className="text-sm font-black text-slate-900 capitalize flex items-center space-x-1.5 mt-0.5">
                <span>{userAccess.role}</span>
                {userAccess.isLabour && userAccess.labourName && (
                  <span className="text-xs text-amber-700 font-bold">({userAccess.labourName})</span>
                )}
              </span>
            </div>
            <span
              className={`px-2.5 py-1 rounded-full text-xs font-black uppercase ${
                userAccess.isOwner
                  ? 'bg-amber-100 text-amber-900 border border-amber-300'
                  : userAccess.isSupervisor
                  ? 'bg-sky-100 text-sky-900 border border-sky-300'
                  : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
              }`}
            >
              {userAccess.canEdit ? 'Read & Write' : 'View-Only'}
            </span>
          </div>

          {/* Role Selection Cards */}
          <div>
            <label className="block text-xs font-bold uppercase text-slate-600 mb-2">
              Select Role to Operate / Preview:
            </label>

            <div className="space-y-2">
              {/* Owner */}
              <div
                onClick={() => handleSelectRole('owner')}
                className={`p-3 rounded-xl border cursor-pointer transition ${
                  isLockedAsLabour || isLockedAsSupervisor
                    ? 'opacity-40 cursor-not-allowed bg-slate-50 border-slate-200'
                    : selectedRole === 'owner'
                    ? 'bg-amber-50 border-amber-400 text-amber-950 ring-1 ring-amber-400'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Shield className="w-4 h-4 text-amber-600" />
                    <span className="text-sm font-black">Owner / Super Contractor</span>
                    {(isLockedAsLabour || isLockedAsSupervisor) && <Lock className="w-3.5 h-3.5 text-slate-400" />}
                  </div>
                  {selectedRole === 'owner' && <CheckCircle2 className="w-4 h-4 text-amber-600" />}
                </div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Full administrative authority: edit floor progress, manage site towers, configure bill headers &amp; rates, approve labour vouchers, and export vector PDFs.
                </p>
              </div>

              {/* Site Supervisor */}
              <div
                onClick={() => handleSelectRole('supervisor')}
                className={`p-3 rounded-xl border cursor-pointer transition ${
                  isLockedAsLabour
                    ? 'opacity-40 cursor-not-allowed bg-slate-50 border-slate-200'
                    : selectedRole === 'supervisor'
                    ? 'bg-sky-50 border-sky-400 text-sky-950 ring-1 ring-sky-400'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Building className="w-4 h-4 text-sky-600" />
                    <span className="text-sm font-black">Site Supervisor</span>
                    {isLockedAsLabour && <Lock className="w-3.5 h-3.5 text-slate-400" />}
                  </div>
                  {selectedRole === 'supervisor' && <CheckCircle2 className="w-4 h-4 text-sky-600" />}
                </div>
                <p className="text-[11px] text-slate-600 mt-1">
                  Daily floor entry, unit plastering status toggles, flat &amp; lobby verification counts, supervisor signature signing.
                </p>
              </div>

              {/* Labour / Mistri View */}
              <div
                onClick={() => handleSelectRole('labour')}
                className={`p-3 rounded-xl border cursor-pointer transition ${
                  selectedRole === 'labour'
                    ? 'bg-emerald-50 border-emerald-400 text-emerald-950 ring-1 ring-emerald-400'
                    : 'bg-white border-slate-200 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <User className="w-4 h-4 text-emerald-600" />
                    <span className="text-sm font-black">Labour / Contractor Team</span>
                  </div>
                  {selectedRole === 'labour' && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                </div>
                <p className="text-[11px] text-slate-600 mt-1">
                  View-Only portal. Displays measured square footage, gross amounts, retention hold, and payment vouchers.
                </p>

                {/* If Labour selected, pick which labour name */}
                {selectedRole === 'labour' && (
                  <div className="mt-2 pt-2 border-t border-emerald-200" onClick={(e) => e.stopPropagation()}>
                    <label className="block text-[11px] font-bold text-emerald-900 mb-1">
                      Choose Labourer Identity:
                    </label>
                    <select
                      value={selectedLabourName}
                      onChange={(e) => setSelectedLabourName(e.target.value)}
                      className="w-full bg-white border border-emerald-300 rounded-lg p-2 font-bold text-slate-900 text-xs"
                    >
                      {availableLabours.map((l) => (
                        <option key={l} value={l}>
                          {l}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* User Accounts Overview (for Owner) */}
          {accounts.length > 0 && userAccess.isOwner && (
            <div className="pt-3 border-t border-slate-200">
              <h4 className="text-xs font-bold uppercase text-slate-600 mb-2">
                Registered Site Profiles ({accounts.length})
              </h4>
              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                {accounts.map((acc) => (
                  <div
                    key={acc.id}
                    className="p-2 rounded-lg bg-slate-50 border border-slate-200 flex items-center justify-between text-[11px]"
                  >
                    <div>
                      <span className="font-bold text-slate-800">{acc.name}</span>
                      <span className="text-slate-500 ml-1.5">({acc.email})</span>
                      <span className="block text-[10px] text-slate-400 capitalize">{acc.role}</span>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        acc.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {acc.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div>
            {onOpenOwnerAdminModal && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenOwnerAdminModal();
                }}
                className="px-3 py-1.5 bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300 font-black text-xs rounded-lg transition"
              >
                Launch Owner Admin Center →
              </button>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-lg border border-slate-200 transition"
            >
              Cancel
            </button>
            <button
              id="apply-role-switch-btn"
              type="button"
              onClick={handleApply}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-lg shadow-md transition"
            >
              Switch Role
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
