import React, { useState } from 'react';
import {
  X,
  Building2,
  PlusCircle,
  CheckCircle,
  Layers,
} from 'lucide-react';

interface TowerManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
  availableTowers: string[];
  activeTower: string;
  onSelectTower: (tower: string) => void;
  onAddTower: (towerName: string, floorCount: number) => void;
}

export const TowerManagementModal: React.FC<TowerManagementModalProps> = ({
  isOpen,
  onClose,
  availableTowers,
  activeTower,
  onSelectTower,
  onAddTower,
}) => {
  const [newTowerName, setNewTowerName] = useState('');
  const [floorCount, setFloorCount] = useState(26);

  if (!isOpen) return null;

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTowerName.trim()) return;
    onAddTower(newTowerName.trim(), floorCount);
    setNewTowerName('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-black">Manage Site Towers</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-5">
          {/* Active Towers List */}
          <div>
            <label className="block text-xs font-bold uppercase text-slate-500 mb-2">
              Existing Project Towers
            </label>
            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {availableTowers.map((tower) => (
                <div
                  key={tower}
                  onClick={() => onSelectTower(tower)}
                  className={`p-2.5 rounded-lg border flex items-center justify-between cursor-pointer transition ${
                    activeTower === tower
                      ? 'bg-emerald-50 border-emerald-400 text-emerald-950 font-bold'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <Building2 className="w-4 h-4 text-emerald-600" />
                    <span className="text-sm">{tower}</span>
                  </div>
                  {activeTower === tower && (
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded">
                      Active
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Add New Tower Form */}
          <form onSubmit={handleCreate} className="pt-4 border-t border-slate-200 space-y-3">
            <h3 className="text-xs font-bold uppercase text-slate-700">
              Add Extra Tower &amp; Initialize Floors
            </h3>

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                Tower Name / Number
              </label>
              <input
                type="text"
                required
                placeholder="e.g. Tower 1, Tower 3, Tower 4"
                value={newTowerName}
                onChange={(e) => setNewTowerName(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-sm font-bold text-slate-900 focus:ring-emerald-500 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">
                Initial Number of Floors
              </label>
              <input
                type="number"
                min="1"
                max="60"
                value={floorCount}
                onChange={(e) => setFloorCount(Number(e.target.value))}
                className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-sm font-bold text-slate-900"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Floors 1st to {floorCount}th will be automatically generated with standard 8 units + lobby + starcases.
              </p>
            </div>

            <div className="pt-2 flex justify-end space-x-2">
              <button
                type="button"
                onClick={onClose}
                className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-lg transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center space-x-1.5 px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-lg shadow-xs transition"
              >
                <PlusCircle className="w-4 h-4" />
                <span>Create Tower</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
