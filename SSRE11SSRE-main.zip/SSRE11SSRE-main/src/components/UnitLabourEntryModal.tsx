import React, { useState, useMemo } from 'react';
import {
  X,
  Users,
  CheckCircle2,
  Building,
  Save,
  Check,
  Filter,
  ArrowRight,
  Layers,
  Sparkles,
  UserCheck,
} from 'lucide-react';
import { FloorEntry, UnitSqftConfig, UnitStatus, UserAccount } from '../types';
import { UNIT_CONFIG_MAP, toggleSingleUnitStatus, toggleFloorCompletedStatus } from '../utils/floorCalculationHelper';
import {
  getUnitLabourName,
  getUniqueLabourNames,
  DEFAULT_LABOUR_SUGGESTIONS,
} from '../utils/labourBillHelper';

interface UnitLabourEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  floors: FloorEntry[];
  activeTower: string;
  sqftConfig: UnitSqftConfig;
  accounts: UserAccount[];
  initialFloorId?: string;
  initialUnitKey?: string;
  onSaveFloor: (updatedFloor: FloorEntry) => void;
  onSaveAllFloors?: (updatedFloors: FloorEntry[]) => void;
}

export const UnitLabourEntryModal: React.FC<UnitLabourEntryModalProps> = ({
  isOpen,
  onClose,
  floors,
  activeTower,
  sqftConfig,
  accounts,
  initialFloorId,
  initialUnitKey,
  onSaveFloor,
  onSaveAllFloors,
}) => {
  // Available registered labours & suggestions
  const registeredLabours = useMemo(() => {
    const list: string[] = accounts
      .filter((a) => a.role === 'labour')
      .map((a) => a.name.trim())
      .filter(Boolean);

    getUniqueLabourNames(floors).forEach((name) => {
      if (!list.includes(name)) list.push(name);
    });

    DEFAULT_LABOUR_SUGGESTIONS.forEach((name) => {
      if (!list.includes(name)) list.push(name);
    });

    return list;
  }, [accounts, floors]);

  // Tower floors sorted
  const towerFloors = useMemo(() => {
    return floors.filter((f) => (f.towerNo || 'Tower 2') === (activeTower || 'Tower 2'));
  }, [floors, activeTower]);

  // Selected Floor ID
  const [selectedFloorId, setSelectedFloorId] = useState<string>(() => {
    if (initialFloorId && towerFloors.some((f) => f.id === initialFloorId)) {
      return initialFloorId;
    }
    return towerFloors[0]?.id || '';
  });

  // Entry Mode: 'single-floor' (floor by floor) vs 'batch-assign' (pick labour and assign to units)
  const [activeMode, setActiveMode] = useState<'single-floor' | 'batch-assign'>('single-floor');

  // Single-floor working floor state
  const currentFloor = useMemo(() => {
    return towerFloors.find((f) => f.id === selectedFloorId) || towerFloors[0] || null;
  }, [towerFloors, selectedFloorId]);

  const [workingFloor, setWorkingFloor] = useState<FloorEntry | null>(null);

  // Sync working floor when selected floor changes
  React.useEffect(() => {
    if (currentFloor) {
      setWorkingFloor({
        ...currentFloor,
        unitLabours: { ...(currentFloor.unitLabours || {}) },
      });
    }
  }, [currentFloor]);

  // Batch Assignment State
  const [batchLabourName, setBatchLabourName] = useState<string>(registeredLabours[0] || 'Adil Ahmad');
  const [batchStatus, setBatchStatus] = useState<UnitStatus | 'keep'>('paid');
  const [batchSelectedFloorIds, setBatchSelectedFloorIds] = useState<string[]>([]);
  const [batchSelectedUnitKeys, setBatchSelectedUnitKeys] = useState<string[]>(
    initialUnitKey ? [initialUnitKey] : ['unit1', 'unit2', 'unit3', 'unit4']
  );
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  // Change single unit's labour in single floor mode
  const handleUnitLabourChange = (unitKey: string, labourName: string) => {
    if (!workingFloor) return;
    const currentUnitLabours = { ...(workingFloor.unitLabours || {}) };
    currentUnitLabours[unitKey] = labourName.trim();
    setWorkingFloor({
      ...workingFloor,
      unitLabours: currentUnitLabours,
    });
  };

  // Change single unit's status in single floor mode
  const handleUnitStatusChange = (unitKey: keyof FloorEntry, newStatus: UnitStatus) => {
    if (!workingFloor) return;
    const updated = toggleSingleUnitStatus(workingFloor, unitKey, sqftConfig);
    // If the toggle didn't land on newStatus, we set directly
    (updated[unitKey] as any) = newStatus;
    setWorkingFloor(updated);
  };

  // Quick Apply Same Labour to ALL units on working floor
  const handleApplySameToAllUnits = (labourName: string) => {
    if (!workingFloor) return;
    const newUnitLabours: Record<string, string> = {};
    UNIT_CONFIG_MAP.forEach(({ key }) => {
      newUnitLabours[String(key)] = labourName;
    });
    setWorkingFloor({
      ...workingFloor,
      labourName,
      unitLabours: newUnitLabours,
    });
  };

  // Save current working floor
  const handleSaveWorkingFloor = () => {
    if (!workingFloor) return;
    onSaveFloor(workingFloor);
    setSaveSuccessNotice(`Saved Floor ${workingFloor.floorNo} unit labour assignments!`);
    setTimeout(() => setSaveSuccessNotice(null), 3000);
  };

  // Execute Batch Assignment across selected floors & units
  const handleExecuteBatchAssign = () => {
    if (batchSelectedFloorIds.length === 0) {
      alert('Please select at least one floor for batch assignment.');
      return;
    }
    if (batchSelectedUnitKeys.length === 0) {
      alert('Please select at least one unit for batch assignment.');
      return;
    }
    if (!batchLabourName.trim()) {
      alert('Please select or enter a labour name.');
      return;
    }

    const updatedFloors: FloorEntry[] = [];

    towerFloors.forEach((fl) => {
      if (batchSelectedFloorIds.includes(fl.id)) {
        const newUnitLabours = { ...(fl.unitLabours || {}) };
        const updated = { ...fl };

        batchSelectedUnitKeys.forEach((uk) => {
          newUnitLabours[uk] = batchLabourName.trim();
          if (batchStatus !== 'keep') {
            (updated[uk as keyof FloorEntry] as any) = batchStatus;
          }
        });

        updated.unitLabours = newUnitLabours;
        const recalc = toggleFloorCompletedStatus(updated, sqftConfig, batchStatus === 'paid');
        updatedFloors.push(recalc);
        onSaveFloor(recalc);
      }
    });

    if (onSaveAllFloors) {
      onSaveAllFloors(updatedFloors);
    }

    setSaveSuccessNotice(
      `Assigned "${batchLabourName}" to ${batchSelectedUnitKeys.length} units across ${batchSelectedFloorIds.length} floors!`
    );
    setTimeout(() => {
      setSaveSuccessNotice(null);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 text-white rounded-2xl shadow-2xl w-full max-w-4xl my-6 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center font-black">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h2 className="text-base font-black text-white">Labour-Wise Unit Entry</h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase">
                  {activeTower}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Assign specific Labour / Mistri for each Unit (Unit 1 to 8, Lobby, Starc 1 &amp; 2)
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Switcher Tabs */}
        <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between gap-2 shrink-0">
          <div className="flex items-center space-x-2">
            <button
              type="button"
              onClick={() => setActiveMode('single-floor')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer ${
                activeMode === 'single-floor'
                  ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Floor-by-Floor Unit Entry</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveMode('batch-assign')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer ${
                activeMode === 'batch-assign'
                  ? 'bg-amber-500 text-slate-950 font-black shadow-xs'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>Batch Assign Labour to Units</span>
            </button>
          </div>

          {saveSuccessNotice && (
            <div className="flex items-center space-x-1 text-emerald-400 text-xs font-bold animate-in fade-in">
              <CheckCircle2 className="w-4 h-4" />
              <span>{saveSuccessNotice}</span>
            </div>
          )}
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-5 flex-1">
          {/* ================================================================= */}
          {/* MODE 1: SINGLE FLOOR UNIT-BY-UNIT LABOUR ENTRY                   */}
          {/* ================================================================= */}
          {activeMode === 'single-floor' && workingFloor && (
            <div className="space-y-4">
              {/* Floor Selector & Primary Labour Info */}
              <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-2">
                  <label className="text-xs font-bold text-slate-400">Select Floor:</label>
                  <select
                    value={selectedFloorId}
                    onChange={(e) => setSelectedFloorId(e.target.value)}
                    className="bg-slate-900 border border-slate-700 text-amber-400 font-black text-xs rounded-lg px-3 py-1.5 focus:outline-hidden"
                  >
                    {towerFloors.map((f) => (
                      <option key={f.id} value={f.id}>
                        {f.floorNo} Floor ({f.flatsNo || 'Flats'})
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center space-x-2">
                  <span className="text-xs text-slate-400 font-semibold">Copy Labour to All Units:</span>
                  <div className="flex flex-wrap gap-1">
                    {registeredLabours.slice(0, 4).map((labour) => (
                      <button
                        key={labour}
                        type="button"
                        onClick={() => handleApplySameToAllUnits(labour)}
                        className="px-2 py-1 bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200 text-[11px] font-bold rounded-lg border border-slate-700 transition"
                      >
                        All: {labour.split(' ')[0]}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* 11 Unit Cards Grid with Labour Selector */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {UNIT_CONFIG_MAP.map(({ key, label, configKey }) => {
                  const unitKeyStr = String(key);
                  const currentStatus = (workingFloor[key] as UnitStatus) || 'none';
                  const currentLabour = getUnitLabourName(workingFloor, unitKeyStr);
                  const sqft = Number(sqftConfig[configKey] || 0);

                  const isPaid = currentStatus === 'paid';
                  const isPending = currentStatus === 'pending';

                  return (
                    <div
                      key={unitKeyStr}
                      className={`p-3 rounded-xl border transition ${
                        isPaid
                          ? 'bg-slate-950 border-emerald-500/40 ring-1 ring-emerald-500/20'
                          : isPending
                          ? 'bg-slate-950 border-amber-500/40 ring-1 ring-amber-500/20'
                          : 'bg-slate-950/60 border-slate-800'
                      }`}
                    >
                      {/* Unit Title & Status Selector */}
                      <div className="flex items-center justify-between mb-2">
                        <div>
                          <span className="font-black text-xs text-white">{label}</span>
                          <span className="text-[10px] text-slate-500 ml-1.5">({sqft} sqft)</span>
                        </div>

                        {/* Status Toggle buttons */}
                        <div className="flex space-x-1">
                          <button
                            type="button"
                            onClick={() => handleUnitStatusChange(key, 'paid')}
                            title="Mark as Paid / Pid Bill"
                            className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase transition ${
                              isPaid
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'bg-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            Pid Bill
                          </button>
                          <button
                            type="button"
                            onClick={() => handleUnitStatusChange(key, 'pending')}
                            title="Mark as Pending"
                            className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase transition ${
                              isPending
                                ? 'bg-amber-500 text-slate-950 shadow-xs'
                                : 'bg-slate-800 text-slate-400 hover:text-white'
                            }`}
                          >
                            Pending
                          </button>
                          <button
                            type="button"
                            onClick={() => handleUnitStatusChange(key, 'none')}
                            title="Mark as None / Not Started"
                            className={`px-1.5 py-0.5 rounded text-[10px] font-black uppercase transition ${
                              currentStatus === 'none'
                                ? 'bg-slate-700 text-slate-200'
                                : 'bg-slate-800 text-slate-500 hover:text-white'
                            }`}
                          >
                            None
                          </button>
                        </div>
                      </div>

                      {/* Labour Name Input / Dropdown */}
                      <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-slate-400 block uppercase">
                          Labour / Mistri:
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            value={currentLabour}
                            onChange={(e) => handleUnitLabourChange(unitKeyStr, e.target.value)}
                            placeholder="Type or pick labour name..."
                            className="w-full bg-slate-900 border border-slate-700 text-amber-300 font-bold rounded-lg px-2.5 py-1.5 text-xs focus:border-amber-400 focus:outline-hidden"
                          />
                        </div>

                        {/* Quick pick suggestion chips */}
                        <div className="flex flex-wrap gap-1 pt-1">
                          {registeredLabours.slice(0, 3).map((name) => (
                            <button
                              key={name}
                              type="button"
                              onClick={() => handleUnitLabourChange(unitKeyStr, name)}
                              className={`px-1.5 py-0.5 rounded text-[9px] font-bold transition ${
                                currentLabour.toLowerCase() === name.toLowerCase()
                                  ? 'bg-amber-500 text-slate-950 font-black'
                                  : 'bg-slate-800 text-slate-400 hover:text-white'
                              }`}
                            >
                              {name.split(' ')[0]}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Bottom Actions */}
              <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
                <div className="text-xs text-slate-400 font-semibold">
                  Changes apply specifically to{' '}
                  <strong className="text-amber-400">{workingFloor.floorNo} Floor</strong> units.
                </div>

                <div className="flex items-center space-x-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition cursor-pointer"
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveWorkingFloor}
                    className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-md transition flex items-center space-x-1.5 cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>Save Floor Units</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* ================================================================= */}
          {/* MODE 2: BATCH ASSIGN LABOUR ACROSS FLOORS & UNITS                */}
          {/* ================================================================= */}
          {activeMode === 'batch-assign' && (
            <div className="space-y-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
              <div className="border-b border-slate-800 pb-3">
                <h3 className="text-sm font-black text-white">
                  Batch Assign Labour to Selected Units
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Select which labour performed which units across one or multiple floors.
                </p>
              </div>

              {/* 1. Pick Labour */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-300 uppercase block">
                  1. Select Labour Name:
                </label>
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={batchLabourName}
                    onChange={(e) => setBatchLabourName(e.target.value)}
                    className="bg-slate-900 border border-slate-700 text-amber-400 font-black text-xs rounded-lg px-3 py-2 focus:outline-hidden min-w-[200px]"
                  >
                    {registeredLabours.map((labour) => (
                      <option key={labour} value={labour}>
                        {labour}
                      </option>
                    ))}
                  </select>

                  <input
                    type="text"
                    value={batchLabourName}
                    onChange={(e) => setBatchLabourName(e.target.value)}
                    placeholder="Or type custom labour name"
                    className="bg-slate-900 border border-slate-700 text-white font-bold text-xs rounded-lg px-3 py-2 focus:border-amber-400 focus:outline-hidden flex-1 min-w-[180px]"
                  />
                </div>
              </div>

              {/* 2. Pick Unit(s) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300 uppercase">
                    2. Select Units to Assign:
                  </label>
                  <div className="space-x-1.5 text-xs">
                    <button
                      type="button"
                      onClick={() => setBatchSelectedUnitKeys(UNIT_CONFIG_MAP.map((u) => String(u.key)))}
                      className="text-amber-400 hover:underline font-bold text-[11px]"
                    >
                      Select All 11 Units
                    </button>
                    <span className="text-slate-600">&bull;</span>
                    <button
                      type="button"
                      onClick={() =>
                        setBatchSelectedUnitKeys([
                          'unit1',
                          'unit2',
                          'unit3',
                          'unit4',
                          'unit5',
                          'unit6',
                          'unit7',
                          'unit8',
                        ])
                      }
                      className="text-amber-400 hover:underline font-bold text-[11px]"
                    >
                      Only Flats (1-8)
                    </button>
                    <span className="text-slate-600">&bull;</span>
                    <button
                      type="button"
                      onClick={() => setBatchSelectedUnitKeys([])}
                      className="text-slate-400 hover:underline text-[11px]"
                    >
                      Clear
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
                  {UNIT_CONFIG_MAP.map(({ key, label }) => {
                    const unitKeyStr = String(key);
                    const isSelected = batchSelectedUnitKeys.includes(unitKeyStr);
                    return (
                      <button
                        key={unitKeyStr}
                        type="button"
                        onClick={() => {
                          if (isSelected) {
                            setBatchSelectedUnitKeys(batchSelectedUnitKeys.filter((k) => k !== unitKeyStr));
                          } else {
                            setBatchSelectedUnitKeys([...batchSelectedUnitKeys, unitKeyStr]);
                          }
                        }}
                        className={`p-2 rounded-lg text-xs font-bold border text-center transition cursor-pointer ${
                          isSelected
                            ? 'bg-amber-500 text-slate-950 border-amber-400 font-black shadow-xs'
                            : 'bg-slate-900 text-slate-400 border-slate-700 hover:bg-slate-800'
                        }`}
                      >
                        {label}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 3. Pick Floors */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300 uppercase">
                    3. Select Floors ({batchSelectedFloorIds.length} Selected):
                  </label>
                  <div className="space-x-1.5 text-xs">
                    <button
                      type="button"
                      onClick={() => setBatchSelectedFloorIds(towerFloors.map((f) => f.id))}
                      className="text-amber-400 hover:underline font-bold text-[11px]"
                    >
                      Select All Floors
                    </button>
                    <span className="text-slate-600">&bull;</span>
                    <button
                      type="button"
                      onClick={() => setBatchSelectedFloorIds([])}
                      className="text-slate-400 hover:underline text-[11px]"
                    >
                      Clear
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-4 sm:grid-cols-8 md:grid-cols-11 gap-1.5 max-h-40 overflow-y-auto p-2 bg-slate-900 rounded-lg border border-slate-800">
                  {towerFloors.map((fl) => {
                    const isSelected = batchSelectedFloorIds.includes(fl.id);
                    return (
                      <button
                        key={fl.id}
                        type="button"
                        onClick={() => {
                          if (isSelected) {
                            setBatchSelectedFloorIds(batchSelectedFloorIds.filter((id) => id !== fl.id));
                          } else {
                            setBatchSelectedFloorIds([...batchSelectedFloorIds, fl.id]);
                          }
                        }}
                        className={`py-1.5 px-1 rounded text-center text-xs font-bold border transition ${
                          isSelected
                            ? 'bg-emerald-600 text-white border-emerald-500 font-black shadow-xs'
                            : 'bg-slate-950 text-slate-400 border-slate-800 hover:bg-slate-800'
                        }`}
                      >
                        {fl.floorNo}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* 4. Unit Status Option */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-300 uppercase block">
                  4. Unit Billing Status to Set:
                </label>
                <div className="flex space-x-2">
                  <button
                    type="button"
                    onClick={() => setBatchStatus('paid')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition ${
                      batchStatus === 'paid'
                        ? 'bg-emerald-600 text-white border-emerald-500 font-black'
                        : 'bg-slate-900 text-slate-400 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    Paid / Pid Bill
                  </button>
                  <button
                    type="button"
                    onClick={() => setBatchStatus('pending')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition ${
                      batchStatus === 'pending'
                        ? 'bg-amber-500 text-slate-950 border-amber-400 font-black'
                        : 'bg-slate-900 text-slate-400 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    Pending
                  </button>
                  <button
                    type="button"
                    onClick={() => setBatchStatus('keep')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition ${
                      batchStatus === 'keep'
                        ? 'bg-sky-600 text-white border-sky-500 font-black'
                        : 'bg-slate-900 text-slate-400 border-slate-700 hover:bg-slate-800'
                    }`}
                  >
                    Keep Existing Status
                  </button>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-3 border-t border-slate-800 flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleExecuteBatchAssign}
                  className="px-6 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition flex items-center space-x-1.5 cursor-pointer"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>Assign Labour to Selected Units</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
