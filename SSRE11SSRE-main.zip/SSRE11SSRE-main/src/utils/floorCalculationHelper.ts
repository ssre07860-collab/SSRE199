import { FloorEntry, UnitSqftConfig, UnitStatus } from '../types';

export const UNIT_CONFIG_MAP: Array<{ key: keyof FloorEntry; configKey: keyof UnitSqftConfig; label: string }> = [
  { key: 'unit1', configKey: 'unit1', label: 'Unit 1' },
  { key: 'unit2', configKey: 'unit2', label: 'Unit 2' },
  { key: 'unit3', configKey: 'unit3', label: 'Unit 3' },
  { key: 'unit4', configKey: 'unit4', label: 'Unit 4' },
  { key: 'unit5', configKey: 'unit5', label: 'Unit 5' },
  { key: 'unit6', configKey: 'unit6', label: 'Unit 6' },
  { key: 'unit7', configKey: 'unit7', label: 'Unit 7' },
  { key: 'unit8', configKey: 'unit8', label: 'Unit 8' },
  { key: 'lobby', configKey: 'lobby', label: 'Lobby' },
  { key: 'starc1', configKey: 'starc1', label: 'Starc 1' },
  { key: 'starc2', configKey: 'starc2', label: 'Starc 2' },
];

/**
 * Dynamically retrieve active units list, considering inactive and custom extra units
 */
export const getActiveUnits = (sqftConfig?: UnitSqftConfig) => {
  const base = [
    { key: 'unit1' as keyof FloorEntry, configKey: 'unit1' as keyof UnitSqftConfig, label: 'Unit 1' },
    { key: 'unit2' as keyof FloorEntry, configKey: 'unit2' as keyof UnitSqftConfig, label: 'Unit 2' },
    { key: 'unit3' as keyof FloorEntry, configKey: 'unit3' as keyof UnitSqftConfig, label: 'Unit 3' },
    { key: 'unit4' as keyof FloorEntry, configKey: 'unit4' as keyof UnitSqftConfig, label: 'Unit 4' },
    { key: 'unit5' as keyof FloorEntry, configKey: 'unit5' as keyof UnitSqftConfig, label: 'Unit 5' },
    { key: 'unit6' as keyof FloorEntry, configKey: 'unit6' as keyof UnitSqftConfig, label: 'Unit 6' },
    { key: 'unit7' as keyof FloorEntry, configKey: 'unit7' as keyof UnitSqftConfig, label: 'Unit 7' },
    { key: 'unit8' as keyof FloorEntry, configKey: 'unit8' as keyof UnitSqftConfig, label: 'Unit 8' },
    { key: 'lobby' as keyof FloorEntry, configKey: 'lobby' as keyof UnitSqftConfig, label: 'Lobby' },
    { key: 'starc1' as keyof FloorEntry, configKey: 'starc1' as keyof UnitSqftConfig, label: 'Starc 1' },
    { key: 'starc2' as keyof FloorEntry, configKey: 'starc2' as keyof UnitSqftConfig, label: 'Starc 2' },
  ];

  if (!sqftConfig) return base;

  const inactive = sqftConfig.inactiveUnits || [];
  let filtered = base.filter((u) => !inactive.includes(String(u.key)));

  if (sqftConfig.extraUnits) {
    sqftConfig.extraUnits.forEach((ex) => {
      if (!filtered.some(f => f.key === ex.key)) {
        filtered.push({
          key: ex.key as keyof FloorEntry,
          configKey: ex.key as any,
          label: ex.label,
        });
      }
    });
  }

  return filtered;
};

/**
 * Check if all flat units (and optionally lobby + starcs) on a floor are completed and Ready for Billing
 */
export const isFloorReadyForBilling = (floor: FloorEntry, sqftConfig?: UnitSqftConfig): boolean => {
  const activeList = getActiveUnits(sqftConfig);
  const flats = activeList.filter(u => String(u.key).startsWith('unit'));
  const allFlatsPaid = flats.every((k) => floor[k.key] === 'paid');
  const hasLobby = activeList.some(u => u.key === 'lobby');
  const isLobbyPaid = hasLobby ? floor.lobby === 'paid' : true;
  return allFlatsPaid && (isLobbyPaid || floor.paidQuantity > 0);
};

/**
 * Get detailed status classification
 */
export const getFloorStatusType = (floor: FloorEntry, sqftConfig?: UnitSqftConfig): 'ready' | 'in_progress' | 'partial' => {
  const activeList = getActiveUnits(sqftConfig);
  const flats = activeList.filter(u => String(u.key).startsWith('unit'));
  const paidFlats = flats.filter((k) => floor[k.key] === 'paid').length;

  const allActivePaid = activeList.every((k) => floor[k.key] === 'paid');
  const allActivePending = activeList.every((k) => floor[k.key] !== 'paid');

  if (allActivePaid) {
    return 'ready';
  }
  if (allActivePending) {
    return 'in_progress';
  }
  return 'partial';
};

export type FloorProgressStatus = 'done' | 'in_progress' | 'pending';

export interface FloorProgressInfo {
  status: FloorProgressStatus;
  label: string;
  subLabel: string;
  paidFlatsCount: number;
  totalFlatsCount: number;
  isAllPaid: boolean;
  cardBgClass: string;
  cardBorderClass: string;
  cardIndicatorBarClass: string;
  rowBgClass: string;
  badgeClass: string;
  dotClass: string;
  accentTextClass: string;
}

/**
 * Returns comprehensive visual status indicators (colors, labels, classes) for floor entry cards and rows
 */
export const getFloorProgressStatus = (floor: FloorEntry, sqftConfig?: UnitSqftConfig): FloorProgressInfo => {
  const activeList = getActiveUnits(sqftConfig);
  const flats = activeList.filter(u => String(u.key).startsWith('unit'));
  let paidFlatsCount = 0;
  let pendingFlatsCount = 0;

  flats.forEach((k) => {
    if (floor[k.key] === 'paid') paidFlatsCount++;
    else if (floor[k.key] === 'pending') pendingFlatsCount++;
  });

  const isReady = isFloorReadyForBilling(floor, sqftConfig);
  const isDone = isReady || (flats.length > 0 && paidFlatsCount === flats.length && floor.paidQuantity > 0);

  if (isDone) {
    return {
      status: 'done',
      label: 'Done',
      subLabel: 'Ready for Billing',
      paidFlatsCount,
      totalFlatsCount: flats.length,
      isAllPaid: true,
      cardBgClass: 'bg-emerald-50/60 hover:bg-emerald-50/90',
      cardBorderClass: 'border-emerald-300 hover:border-emerald-500 shadow-emerald-900/5',
      cardIndicatorBarClass: 'bg-emerald-600',
      rowBgClass: 'bg-emerald-50/50 hover:bg-emerald-100/60 border-l-4 border-l-emerald-600',
      badgeClass: 'bg-emerald-100 text-emerald-900 border border-emerald-300 font-extrabold',
      dotClass: 'bg-emerald-500 ring-2 ring-emerald-200 shadow-xs',
      accentTextClass: 'text-emerald-800',
    };
  }

  const hasAnyProgress =
    paidFlatsCount > 0 ||
    floor.lobby === 'paid' ||
    floor.starc1 === 'paid' ||
    floor.starc2 === 'paid' ||
    floor.paidQuantity > 0 ||
    pendingFlatsCount > 0 ||
    floor.lobby === 'pending';

  if (hasAnyProgress) {
    return {
      status: 'in_progress',
      label: 'In Progress',
      subLabel: `${paidFlatsCount}/${flats.length} Flats Done`,
      paidFlatsCount,
      totalFlatsCount: flats.length,
      isAllPaid: false,
      cardBgClass: 'bg-amber-50/45 hover:bg-amber-50/75',
      cardBorderClass: 'border-amber-300 hover:border-amber-500 shadow-amber-900/5',
      cardIndicatorBarClass: 'bg-amber-500',
      rowBgClass: 'bg-amber-50/40 hover:bg-amber-100/60 border-l-4 border-l-amber-400',
      badgeClass: 'bg-amber-100 text-amber-950 border border-amber-300 font-extrabold',
      dotClass: 'bg-amber-500 ring-2 ring-amber-200 shadow-xs',
      accentTextClass: 'text-amber-900',
    };
  }

  return {
    status: 'pending',
    label: 'Pending',
    subLabel: 'Not Started',
    paidFlatsCount: 0,
    totalFlatsCount: flats.length,
    isAllPaid: false,
    cardBgClass: 'bg-white hover:bg-slate-50/80',
    cardBorderClass: 'border-slate-200 hover:border-slate-400 shadow-slate-900/5',
    cardIndicatorBarClass: 'bg-slate-300',
    rowBgClass: 'bg-white hover:bg-slate-50 border-l-4 border-l-slate-200',
    badgeClass: 'bg-slate-100 text-slate-700 border border-slate-200 font-bold',
    dotClass: 'bg-slate-400 ring-2 ring-slate-200',
    accentTextClass: 'text-slate-600',
  };
};

/**
 * Toggle entire floor between 'Ready for Billing' (all completed / paid) and 'In Progress' (all pending)
 */
export const toggleFloorCompletedStatus = (
  floor: FloorEntry,
  sqftConfig: UnitSqftConfig,
  markCompleted: boolean,
  holdPercent: number = 20
): FloorEntry => {
  const targetStatus: UnitStatus = markCompleted ? 'paid' : 'pending';
  const activeList = getActiveUnits(sqftConfig);

  let fullSqft = 0;
  activeList.forEach((u) => {
    fullSqft += Number(sqftConfig[u.configKey] || 0);
  });

  const releaseQty = floor.releaseQuantity > 0 ? floor.releaseQuantity : fullSqft;

  const updated: FloorEntry = { ...floor };

  // Set all active units status
  activeList.forEach((u) => {
    (updated[u.key as keyof FloorEntry] as any) = targetStatus;
  });

  const flats = activeList.filter(u => String(u.key).startsWith('unit'));
  const flatsCount = markCompleted ? flats.length : 0;
  const lobbyCount = (activeList.some(u => u.key === 'lobby') && markCompleted) ? 1 : 0;
  const s1Count = (activeList.some(u => u.key === 'starc1') && markCompleted) ? 1 : 0;
  const s2Count = (activeList.some(u => u.key === 'starc2') && markCompleted) ? 1 : 0;

  updated.gypsumRunningFlats = flatsCount;
  updated.gypsumRunningLobby = lobbyCount;
  updated.starches1WC = s1Count;
  updated.starches2WC = s2Count;
  updated.verifyFlats = flatsCount;
  updated.verifyLobby = lobbyCount;
  updated.verifyStar1 = s1Count;
  updated.verifyStar2 = s2Count;

  if (markCompleted) {
    const holdQty = Math.round((releaseQty * holdPercent) / 100);
    updated.releaseQuantity = releaseQty;
    updated.holdQuantity = holdQty;
    updated.paidQuantity = releaseQty - holdQty;
  } else {
    updated.releaseQuantity = releaseQty;
    updated.holdQuantity = releaseQty;
    updated.paidQuantity = 0;
  }

  updated.updatedAt = new Date().toISOString();
  return updated;
};

/**
 * Toggle a single unit's status on a floor and recalculate quantities accurately
 */
export const toggleSingleUnitStatus = (
  floor: FloorEntry,
  unitKey: keyof FloorEntry,
  sqftConfig: UnitSqftConfig,
  holdPercent: number = 20
): FloorEntry => {
  const currentStatus = (floor[unitKey] as UnitStatus) || 'none';
  let newStatus: UnitStatus;
  if (currentStatus === 'none') {
    newStatus = 'pending';
  } else if (currentStatus === 'pending') {
    newStatus = 'paid';
  } else {
    newStatus = 'none';
  }

  const updated: FloorEntry = {
    ...floor,
    [unitKey]: newStatus,
  };

  const activeList = getActiveUnits(sqftConfig);

  // Recount flats and area running units
  const flats = activeList.filter(u => String(u.key).startsWith('unit'));
  let flatsCount = 0;
  flats.forEach((k) => {
    if (updated[k.key as keyof FloorEntry] === 'paid') flatsCount++;
  });

  const lobbyCount = updated.lobby === 'paid' ? 1 : 0;
  const s1Count = updated.starc1 === 'paid' ? 1 : 0;
  const s2Count = updated.starc2 === 'paid' ? 1 : 0;

  updated.gypsumRunningFlats = flatsCount;
  updated.gypsumRunningLobby = lobbyCount;
  updated.starches1WC = s1Count;
  updated.starches2WC = s2Count;
  updated.verifyFlats = flatsCount;
  updated.verifyLobby = lobbyCount;
  updated.verifyStar1 = s1Count;
  updated.verifyStar2 = s2Count;

  // Calculate Sqft based on config
  let completedSqft = 0;
  activeList.forEach(({ key, configKey }) => {
    if (updated[key] === 'paid') {
      completedSqft += Number(sqftConfig[configKey] || 0);
    }
  });

  let fullSqft = 0;
  activeList.forEach((u) => {
    fullSqft += Number(sqftConfig[u.configKey] || 0);
  });

  const releaseQty = floor.releaseQuantity > 0 ? floor.releaseQuantity : fullSqft;

  const allFlatsCompleted = flatsCount === flats.length;
  const lobbyDone = !activeList.some(u => u.key === 'lobby') || lobbyCount === 1;
  const s1Done = !activeList.some(u => u.key === 'starc1') || s1Count === 1;
  const s2Done = !activeList.some(u => u.key === 'starc2') || s2Count === 1;

  if (allFlatsCompleted && lobbyDone && s1Done && s2Done) {
    const holdQty = Math.round((releaseQty * holdPercent) / 100);
    updated.releaseQuantity = releaseQty;
    updated.holdQuantity = holdQty;
    updated.paidQuantity = releaseQty - holdQty;
  } else if (flatsCount === 0 && lobbyCount === 0 && s1Count === 0 && s2Count === 0) {
    updated.releaseQuantity = releaseQty;
    updated.holdQuantity = releaseQty;
    updated.paidQuantity = 0;
  } else {
    // Partial completion
    const calculatedPaid = Math.max(0, Math.round(completedSqft * (1 - holdPercent / 100)));
    updated.releaseQuantity = releaseQty;
    updated.paidQuantity = calculatedPaid;
    updated.holdQuantity = Math.max(0, releaseQty - calculatedPaid);
  }

  updated.updatedAt = new Date().toISOString();
  return updated;
};;

export interface FloorBillingBadgeInfo {
  isExported: boolean;
  isPrinted: boolean;
  isBilled: boolean;
  status: 'exported' | 'printed' | 'both' | 'pending';
  badgeLabel: string;
  badgeShortLabel: string;
  badgeClass: string;
  badgeIconType: 'pdf' | 'printed' | 'both' | 'pending';
  tooltip: string;
  exportDateFormatted?: string;
}

/**
 * Returns visual indicator badge styling and labels for floor billing / PDF export tracking
 */
export const getFloorBillingBadgeInfo = (floor: FloorEntry): FloorBillingBadgeInfo => {
  const isExported = Boolean(
    floor.isBillExported || floor.billExportStatus === 'exported' || floor.billExportStatus === 'both'
  );
  const isPrinted = Boolean(
    floor.isBillPrinted || floor.billExportStatus === 'printed' || floor.billExportStatus === 'both'
  );

  const exportDateFormatted = floor.billExportDate
    ? new Date(floor.billExportDate).toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
      })
    : undefined;

  if (isExported && isPrinted) {
    return {
      isExported: true,
      isPrinted: true,
      isBilled: true,
      status: 'both',
      badgeLabel: 'PDF & Printed',
      badgeShortLabel: 'PDF + Print',
      badgeClass: 'bg-emerald-100 text-emerald-950 border border-emerald-300 ring-1 ring-emerald-400/30 font-black',
      badgeIconType: 'both',
      tooltip: `Bill has been exported to PDF and printed${exportDateFormatted ? ` (${exportDateFormatted})` : ''}`,
      exportDateFormatted,
    };
  }

  if (isExported) {
    return {
      isExported: true,
      isPrinted: false,
      isBilled: true,
      status: 'exported',
      badgeLabel: 'PDF Exported',
      badgeShortLabel: 'PDF Ready',
      badgeClass: 'bg-sky-100 text-sky-950 border border-sky-300 ring-1 ring-sky-400/30 font-black',
      badgeIconType: 'pdf',
      tooltip: `Bill exported to PDF${exportDateFormatted ? ` on ${exportDateFormatted}` : ''}`,
      exportDateFormatted,
    };
  }

  if (isPrinted) {
    return {
      isExported: false,
      isPrinted: true,
      isBilled: true,
      status: 'printed',
      badgeLabel: 'Printed',
      badgeShortLabel: 'Printed',
      badgeClass: 'bg-indigo-100 text-indigo-950 border border-indigo-300 ring-1 ring-indigo-400/30 font-black',
      badgeIconType: 'printed',
      tooltip: `Bill physically printed${exportDateFormatted ? ` on ${exportDateFormatted}` : ''}`,
      exportDateFormatted,
    };
  }

  return {
    isExported: false,
    isPrinted: false,
    isBilled: false,
    status: 'pending',
    badgeLabel: 'Pending Bill',
    badgeShortLabel: 'Unbilled',
    badgeClass: 'bg-slate-100 text-slate-500 border border-slate-200 font-semibold',
    badgeIconType: 'pending',
    tooltip: 'Bill not yet exported to PDF or printed',
  };
};

/**
 * Updates floor billing status and sync timestamps
 */
export const updateFloorBillingStatus = (
  floor: FloorEntry,
  status: 'exported' | 'printed' | 'both' | 'pending'
): FloorEntry => {
  const now = new Date().toISOString();
  let isBillExported = false;
  let isBillPrinted = false;

  if (status === 'exported') {
    isBillExported = true;
  } else if (status === 'printed') {
    isBillPrinted = true;
  } else if (status === 'both') {
    isBillExported = true;
    isBillPrinted = true;
  }

  return {
    ...floor,
    billExportStatus: status,
    isBillExported,
    isBillPrinted,
    billExportDate: status === 'pending' ? undefined : (floor.billExportDate || now),
    updatedAt: now,
  };
};

