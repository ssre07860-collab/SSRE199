import { FloorEntry, BillHeader, UnitSqftConfig } from '../types';
import { INITIAL_BILL_HEADER, INITIAL_SQFT_CONFIG, INITIAL_FLOOR_ENTRIES } from '../data/initialData';
import { sortFloors } from '../services/firestoreService';
import { deduplicateFloors } from './towerHelper';

const LIFETIME_FLOORS_KEY = 'prestige_tower2_lifetime_floors_v2';
const LIFETIME_HEADER_KEY = 'prestige_tower2_lifetime_header_v2';
const LIFETIME_SQFT_KEY = 'prestige_tower2_lifetime_sqft_v2';
const LIFETIME_LAST_SYNC_KEY = 'prestige_tower2_lifetime_last_sync_timestamp';

/**
 * Save floors to lifetime local storage mirror
 */
export function saveLifetimeFloors(floors: FloorEntry[]): void {
  try {
    if (!floors || floors.length === 0) return;
    const clean = deduplicateFloors(floors);
    localStorage.setItem(LIFETIME_FLOORS_KEY, JSON.stringify(clean));
    localStorage.setItem(LIFETIME_LAST_SYNC_KEY, Date.now().toString());
  } catch (err) {
    console.warn('Could not write floors to lifetime storage mirror:', err);
  }
}

/**
 * Load floors from lifetime local storage mirror
 */
export function loadLifetimeFloors(): FloorEntry[] | null {
  try {
    const raw = localStorage.getItem(LIFETIME_FLOORS_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      const deduplicated = deduplicateFloors(parsed);
      // If deduplication removed any duplicate records, persist cleaned state immediately
      if (deduplicated.length !== parsed.length) {
        localStorage.setItem(LIFETIME_FLOORS_KEY, JSON.stringify(deduplicated));
      }
      return sortFloors(deduplicated);
    }
  } catch (err) {
    console.warn('Could not read floors from lifetime storage mirror:', err);
  }
  return null;
}

/**
 * Save bill header to lifetime local storage mirror
 */
export function saveLifetimeHeader(header: BillHeader): void {
  try {
    if (!header) return;
    localStorage.setItem(LIFETIME_HEADER_KEY, JSON.stringify(header));
    localStorage.setItem(LIFETIME_LAST_SYNC_KEY, Date.now().toString());
  } catch (err) {
    console.warn('Could not write bill header to lifetime storage mirror:', err);
  }
}

/**
 * Load bill header from lifetime local storage mirror
 */
export function loadLifetimeHeader(): BillHeader | null {
  try {
    const raw = localStorage.getItem(LIFETIME_HEADER_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object' && parsed.scName) {
      return parsed as BillHeader;
    }
  } catch (err) {
    console.warn('Could not read bill header from lifetime storage mirror:', err);
  }
  return null;
}

/**
 * Save unit sqft config to lifetime local storage mirror
 */
export function saveLifetimeSqftConfig(config: UnitSqftConfig): void {
  try {
    if (!config) return;
    localStorage.setItem(LIFETIME_SQFT_KEY, JSON.stringify(config));
  } catch (err) {
    console.warn('Could not write unit config to lifetime storage mirror:', err);
  }
}

/**
 * Load unit sqft config from lifetime local storage mirror
 */
export function loadLifetimeSqftConfig(): UnitSqftConfig | null {
  try {
    const raw = localStorage.getItem(LIFETIME_SQFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === 'object') {
      return parsed as UnitSqftConfig;
    }
  } catch (err) {
    console.warn('Could not read unit config from lifetime storage mirror:', err);
  }
  return null;
}

/**
 * Get the last timestamp when data was persisted
 */
export function getLastLifetimeSyncTimestamp(): number | null {
  try {
    const val = localStorage.getItem(LIFETIME_LAST_SYNC_KEY);
    if (!val) return null;
    const parsed = parseInt(val, 10);
    return isNaN(parsed) ? null : parsed;
  } catch {
    return null;
  }
}

/**
 * Reset lifetime storage to default initial data (only on explicit user reset)
 */
export function resetLifetimeStorage(): void {
  try {
    localStorage.removeItem(LIFETIME_FLOORS_KEY);
    localStorage.removeItem(LIFETIME_HEADER_KEY);
    localStorage.removeItem(LIFETIME_SQFT_KEY);
    localStorage.setItem(LIFETIME_LAST_SYNC_KEY, Date.now().toString());
  } catch (err) {
    console.warn('Could not reset lifetime storage:', err);
  }
}
