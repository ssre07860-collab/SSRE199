import React, { useState, useEffect } from 'react';
import {
  X,
  User,
  Phone,
  MapPin,
  CreditCard,
  Mail,
  Camera,
  Trash2,
  Save,
  CheckCircle2,
  ShieldAlert,
  Edit,
  Building2,
  Lock
} from 'lucide-react';
import { UserAccount, UserAccessInfo, UserRole } from '../types';
import { ConfirmationDialog } from './ConfirmationDialog';

interface LabourRegistrationModalProps {
  isOpen: boolean;
  onClose: () => void;
  userAccess: UserAccessInfo;
  accounts: UserAccount[];
  onSaveUserAccount: (account: UserAccount) => Promise<void>;
  onDeleteUserAccount?: (accountId: string) => Promise<void>;
  initialAccount?: UserAccount | null;
}

export const LabourRegistrationModal: React.FC<LabourRegistrationModalProps> = ({
  isOpen,
  onClose,
  userAccess,
  accounts,
  onSaveUserAccount,
  onDeleteUserAccount,
  initialAccount = null,
}) => {
  // Check access permissions
  const canEdit = userAccess.isOwner || userAccess.isSupervisor;
  const isOwner = userAccess.isOwner;

  // Form states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [aadhaarNo, setAadhaarNo] = useState('');
  const [panNo, setPanNo] = useState('');
  const [email, setEmail] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [assignedTower, setAssignedTower] = useState('Tower 2');
  const [ratePerSqft, setRatePerSqft] = useState<number>(12);
  const [status, setStatus] = useState<'approved' | 'pending' | 'rejected'>('pending');

  // UI state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Sync initial account values if we are editing
  useEffect(() => {
    if (initialAccount) {
      setName(initialAccount.name || '');
      setPhone(initialAccount.phone || '');
      setAddress(initialAccount.address || '');
      setAadhaarNo(initialAccount.aadhaarNo || '');
      setPanNo(initialAccount.panNo || '');
      setEmail(initialAccount.email || '');
      setPhotoUrl(initialAccount.photoUrl || '');
      setAssignedTower(initialAccount.assignedTower || 'Tower 2');
      setRatePerSqft(initialAccount.ratePerSqft || 12);
      setStatus(initialAccount.status || 'approved');
    } else {
      // Reset form for adding new labourer (default to approved so owner can add in 1 step)
      setName('');
      setPhone('');
      setAddress('');
      setAadhaarNo('');
      setPanNo('');
      setEmail('');
      setPhotoUrl('');
      setAssignedTower('Tower 2');
      setRatePerSqft(12);
      setStatus('approved');
    }
    setFeedback(null);
  }, [initialAccount, isOpen]);

  if (!isOpen) return null;

  // Check if current user is labour role. If so, deny rendering at all!
  if (userAccess.isLabour) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-xs">
        <div className="bg-white p-6 rounded-2xl max-w-sm text-center border border-slate-200 shadow-2xl">
          <ShieldAlert className="w-12 h-12 text-rose-600 mx-auto mb-3" />
          <h3 className="text-sm font-black text-slate-900 uppercase">Strict Access Denied</h3>
          <p className="text-xs text-slate-600 mt-2">
            You do not have administrative permissions to view or edit labour profile files.
          </p>
          <button
            onClick={onClose}
            className="mt-4 px-4 py-2 bg-slate-900 text-white rounded-lg text-xs font-bold w-full"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  // Handle Photo File Conversion (Base64)
  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFeedback({ type: 'error', message: 'Please select a valid image file (JPG/PNG).' });
      return;
    }

    // Size limit check (2MB)
    if (file.size > 2 * 1024 * 1024) {
      setFeedback({ type: 'error', message: 'Image too large. Please upload an image under 2MB.' });
      return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
      setPhotoUrl(reader.result as string);
      setFeedback({ type: 'success', message: 'Photo uploaded successfully! Ready to save.' });
    };
    reader.onerror = () => {
      setFeedback({ type: 'error', message: 'Error reading image file.' });
    };
    reader.readAsDataURL(file);
  };

  // Trigger camera click
  const triggerFileInput = () => {
    document.getElementById('labour-photo-input')?.click();
  };

  // Handle submit (save/update account)
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!canEdit) {
      setFeedback({ type: 'error', message: 'You do not have write access to update labour profiles.' });
      return;
    }

    if (!name.trim()) {
      setFeedback({ type: 'error', message: 'Labourer Full Name is required.' });
      return;
    }

    // Phone 10-digit validation
    const cleanPhone = phone.replace(/\D/g, '');
    if (phone && cleanPhone.length !== 10) {
      setFeedback({ type: 'error', message: 'Please enter a valid 10-digit Mobile Number.' });
      return;
    }

    // Aadhaar 12-digit validation
    const cleanAadhaar = aadhaarNo.replace(/\D/g, '');
    if (aadhaarNo && cleanAadhaar.length !== 12) {
      setFeedback({ type: 'error', message: 'Aadhaar Card Number must be exactly 12 digits.' });
      return;
    }

    // Email validation
    if (!email.trim()) {
      setFeedback({ type: 'error', message: 'Gmail ID is required for authentication matching.' });
      return;
    }

    setIsSubmitting(true);
    setFeedback(null);

    const isApproved = status === 'approved';
    const accountData: UserAccount = {
      id: initialAccount?.id || `usr-lab-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: cleanPhone || undefined,
      address: address.trim() || undefined,
      aadhaarNo: cleanAadhaar || undefined,
      panNo: panNo.trim().toUpperCase() || undefined,
      photoUrl: photoUrl || undefined,
      role: 'labour',
      specialization: 'Gypsum Mistri / Labour',
      assignedTower,
      ratePerSqft: Number(ratePerSqft) || 12,
      status: status,
      isVerifiedByOwner: isApproved,
      verifiedByEmail: isApproved ? (userAccess.email || 'ssre07860@gmail.com') : undefined,
      verifiedAt: isApproved ? new Date().toISOString() : undefined,
      mappedLabourName: name.trim(),
      canViewBills: isApproved,
      registeredAt: initialAccount?.registeredAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      await onSaveUserAccount(accountData);
      setFeedback({
        type: 'success',
        message: `Labour Profile for "${accountData.name}" has been saved instantly to the Cloud!`
      });
      setIsSubmitting(false);
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      setIsSubmitting(false);
      setFeedback({
        type: 'error',
        message: `Error saving profile: ${err?.message || 'Failed to save to database.'}`
      });
    }
  };

  // Handle Delete Confirmation (Only Owner)
  const confirmDeleteLabour = async () => {
    if (!isOwner || !onDeleteUserAccount || !initialAccount) return;
    setIsSubmitting(true);
    setShowDeleteConfirm(false);
    try {
      await onDeleteUserAccount(initialAccount.id);
      setFeedback({ type: 'success', message: 'Profile permanently deleted successfully!' });
      setIsSubmitting(false);
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      setIsSubmitting(false);
      setFeedback({ type: 'error', message: `Delete failed: ${err?.message || 'Failed'}` });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/70 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden max-h-[92vh] flex flex-col animate-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-amber-500" />
            <h2 className="text-sm font-black uppercase tracking-wider">
              {initialAccount ? '📋 Edit Contractor / Labour Profile' : '➕ Register New Field Labourer'}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Box */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
          
          {feedback && (
            <div
              className={`p-3 rounded-xl border flex items-start space-x-2 font-bold ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : 'bg-rose-50 border-rose-200 text-rose-800'
              }`}
            >
              <CheckCircle2 className={`w-4 h-4 shrink-0 mt-0.5 ${feedback.type === 'success' ? 'text-emerald-600' : 'text-rose-600'}`} />
              <span>{feedback.message}</span>
            </div>
          )}

          {/* Photo Section with Camera Access */}
          <div className="flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-4 p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="relative group">
              <div className="w-24 h-24 rounded-full border-2 border-dashed border-slate-300 bg-slate-100 flex items-center justify-center overflow-hidden shrink-0">
                {photoUrl ? (
                  <img
                    src={photoUrl}
                    alt="Labour Avatar"
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <User className="w-10 h-10 text-slate-400" />
                )}
              </div>
              {canEdit && (
                <button
                  type="button"
                  onClick={triggerFileInput}
                  className="absolute bottom-0 right-0 p-2 bg-amber-500 text-slate-950 rounded-full hover:bg-amber-400 shadow-md transition"
                  title="Capture or select photo"
                >
                  <Camera className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="text-center sm:text-left space-y-1 flex-1">
              <span className="text-xs font-black text-slate-800 block">Labour Photo Identification *</span>
              <p className="text-[11px] text-slate-500 leading-normal">
                Upload a clear face photo from your device, or tap to capture directly from your mobile camera. Supports JPG, PNG up to 2MB.
              </p>
              {canEdit && (
                <button
                  type="button"
                  onClick={triggerFileInput}
                  className="mt-1 px-3 py-1 bg-white border border-slate-300 rounded text-[11px] font-bold text-slate-700 hover:bg-slate-50 transition cursor-pointer"
                >
                  Choose Image / Take Photo
                </button>
              )}
              <input
                id="labour-photo-input"
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handlePhotoChange}
                className="hidden"
              />
            </div>
          </div>

          {/* Main Info Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Full Name * (पूरा नाम)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400">
                  <User className="w-3.5 h-3.5" />
                </span>
                <input
                  type="text"
                  required
                  disabled={!canEdit}
                  placeholder="e.g. Adil Ahmad"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-hidden disabled:bg-slate-50"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Mobile Number (मोबाइल नंबर)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400">
                  <Phone className="w-3.5 h-3.5" />
                </span>
                <input
                  type="tel"
                  disabled={!canEdit}
                  placeholder="10-digit mobile number"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-hidden disabled:bg-slate-50"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                Gmail / Email ID * (गूगल ईमेल आईडी)
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 text-slate-400">
                  <Mail className="w-3.5 h-3.5" />
                </span>
                <input
                  type="email"
                  required
                  disabled={!canEdit}
                  placeholder="e.g. adil@gmail.com (For Sign In)"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-hidden disabled:bg-slate-50"
                />
              </div>
              <p className="text-[10px] text-emerald-600 font-bold mt-1">
                ✓ इस Gmail ID से लेबर के लॉगिन करते ही उसका बिल और पेमेंट डिटेल अपने-आप दिखेगा।
              </p>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Rate Per Sqft (₹/sqft)
                </label>
                <input
                  type="number"
                  step="0.5"
                  disabled={!canEdit}
                  value={ratePerSqft}
                  onChange={(e) => setRatePerSqft(parseFloat(e.target.value) || 12)}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-bold focus:ring-2 focus:ring-amber-500 focus:outline-hidden disabled:bg-slate-50 text-emerald-700"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  Default Tower
                </label>
                <select
                  disabled={!canEdit}
                  value={assignedTower}
                  onChange={(e) => setAssignedTower(e.target.value)}
                  className="w-full px-2 py-2 border border-slate-300 rounded-lg text-xs font-bold focus:ring-2 focus:ring-amber-500 focus:outline-hidden disabled:bg-slate-50"
                >
                  <option value="Tower 2">Tower 2</option>
                  <option value="Tower 3">Tower 3</option>
                  <option value="Tower 4">Tower 4</option>
                  <option value="All Towers">All Towers</option>
                </select>
              </div>
            </div>
          </div>

          {/* Verification Cards / IDs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center space-x-1">
                <CreditCard className="w-3.5 h-3.5 text-slate-500" />
                <span>Aadhaar Card Number * (आधार नंबर)</span>
              </label>
              <input
                type="text"
                disabled={!canEdit}
                placeholder="12-digit Aadhaar Number"
                value={aadhaarNo}
                onChange={(e) => setAadhaarNo(e.target.value.replace(/\D/g, '').slice(0, 12))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold focus:ring-2 focus:ring-amber-500 focus:outline-hidden disabled:bg-slate-50"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center space-x-1">
                <CreditCard className="w-3.5 h-3.5 text-slate-500" />
                <span>PAN Card Number (पैन कार्ड नंबर)</span>
              </label>
              <input
                type="text"
                disabled={!canEdit}
                placeholder="ABCDE1234F"
                value={panNo}
                onChange={(e) => setPanNo(e.target.value.toUpperCase().slice(0, 10))}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-mono font-bold focus:ring-2 focus:ring-amber-500 focus:outline-hidden disabled:bg-slate-50 uppercase"
              />
            </div>
          </div>

          {/* Address Details */}
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1 flex items-center space-x-1">
              <MapPin className="w-3.5 h-3.5 text-slate-500" />
              <span>Full Address (स्थायी पता)</span>
            </label>
            <textarea
              rows={2}
              disabled={!canEdit}
              placeholder="Enter full permanent residential address..."
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-hidden disabled:bg-slate-50"
            />
          </div>

          {/* Verification Status (Only Owner can approve) */}
          <div className="flex items-center justify-between p-2.5 bg-slate-100 rounded-xl border border-slate-200">
            <div className="flex items-center space-x-1.5">
              <Lock className="w-3.5 h-3.5 text-slate-500" />
              <span className="font-bold text-slate-700">Account Authorization Status</span>
            </div>
            {isOwner ? (
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as any)}
                className="px-2 py-1 bg-white border border-slate-300 rounded-md font-bold text-xs"
              >
                <option value="approved">Approved &amp; Active</option>
                <option value="pending">Pending Approval</option>
                <option value="rejected">Rejected / Blocked</option>
              </select>
            ) : (
              <span className="font-extrabold uppercase text-[10px] bg-slate-200 px-2 py-1 rounded text-slate-600">
                {status} (Locked)
              </span>
            )}
          </div>

          {/* Actions & Buttons */}
          <div className="flex items-center justify-between border-t border-slate-200 pt-4 mt-2">
            <div>
              {isOwner && initialAccount && (
                <button
                  type="button"
                  onClick={() => setShowDeleteConfirm(true)}
                  disabled={isSubmitting}
                  className="flex items-center space-x-1.5 px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-lg border border-rose-200 transition cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Delete Profile</span>
                </button>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 border border-slate-300 rounded-lg hover:bg-slate-50 font-bold transition cursor-pointer"
              >
                Cancel
              </button>
              {canEdit && (
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex items-center space-x-1.5 px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-black rounded-lg shadow-sm transition cursor-pointer"
                >
                  <Save className="w-4 h-4 text-emerald-400" />
                  <span>{isSubmitting ? 'Saving to Cloud...' : 'Save Profile'}</span>
                </button>
              )}
            </div>
          </div>

        </form>

        {/* Safe Confirmation Dialog for Labour Deletion */}
        <ConfirmationDialog
          isOpen={showDeleteConfirm}
          title="Permanently Delete Labour Profile?"
          message={`Are you sure you want to permanently delete the profile of "${name}"? This will remove all verification documents, photos, and linked account data.`}
          confirmText="Yes, Delete Profile"
          cancelText="Keep Profile"
          isDestructive={true}
          itemDetails={[
            { label: 'Labour Name', value: name },
            { label: 'Gmail ID', value: email || 'None' },
            { label: 'Assigned Tower', value: assignedTower },
            { label: 'Rate per Sqft', value: `₹${ratePerSqft}` },
          ]}
          onConfirm={confirmDeleteLabour}
          onCancel={() => setShowDeleteConfirm(false)}
        />
      </div>
    </div>
  );
};
