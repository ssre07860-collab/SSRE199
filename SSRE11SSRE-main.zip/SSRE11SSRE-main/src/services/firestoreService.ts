import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  getDoc,
  getDocs,
  onSnapshot,
  writeBatch,
  query,
} from 'firebase/firestore';
import { db, auth, ensureAuthenticated } from '../firebase';
import { FloorEntry, BillHeader, UnitSqftConfig } from '../types';
import { deduplicateFloors } from '../utils/towerHelper';

const FLOORS_COLLECTION = 'floors';
const SETTINGS_COLLECTION = 'app_settings';
const HEADER_DOC = 'billHeader';
const SQFT_DOC = 'unitSqftConfig';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo:
        auth.currentUser?.providerData?.map((p) => ({
          providerId: p.providerId,
          email: p.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Helper to remove undefined values before saving to Firestore
function sanitizeDocData<T extends Record<string, any>>(data: T): Record<string, any> {
  const sanitized: Record<string, any> = {};
  Object.keys(data).forEach((key) => {
    if (data[key] !== undefined) {
      sanitized[key] = data[key];
    }
  });
  return sanitized;
}

/**
 * Seed initial floors and settings into Firestore if collection is currently empty
 */
export async function seedInitialDataIfEmpty(
  initialFloors: FloorEntry[],
  initialHeader: BillHeader,
  initialConfig: UnitSqftConfig
): Promise<boolean> {
  const pathForFloors = FLOORS_COLLECTION;
  try {
    await ensureAuthenticated();
    const floorsRef = collection(db, FLOORS_COLLECTION);
    const snapshot = await getDocs(floorsRef);

    if (snapshot.empty) {
      console.log('Firestore is empty. Seeding initial floor entries & header...');
      const batch = writeBatch(db);

      // Seed all initial floors
      for (const floor of initialFloors) {
        const floorRef = doc(db, FLOORS_COLLECTION, floor.id);
        batch.set(floorRef, {
          ...sanitizeDocData(floor),
          updatedAt: new Date().toISOString(),
        });
      }

      // Seed initial header
      const headerRef = doc(db, SETTINGS_COLLECTION, HEADER_DOC);
      batch.set(headerRef, {
        ...sanitizeDocData(initialHeader),
        updatedAt: new Date().toISOString(),
      });

      // Seed initial sqft config
      const sqftRef = doc(db, SETTINGS_COLLECTION, SQFT_DOC);
      batch.set(sqftRef, {
        ...sanitizeDocData(initialConfig),
        updatedAt: new Date().toISOString(),
      });

      await batch.commit();
      console.log('Initial data successfully seeded to Firestore!');
      return true;
    }
    return false;
  } catch (error: any) {
    console.warn('Initial seeding note (will use local dataset if remote sync is unavailable):', error);
    if (error?.code === 'permission-denied' || error?.message?.includes('insufficient permissions')) {
      handleFirestoreError(error, OperationType.WRITE, pathForFloors);
    }
    return false;
  }
}

/**
 * Sort floors in standard architectural sequence (Ground -> 1 -> 2 -> ... -> 31)
 */
export function sortFloors(floorsList: FloorEntry[]): FloorEntry[] {
  return [...floorsList].sort((a, b) => {
    const parseFloor = (val: string): number => {
      const lower = (val || '').toLowerCase().trim();
      if (lower.includes('ground') || lower === 'g' || lower === 'gf') return 0;
      if (lower.includes('basement 2') || lower === 'b2') return -2;
      if (lower.includes('basement 1') || lower.includes('basement') || lower === 'b1') return -1;
      const num = parseInt(lower.replace(/\D/g, ''), 10);
      return isNaN(num) ? 999 : num;
    };
    return parseFloor(a.floorNo) - parseFloor(b.floorNo);
  });
}

/**
 * Real-time listener for floors collection
 */
export function subscribeToFloors(
  onUpdate: (floors: FloorEntry[]) => void,
  onError?: (error: Error) => void
): () => void {
  const floorsRef = collection(db, FLOORS_COLLECTION);
  const q = query(floorsRef);

  return onSnapshot(
    q,
    (snapshot) => {
      const floors: FloorEntry[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as FloorEntry;
        floors.push({
          ...data,
          id: docSnap.id,
        });
      });
      onUpdate(sortFloors(deduplicateFloors(floors)));
    },
    (err) => {
      console.error('Error listening to Firestore floors:', err);
      if (onError) onError(err);
      if (err?.code === 'permission-denied' || err?.message?.includes('insufficient permissions')) {
        handleFirestoreError(err, OperationType.LIST, FLOORS_COLLECTION);
      }
    }
  );
}

/**
 * Real-time listener for BillHeader settings
 */
export function subscribeToBillHeader(
  onUpdate: (header: BillHeader) => void,
  onError?: (error: Error) => void
): () => void {
  const headerPath = `${SETTINGS_COLLECTION}/${HEADER_DOC}`;
  const headerRef = doc(db, SETTINGS_COLLECTION, HEADER_DOC);

  return onSnapshot(
    headerRef,
    (docSnap) => {
      if (docSnap.exists()) {
        onUpdate(docSnap.data() as BillHeader);
      }
    },
    (err) => {
      console.error('Error listening to Bill Header in Firestore:', err);
      if (onError) onError(err);
      if (err?.code === 'permission-denied' || err?.message?.includes('insufficient permissions')) {
        handleFirestoreError(err, OperationType.GET, headerPath);
      }
    }
  );
}

/**
 * Real-time listener for UnitSqftConfig settings
 */
export function subscribeToSqftConfig(
  onUpdate: (config: UnitSqftConfig) => void,
  onError?: (error: Error) => void
): () => void {
  const sqftPath = `${SETTINGS_COLLECTION}/${SQFT_DOC}`;
  const sqftRef = doc(db, SETTINGS_COLLECTION, SQFT_DOC);

  return onSnapshot(
    sqftRef,
    (docSnap) => {
      if (docSnap.exists()) {
        onUpdate(docSnap.data() as UnitSqftConfig);
      }
    },
    (err) => {
      console.error('Error listening to Unit Sqft Config in Firestore:', err);
      if (onError) onError(err);
      if (err?.code === 'permission-denied' || err?.message?.includes('insufficient permissions')) {
        handleFirestoreError(err, OperationType.GET, sqftPath);
      }
    }
  );
}

/**
 * Save or update a single floor entry in Firestore
 */
export async function saveFloorToFirestore(floor: FloorEntry): Promise<void> {
  const path = `${FLOORS_COLLECTION}/${floor.id}`;
  try {
    await ensureAuthenticated();
    const floorRef = doc(db, FLOORS_COLLECTION, floor.id);
    const clean = sanitizeDocData({
      ...floor,
      updatedAt: new Date().toISOString(),
    });
    await setDoc(floorRef, clean, { merge: true });
  } catch (error: any) {
    if (error?.code === 'permission-denied' || error?.message?.includes('insufficient permissions')) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
    throw error;
  }
}

/**
 * Delete a single floor entry from Firestore
 */
export async function deleteFloorFromFirestore(floorId: string): Promise<void> {
  const path = `${FLOORS_COLLECTION}/${floorId}`;
  try {
    await ensureAuthenticated();
    const floorRef = doc(db, FLOORS_COLLECTION, floorId);
    await deleteDoc(floorRef);
  } catch (error: any) {
    if (error?.code === 'permission-denied' || error?.message?.includes('insufficient permissions')) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
    throw error;
  }
}

/**
 * Batch update multiple floor entries in Firestore
 */
export async function batchSaveFloorsToFirestore(floors: FloorEntry[]): Promise<void> {
  if (floors.length === 0) return;
  const cleanFloors = deduplicateFloors(floors);
  try {
    await ensureAuthenticated();
    const chunks: FloorEntry[][] = [];
    for (let i = 0; i < cleanFloors.length; i += 400) {
      chunks.push(cleanFloors.slice(i, i + 400));
    }
    for (const chunk of chunks) {
      const batch = writeBatch(db);
      for (const floor of chunk) {
        const ref = doc(db, FLOORS_COLLECTION, floor.id);
        batch.set(
          ref,
          {
            ...sanitizeDocData(floor),
            updatedAt: new Date().toISOString(),
          },
          { merge: true }
        );
      }
      await batch.commit();
    }
  } catch (error: any) {
    if (error?.code === 'permission-denied' || error?.message?.includes('insufficient permissions')) {
      handleFirestoreError(error, OperationType.WRITE, FLOORS_COLLECTION);
    }
    throw error;
  }
}

/**
 * Batch delete floor entries from Firestore
 */
export async function batchDeleteFloorsFromFirestore(floorIds: string[]): Promise<void> {
  if (floorIds.length === 0) return;
  try {
    await ensureAuthenticated();
    const chunks: string[][] = [];
    for (let i = 0; i < floorIds.length; i += 400) {
      chunks.push(floorIds.slice(i, i + 400));
    }
    for (const chunk of chunks) {
      const batch = writeBatch(db);
      for (const id of chunk) {
        const ref = doc(db, FLOORS_COLLECTION, id);
        batch.delete(ref);
      }
      await batch.commit();
    }
  } catch (error: any) {
    if (error?.code === 'permission-denied' || error?.message?.includes('insufficient permissions')) {
      handleFirestoreError(error, OperationType.DELETE, FLOORS_COLLECTION);
    }
    throw error;
  }
}

/**
 * Save bill header configuration to Firestore
 */
export async function saveBillHeaderToFirestore(header: BillHeader): Promise<void> {
  const path = `${SETTINGS_COLLECTION}/${HEADER_DOC}`;
  try {
    await ensureAuthenticated();
    const headerRef = doc(db, SETTINGS_COLLECTION, HEADER_DOC);
    await setDoc(
      headerRef,
      {
        ...sanitizeDocData(header),
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error: any) {
    if (error?.code === 'permission-denied' || error?.message?.includes('insufficient permissions')) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
    throw error;
  }
}

/**
 * Reset all floors and header to initial state in Firestore
 */
export async function resetAllFirestoreData(
  initialFloors: FloorEntry[],
  initialHeader: BillHeader
): Promise<void> {
  try {
    await ensureAuthenticated();
    const floorsRef = collection(db, FLOORS_COLLECTION);
    const snap = await getDocs(floorsRef);
    const deleteBatch = writeBatch(db);
    snap.forEach((d) => {
      deleteBatch.delete(d.ref);
    });
    await deleteBatch.commit();

    const reseedBatch = writeBatch(db);
    for (const floor of initialFloors) {
      const ref = doc(db, FLOORS_COLLECTION, floor.id);
      reseedBatch.set(ref, {
        ...sanitizeDocData(floor),
        updatedAt: new Date().toISOString(),
      });
    }
    const headerRef = doc(db, SETTINGS_COLLECTION, HEADER_DOC);
    reseedBatch.set(headerRef, {
      ...sanitizeDocData(initialHeader),
      updatedAt: new Date().toISOString(),
    });
    await reseedBatch.commit();
  } catch (error: any) {
    if (error?.code === 'permission-denied' || error?.message?.includes('insufficient permissions')) {
      handleFirestoreError(error, OperationType.WRITE, FLOORS_COLLECTION);
    }
    throw error;
  }
}

// Function aliases for backward compatibility and clean naming
export const saveFloorEntry = saveFloorToFirestore;
export const deleteFloorEntry = deleteFloorFromFirestore;
export const saveBillHeader = saveBillHeaderToFirestore;
export const batchUpdateFloorEntries = batchSaveFloorsToFirestore;
export const batchDeleteFloorEntries = batchDeleteFloorsFromFirestore;
export const saveFloorsToFirestore = batchSaveFloorsToFirestore;

/**
 * Fetch all floors from Firestore once
 */
export async function fetchFloorsFromFirestore(): Promise<FloorEntry[]> {
  try {
    await ensureAuthenticated();
    const floorsRef = collection(db, FLOORS_COLLECTION);
    const snap = await getDocs(floorsRef);
    const result: FloorEntry[] = [];
    snap.forEach((docSnap) => {
      result.push({
        ...(docSnap.data() as FloorEntry),
        id: docSnap.id,
      });
    });
    return sortFloors(deduplicateFloors(result));
  } catch (err: any) {
    console.warn('fetchFloorsFromFirestore warning:', err);
    return [];
  }
}

/**
 * Fetch bill header from Firestore once
 */
export async function fetchBillHeaderFromFirestore(): Promise<BillHeader | null> {
  try {
    await ensureAuthenticated();
    const headerRef = doc(db, SETTINGS_COLLECTION, HEADER_DOC);
    const docSnap = await getDoc(headerRef);
    if (docSnap.exists()) {
      return docSnap.data() as BillHeader;
    }
    return null;
  } catch (err: any) {
    console.warn('fetchBillHeaderFromFirestore warning:', err);
    return null;
  }
}

/**
 * Fetch unit sqft config from Firestore once
 */
export async function fetchUnitSqftConfigFromFirestore(): Promise<UnitSqftConfig | null> {
  try {
    await ensureAuthenticated();
    const sqftRef = doc(db, SETTINGS_COLLECTION, SQFT_DOC);
    const docSnap = await getDoc(sqftRef);
    if (docSnap.exists()) {
      return docSnap.data() as UnitSqftConfig;
    }
    return null;
  } catch (err: any) {
    console.warn('fetchUnitSqftConfigFromFirestore warning:', err);
    return null;
  }
}

/**
 * Save unit sqft config to Firestore
 */
export async function saveUnitSqftConfigToFirestore(config: UnitSqftConfig): Promise<void> {
  const path = `${SETTINGS_COLLECTION}/${SQFT_DOC}`;
  try {
    await ensureAuthenticated();
    const sqftRef = doc(db, SETTINGS_COLLECTION, SQFT_DOC);
    await setDoc(
      sqftRef,
      {
        ...sanitizeDocData(config),
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error: any) {
    if (error?.code === 'permission-denied' || error?.message?.includes('insufficient permissions')) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
    throw error;
  }
}

const USER_BACKUPS_COLLECTION = 'user_backups';

export interface UserLifetimeBackup {
  userEmail: string;
  updatedAt: string;
  totalFloors: number;
  floors: FloorEntry[];
  header: BillHeader;
  sqftConfig: UnitSqftConfig;
}

/**
 * Save full lifetime backup under Gmail ID in Firestore
 */
export async function saveLifetimeUserBackup(
  userEmail: string,
  backupData: { floors: FloorEntry[]; header: BillHeader; sqftConfig: UnitSqftConfig }
): Promise<void> {
  const safeId = userEmail.toLowerCase().replace(/[^a-z0-9]/g, '_');
  const path = `${USER_BACKUPS_COLLECTION}/${safeId}`;
  try {
    await ensureAuthenticated();
    const backupRef = doc(db, USER_BACKUPS_COLLECTION, safeId);
    const payload: UserLifetimeBackup = {
      userEmail: userEmail.toLowerCase(),
      updatedAt: new Date().toISOString(),
      totalFloors: backupData.floors.length,
      floors: backupData.floors.map((f) => sanitizeDocData(f)) as FloorEntry[],
      header: sanitizeDocData(backupData.header) as BillHeader,
      sqftConfig: sanitizeDocData(backupData.sqftConfig) as UnitSqftConfig,
    };
    await setDoc(backupRef, payload, { merge: true });

    // Also update a global latest marker for fallback
    const latestRef = doc(db, USER_BACKUPS_COLLECTION, 'latest');
    await setDoc(latestRef, payload, { merge: true });
  } catch (error: any) {
    console.warn('saveLifetimeUserBackup warning:', error);
    if (error?.code === 'permission-denied' || error?.message?.includes('insufficient permissions')) {
      handleFirestoreError(error, OperationType.WRITE, path);
    }
    throw error;
  }
}

/**
 * Fetch lifetime backup saved for a Gmail ID in Firestore
 */
export async function fetchLifetimeUserBackup(userEmail: string): Promise<UserLifetimeBackup | null> {
  const safeId = userEmail.toLowerCase().replace(/[^a-z0-9]/g, '_');
  try {
    await ensureAuthenticated();
    const backupRef = doc(db, USER_BACKUPS_COLLECTION, safeId);
    const snap = await getDoc(backupRef);
    if (snap.exists()) {
      return snap.data() as UserLifetimeBackup;
    }

    // Try fallback to 'latest'
    const latestRef = doc(db, USER_BACKUPS_COLLECTION, 'latest');
    const latestSnap = await getDoc(latestRef);
    if (latestSnap.exists()) {
      return latestSnap.data() as UserLifetimeBackup;
    }
    return null;
  } catch (err: any) {
    console.warn('fetchLifetimeUserBackup warning:', err);
    return null;
  }
}
