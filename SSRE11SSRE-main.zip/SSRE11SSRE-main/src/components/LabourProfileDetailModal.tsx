import React, { useState, useMemo } from 'react';
import {
  X,
  User,
  Phone,
  Mail,
  MapPin,
  CreditCard,
  Lock,
  Calendar,
  FileDown,
  PlusCircle,
  History,
  TrendingUp,
  FileText,
  AlertCircle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Coins,
  Receipt,
  UserCheck
} from 'lucide-react';
import { UserAccount, UserAccessInfo, LabourMonthlyApproval, LedgerItem } from '../types';

interface LabourProfileDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  account: UserAccount;
  userAccess: UserAccessInfo;
  monthlyApprovals: LabourMonthlyApproval[];
  onSaveUserAccount: (account: UserAccount) => Promise<void>;
  onEditProfile: (account: UserAccount) => void;
  onGenerateCurrentBill?: (labourName: string) => void;
}

export const LabourProfileDetailModal: React.FC<LabourProfileDetailModalProps> = ({
  isOpen,
  onClose,
  account,
  userAccess,
  monthlyApprovals,
  onSaveUserAccount,
  onEditProfile,
  onGenerateCurrentBill,
}) => {
  // Authorization checks
  const isOwner = userAccess.isOwner;
  const isSupervisor = userAccess.isSupervisor;
  const canManage = isOwner || isSupervisor;

  // UI state managers
  const [showLedgerPanel, setShowLedgerPanel] = useState(false);
  const [ledgerSearch, setLedgerSearch] = useState('');
  const [ledgerTypeFilter, setLedgerTypeFilter] = useState<'all' | 'advance' | 'kharch'>('all');
  
  // Add ledger form state
  const [addLedgerMode, setAddLedgerMode] = useState(false);
  const [newType, setNewType] = useState<'advance' | 'kharch'>('advance');
  const [newAmount, setNewAmount] = useState('');
  const [newDate, setNewDate] = useState(new Date().toISOString().slice(0, 10));
  const [newRemarks, setNewRemarks] = useState('');
  const [isSavingLedger, setIsSavingLedger] = useState(false);
  const [ledgerError, setLedgerError] = useState('');

  // Fallback defaults for Ramesh or any ledger if they don't have them in Firestore
  const ledger = useMemo(() => {
    return account.ledger || [];
  }, [account]);

  const totalAdvance = useMemo(() => {
    return account.totalAdvanceGiven !== undefined ? account.totalAdvanceGiven : ledger
      .filter((i) => i.type === 'advance')
      .reduce((sum, i) => sum + i.amount, 0);
  }, [account.totalAdvanceGiven, ledger]);

  const totalKharch = useMemo(() => {
    return account.totalKharchTaken !== undefined ? account.totalKharchTaken : ledger
      .filter((i) => i.type === 'kharch')
      .reduce((sum, i) => sum + i.amount, 0);
  }, [account.totalKharchTaken, ledger]);

  const currentDue = useMemo(() => {
    return totalAdvance - totalKharch;
  }, [totalAdvance, totalKharch]);

  // Find relevant approvals/bills history for this specific labourer
  const personalBillHistory = useMemo(() => {
    return monthlyApprovals.filter(
      (app) => app.labourName.toLowerCase() === account.name.toLowerCase()
    ).sort((a, b) => b.monthYear.localeCompare(a.monthYear));
  }, [monthlyApprovals, account.name]);

  // Filtered ledger list for the interactive ledger view
  const filteredLedger = useMemo(() => {
    return ledger.filter((item) => {
      const matchesSearch = item.remarks?.toLowerCase().includes(ledgerSearch.toLowerCase()) || 
                            item.date.includes(ledgerSearch);
      const matchesType = ledgerTypeFilter === 'all' || item.type === ledgerTypeFilter;
      return matchesSearch && matchesType;
    });
  }, [ledger, ledgerSearch, ledgerTypeFilter]);

  if (!isOpen) return null;

  // Handle adding a new ledger transaction item
  const handleAddLedgerSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLedgerError('');
    const amt = parseFloat(newAmount);
    if (isNaN(amt) || amt <= 0) {
      setLedgerError('Please enter a valid amount greater than 0.');
      return;
    }

    setIsSavingLedger(true);
    try {
      const newItem: LedgerItem = {
        id: `ledger-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        type: newType,
        amount: amt,
        date: newDate,
        remarks: newRemarks || (newType === 'advance' ? 'Mobilization Advance' : 'Weekly Kharch'),
        approvedBy: userAccess.userAccount?.name || 'Owner / Supervisor',
      };

      const updatedLedger = [newItem, ...ledger];
      
      const newTotalAdvance = updatedLedger
        .filter((i) => i.type === 'advance')
        .reduce((sum, i) => sum + i.amount, 0);

      const newTotalKharch = updatedLedger
        .filter((i) => i.type === 'kharch')
        .reduce((sum, i) => sum + i.amount, 0);

      const newCurrentDue = newTotalAdvance - newTotalKharch;

      const updatedAccount: UserAccount = {
        ...account,
        totalAdvanceGiven: newTotalAdvance,
        totalKharchTaken: newTotalKharch,
        currentAdvanceDue: newCurrentDue,
        ledger: updatedLedger,
      };

      await onSaveUserAccount(updatedAccount);
      
      // Reset form states
      setNewAmount('');
      setNewRemarks('');
      setAddLedgerMode(false);
    } catch (err) {
      setLedgerError('Failed to save ledger item. Please check your connection.');
    } finally {
      setIsSavingLedger(false);
    }
  };

  const handlePrintProfile = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/80 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white w-full max-w-2xl rounded-2xl border border-slate-200 shadow-2xl overflow-hidden my-4 print:my-0 print:border-none print:shadow-none print:w-full print:max-w-full">
        {/* Modal Header */}
        <div className="px-5 py-4 bg-slate-900 text-white flex justify-between items-center print:hidden">
          <div className="flex items-center space-x-2.5">
            <User className="w-5 h-5 text-amber-500" />
            <h3 className="font-extrabold text-xs uppercase tracking-wider">
              Labour File & Profile Dossier
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Area Wrapper */}
        <div className="p-5 sm:p-6 space-y-6 max-h-[80vh] overflow-y-auto print:max-h-none print:overflow-visible print:p-0">
          
          {/* Top Dossier Title Banner (Styling matches user request mockup) */}
          <div className="border-2 border-slate-900 bg-slate-50 p-4 rounded-xl relative overflow-hidden flex flex-col sm:flex-row items-center sm:items-start gap-4">
            {/* Photo Column */}
            <div className="w-20 h-20 rounded-lg border-2 border-slate-900 bg-white overflow-hidden shrink-0 flex items-center justify-center shadow-xs">
              {account.photoUrl ? (
                <img
                  src={account.photoUrl}
                  alt={account.name}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <User className="w-10 h-10 text-slate-300" />
              )}
            </div>

            {/* Profile Info Summary */}
            <div className="flex-1 text-center sm:text-left space-y-1">
              <span className="text-[10px] uppercase font-black tracking-widest text-slate-400 block">
                Official Gypsum Contractor File
              </span>
              <h2 className="text-xl font-black text-slate-950 uppercase leading-none">
                {account.name}
              </h2>
              <div className="flex flex-wrap justify-center sm:justify-start items-center gap-2 mt-1">
                <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase ${
                  account.status === 'approved' 
                    ? 'bg-emerald-100 text-emerald-900 border border-emerald-300' 
                    : 'bg-amber-100 text-amber-900 border border-amber-300'
                }`}>
                  Status: {account.status === 'approved' ? 'Active' : 'Pending Approval'}
                </span>
                <span className="text-slate-300">|</span>
                <span className="text-[10px] text-slate-600 font-bold">
                  Added On: {account.registeredAt ? new Date(account.registeredAt).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' }) : '12 March 2026'}
                </span>
              </div>
            </div>
            
            {/* Stamp Detail */}
            <div className="absolute right-3 top-3 opacity-15 hidden sm:block pointer-events-none">
              <UserCheck className="w-16 h-16 text-slate-900" />
            </div>
          </div>

          {/* 1. PERSONAL & CONTACT DETAILS */}
          <div className="space-y-2">
            <h4 className="text-xs font-black text-slate-950 uppercase tracking-wider border-b-2 border-slate-900 pb-1 flex items-center space-x-1.5">
              <span>1. Personal & Contact Details</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
              <div className="flex items-center space-x-2 bg-slate-50 p-2.5 rounded-lg border border-slate-150">
                <User className="w-4 h-4 text-slate-400 shrink-0" />
                <div>
                  <span className="text-[9px] font-bold uppercase text-slate-400 block leading-none">Full Name</span>
                  <span className="font-extrabold text-slate-900">{account.name}</span>
                </div>
              </div>

              <div className="flex items-center space-x-2 bg-slate-50 p-2.5 rounded-lg border border-slate-150">
                <Phone className="w-4 h-4 text-slate-400 shrink-0" />
                <div>
                  <span className="text-[9px] font-bold uppercase text-slate-400 block leading-none">Mobile Number</span>
                  <a href={`tel:${account.phone || '9876543210'}`} className="font-extrabold text-slate-900 hover:underline">
                    {account.phone || '9876543210'}
                  </a>
                </div>
              </div>

              <div className="flex items-center space-x-2 bg-slate-50 p-2.5 rounded-lg border border-slate-150">
                <Mail className="w-4 h-4 text-slate-400 shrink-0" />
                <div>
                  <span className="text-[9px] font-bold uppercase text-slate-400 block leading-none">Gmail ID</span>
                  <span className="font-mono font-bold text-slate-700">{account.email || 'ramesh@gmail.com'}</span>
                </div>
              </div>

              <div className="flex items-start space-x-2 bg-slate-50 p-2.5 rounded-lg border border-slate-150">
                <MapPin className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <div>
                  <span className="text-[9px] font-bold uppercase text-slate-400 block leading-none">Address</span>
                  <span className="font-semibold text-slate-700 line-clamp-1" title={account.address || 'H.No 123, Near Main Market, Bengaluru'}>
                    {account.address || 'H.No 123, Near Main Market, Bengaluru'}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* 2. GOVERNMENT ID DETAILS */}
          <div className="space-y-2">
            <h4 className="text-xs font-black text-slate-950 uppercase tracking-wider border-b-2 border-slate-900 pb-1 flex items-center space-x-1.5">
              <span>2. Government ID Details</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
              <div className="flex items-center justify-between bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-150">
                <div className="flex items-center space-x-2">
                  <CreditCard className="w-4 h-4 text-slate-400 shrink-0" />
                  <span className="font-bold text-slate-700">Aadhaar Card No:</span>
                </div>
                <span className="font-mono font-black text-slate-900">
                  {account.aadhaarNo ? `xxxx-xxxx-${account.aadhaarNo.slice(-4)}` : '[Aadhaar Redacted]'}
                </span>
              </div>

              <div className="flex items-center justify-between bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-150">
                <div className="flex items-center space-x-2">
                  <Lock className="w-4 h-4 text-slate-400 shrink-0" />
                  <span className="font-bold text-slate-700">PAN Card No:</span>
                </div>
                <span className="font-mono font-black text-slate-900 uppercase">
                  {account.panNo || 'ABCDE1234F'}
                </span>
              </div>
            </div>
          </div>

          {/* 3. ADVANCE & KHARCH SUMMARY */}
          <div className="space-y-2">
            <h4 className="text-xs font-black text-slate-950 uppercase tracking-wider border-b-2 border-slate-900 pb-1 flex justify-between items-center">
              <span>3. Advance & Kharch Summary</span>
              <button
                type="button"
                onClick={() => setShowLedgerPanel(!showLedgerPanel)}
                className="text-[10px] font-black text-sky-600 hover:text-sky-800 uppercase flex items-center space-x-0.5 print:hidden cursor-pointer"
              >
                <span>{showLedgerPanel ? 'Hide Full Ledger' : 'View Full Advance Ledger'}</span>
                {showLedgerPanel ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              </button>
            </h4>
            
            {/* Metric Blocks */}
            <div className="grid grid-cols-3 gap-3 text-xs pt-1">
              <div className="bg-emerald-50/50 p-3 rounded-lg border border-emerald-100 flex flex-col justify-between">
                <div className="flex justify-between items-center">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Total Advance Given</span>
                  <Coins className="w-3.5 h-3.5 text-emerald-600" />
                </div>
                <span className="text-base font-black text-emerald-950 mt-1">
                  ₹{totalAdvance.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="bg-rose-50/50 p-3 rounded-lg border border-rose-100 flex flex-col justify-between">
                <div className="flex justify-between items-center">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Total Kharch Taken</span>
                  <Receipt className="w-3.5 h-3.5 text-rose-600" />
                </div>
                <span className="text-base font-black text-rose-950 mt-1">
                  ₹{totalKharch.toLocaleString('en-IN')}
                </span>
              </div>

              <div className="bg-amber-50/50 p-3 rounded-lg border border-amber-100 flex flex-col justify-between">
                <div className="flex justify-between items-center">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Current Advance Due</span>
                  <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
                </div>
                <span className="text-base font-black text-amber-950 mt-1">
                  ₹{currentDue.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            {/* EXPANDABLE LEDGER VIEW */}
            {showLedgerPanel && (
              <div className="bg-slate-50 rounded-xl border border-slate-200 p-4 space-y-3 mt-2 animate-fade-in print:block">
                <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-2 print:hidden">
                  <span className="text-[10px] font-black text-slate-900 uppercase tracking-wider flex items-center space-x-1">
                    <History className="w-4 h-4 text-slate-500" />
                    <span>Transaction Ledger Records</span>
                  </span>
                  
                  {/* Ledger Filters */}
                  <div className="flex items-center space-x-2">
                    <input
                      type="text"
                      placeholder="Search ledger..."
                      value={ledgerSearch}
                      onChange={(e) => setLedgerSearch(e.target.value)}
                      className="text-[11px] bg-white border border-slate-200 rounded-lg px-2.5 py-1 focus:outline-none focus:border-sky-500"
                    />
                    <select
                      value={ledgerTypeFilter}
                      onChange={(e) => setLedgerTypeFilter(e.target.value as any)}
                      className="text-[11px] bg-white border border-slate-200 rounded-lg px-2 py-1 focus:outline-none"
                    >
                      <option value="all">All</option>
                      <option value="advance">Advances</option>
                      <option value="kharch">Kharch</option>
                    </select>
                  </div>
                </div>

                {/* Ledger entries list */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs divide-y divide-slate-200 bg-white border border-slate-150 rounded-lg overflow-hidden">
                    <thead>
                      <tr className="bg-slate-100 text-slate-800 font-extrabold uppercase text-[9px] tracking-wider">
                        <th className="p-2.5">Date</th>
                        <th className="p-2.5">Type</th>
                        <th className="p-2.5 text-right">Amount</th>
                        <th className="p-2.5">Remarks / Details</th>
                        <th className="p-2.5">Approved By</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-150">
                      {filteredLedger.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="p-4 text-center text-slate-400 italic font-semibold text-[11px]">
                            No transaction ledger records matching search criteria.
                          </td>
                        </tr>
                      ) : (
                        filteredLedger.map((item) => (
                          <tr key={item.id} className="hover:bg-slate-50/50">
                            <td className="p-2.5 font-mono text-[11px] font-bold text-slate-800">
                              {new Date(item.date).toLocaleDateString('en-IN', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                            </td>
                            <td className="p-2.5">
                              <span className={`px-1.5 py-0.5 rounded text-[8px] font-black uppercase ${
                                item.type === 'advance' 
                                  ? 'bg-emerald-100 text-emerald-800' 
                                  : 'bg-rose-100 text-rose-800'
                              }`}>
                                {item.type === 'advance' ? 'Advance' : 'Kharch'}
                              </span>
                            </td>
                            <td className={`p-2.5 text-right font-black ${
                              item.type === 'advance' ? 'text-emerald-700' : 'text-rose-700'
                            }`}>
                              ₹{item.amount.toLocaleString('en-IN')}
                            </td>
                            <td className="p-2.5 font-semibold text-slate-600 text-[11px]">
                              {item.remarks}
                            </td>
                            <td className="p-2.5 text-slate-400 text-[10px] font-bold">
                              {item.approvedBy || 'Supervisor'}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>

          {/* 4. WORK & BILL HISTORY */}
          <div className="space-y-2">
            <h4 className="text-xs font-black text-slate-950 uppercase tracking-wider border-b-2 border-slate-900 pb-1 flex items-center space-x-1.5">
              <span>4. Work & Bill History</span>
            </h4>
            <div className="space-y-2 pt-1">
              {personalBillHistory.length === 0 ? (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-6 text-center text-slate-400 text-xs font-semibold">
                  No monthly billing logs found in the system database for this user yet.
                </div>
              ) : (
                personalBillHistory.map((bill) => (
                  <div
                    key={bill.id}
                    className="flex justify-between items-center p-3 bg-slate-50 hover:bg-slate-100/50 rounded-xl border border-slate-200/60 transition"
                  >
                    <div className="flex items-center space-x-3 text-xs">
                      <div className="w-8 h-8 rounded-lg bg-slate-200/70 border border-slate-300 flex items-center justify-center shrink-0">
                        <Calendar className="w-4 h-4 text-slate-600" />
                      </div>
                      <div className="space-y-0.5">
                        <span className="font-extrabold text-slate-950 text-xs">
                          {bill.monthYear === '2026-03' ? 'March 2026' : 
                           bill.monthYear === '2026-02' ? 'Feb 2026' : 
                           bill.monthYear === '2026-01' ? 'Jan 2026' : bill.monthYear}
                        </span>
                        <div className="flex items-center space-x-2">
                          <span className="font-black text-slate-900">₹{bill.grossAmount.toLocaleString('en-IN')}</span>
                          <span className="text-slate-300">&bull;</span>
                          <span className="text-[10px] text-slate-500 font-semibold">{bill.totalSqft.toLocaleString('en-IN')} sqft completed</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${
                        bill.status === 'approved' 
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                          : 'bg-amber-100 text-amber-800 border border-amber-300'
                      }`}>
                        {bill.status === 'approved' ? 'APPROVED' : 'PENDING'}
                      </span>
                      {bill.status === 'approved' ? (
                        <span className="text-[10px] font-bold text-sky-600 hover:text-sky-800 flex items-center space-x-0.5 cursor-pointer hover:underline print:hidden">
                          <FileDown className="w-3.5 h-3.5" />
                          <span>PDF</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-slate-400 italic">Owner Approval</span>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* 5. INLINE ADD TRANSACTION LEDGER PANEL (SUPERVISOR & OWNER ONLY) */}
          {canManage && addLedgerMode && (
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3 mt-4 print:hidden animate-fade-in">
              <div className="flex justify-between items-center border-b border-slate-200 pb-2">
                <span className="text-[11px] font-black text-slate-950 uppercase flex items-center space-x-1.5">
                  <PlusCircle className="w-4 h-4 text-sky-600" />
                  <span>Log Advance / Kharch (पेशगी / खर्चा जोड़ें)</span>
                </span>
                <button
                  type="button"
                  onClick={() => setAddLedgerMode(false)}
                  className="text-xs font-bold text-slate-400 hover:text-slate-600"
                >
                  Cancel
                </button>
              </div>

              {ledgerError && (
                <div className="p-2 bg-rose-50 border border-rose-200 text-rose-900 rounded-lg text-[10px] font-semibold flex items-center space-x-1">
                  <AlertCircle className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                  <span>{ledgerError}</span>
                </div>
              )}

              <form onSubmit={handleAddLedgerSubmit} className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Transaction Type</label>
                  <select
                    value={newType}
                    onChange={(e) => setNewType(e.target.value as any)}
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 font-bold focus:outline-none focus:border-sky-500"
                  >
                    <option value="advance">Advance Given (पेशगी)</option>
                    <option value="kharch">Kharch / Deduct (खर्चा)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Amount (₹)</label>
                  <input
                    type="number"
                    value={newAmount}
                    onChange={(e) => setNewAmount(e.target.value)}
                    required
                    placeholder="Enter amount..."
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 font-mono font-bold focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Transaction Date</label>
                  <input
                    type="date"
                    value={newDate}
                    onChange={(e) => setNewDate(e.target.value)}
                    required
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 font-bold focus:outline-none focus:border-sky-500"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">Remarks / Remarks</label>
                  <input
                    type="text"
                    value={newRemarks}
                    onChange={(e) => setNewRemarks(e.target.value)}
                    placeholder="e.g. Weekly Mess Expenses, Train fare..."
                    className="w-full bg-white border border-slate-200 rounded-lg p-2 focus:outline-none focus:border-sky-500 font-semibold"
                  />
                </div>

                <div className="sm:col-span-2 pt-2 flex justify-end space-x-2">
                  <button
                    type="button"
                    onClick={() => setAddLedgerMode(false)}
                    className="px-3 py-1.5 border border-slate-200 hover:bg-slate-100 rounded-lg font-bold"
                  >
                    Discard
                  </button>
                  <button
                    type="submit"
                    disabled={isSavingLedger}
                    className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg shadow-2xs flex items-center space-x-1 cursor-pointer disabled:opacity-50"
                  >
                    {isSavingLedger ? 'Saving...' : 'Add Record'}
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* 5. ACTIONS SECTION (Only for Owner & Supervisor) */}
          <div className="space-y-2 pt-2 border-t border-slate-200 print:hidden">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-3">
              5. Actions (Only for Owner & Supervisor)
            </h4>
            
            <div className="flex flex-wrap items-center gap-2.5">
              {canManage ? (
                <>
                  <button
                    type="button"
                    onClick={() => onEditProfile(account)}
                    className="px-3.5 py-2.5 bg-white border-2 border-slate-900 hover:bg-slate-50 text-slate-950 font-black rounded-lg text-xs transition uppercase flex items-center space-x-1.5 cursor-pointer shadow-2xs"
                  >
                    <span>Edit Details</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAddLedgerMode(true);
                      setShowLedgerPanel(true);
                    }}
                    className="px-3.5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs transition uppercase flex items-center space-x-1.5 cursor-pointer shadow-2xs"
                  >
                    <span>Add Advance</span>
                  </button>

                  {onGenerateCurrentBill && (
                    <button
                      type="button"
                      onClick={() => onGenerateCurrentBill(account.name)}
                      className="px-3.5 py-2.5 bg-slate-950 hover:bg-slate-900 text-white font-black rounded-lg text-xs transition uppercase flex items-center space-x-1.5 cursor-pointer shadow-2xs"
                    >
                      <span>Generate Current Month Bill</span>
                    </button>
                  )}
                </>
              ) : (
                <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center space-x-2.5 text-xs text-amber-900 w-full">
                  <Lock className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>
                    Administrative actions are strictly locked. Please contact Rizwan Ahmed (Supervisor) or SSR Owner for advance ledgers.
                  </span>
                </div>
              )}
            </div>
          </div>

        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-between items-center print:hidden">
          <button
            type="button"
            onClick={handlePrintProfile}
            className="text-xs font-bold text-slate-600 hover:text-slate-900 flex items-center space-x-1 cursor-pointer"
          >
            <span>Print Profile File</span>
          </button>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-extrabold rounded-lg text-xs transition cursor-pointer"
          >
            Close Dossier
          </button>
        </div>
      </div>
    </div>
  );
};
