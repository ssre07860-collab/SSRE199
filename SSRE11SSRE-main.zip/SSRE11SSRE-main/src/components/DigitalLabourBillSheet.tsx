import React from 'react';
import { LabourDigitalBillRecord } from '../types';

interface DigitalLabourBillSheetProps {
  bill: LabourDigitalBillRecord;
  id?: string;
  isPrintMode?: boolean;
}

export const DigitalLabourBillSheet: React.FC<DigitalLabourBillSheetProps> = ({
  bill,
  id = 'digital-bill-sheet',
  isPrintMode = false,
}) => {
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('en-IN', {
      maximumFractionDigits: 0,
    }).format(val);
  };

  return (
    <div
      id={id}
      className={`bg-white text-slate-900 mx-auto font-sans shadow-xl border border-slate-300 transition-all ${
        isPrintMode ? 'p-6 w-full max-w-[800px]' : 'p-6 sm:p-8 max-w-[850px] rounded-xl'
      }`}
      style={{
        boxSizing: 'border-box',
        color: '#111827',
        backgroundColor: '#ffffff',
      }}
    >
      {/* 1. Header Section */}
      <div className="flex flex-col sm:flex-row items-start justify-between border-b-2 border-slate-900 pb-4 gap-4">
        {/* Left: Circular Logo & Brand */}
        <div className="flex items-center space-x-3.5">
          {/* Circular Double-Ring Logo */}
          <div className="relative w-16 h-16 rounded-full border-2 border-red-600 p-0.5 flex items-center justify-center shrink-0 bg-white shadow-xs">
            <div className="w-full h-full rounded-full border-2 border-slate-950 flex flex-col items-center justify-center">
              <span className="text-red-600 font-black text-xs tracking-tighter leading-none">SSR</span>
              <span className="text-[7px] font-black text-slate-900 tracking-widest leading-none mt-0.5">ESTD</span>
            </div>
          </div>

          <div>
            <div className="text-2xl sm:text-3xl font-black text-slate-950 tracking-wide flex items-baseline">
              <span>{bill.companyName || 'SSR ENTERPRISE'}</span>
            </div>
            {/* Red accent line under ENTERPRISE */}
            <div className="h-1 bg-red-600 w-36 rounded-full mt-0.5 mb-1"></div>
            <div className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
              Gypsum &amp; Interior Specialist Contractor
            </div>
          </div>
        </div>

        {/* Right: Company Contact Metadata */}
        <div className="text-right text-[11px] text-slate-700 leading-snug space-y-0.5 sm:max-w-xs">
          <div className="font-semibold text-slate-900">
            Address: {bill.companyAddress || 'Varthur Gunjur Main Road Near Airtel Office\nBengaluru Urban Karnataka -560087'}
          </div>
          <div className="font-bold text-slate-900">Mobile No : {bill.companyMobile || '+919026129779'}</div>
          <div>Email : {bill.companyEmail || 'ssrenterprises111@gmail.com'}</div>
          <div className="font-bold text-slate-900">GSTIN : {bill.companyGstin || '29QZGPS3021A1Z9'}</div>
        </div>
      </div>

      {/* 2. Client Info & Labour Details Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-3.5 border-b border-slate-300 text-xs">
        {/* Left: To Client Info */}
        <div className="space-y-1 pr-2">
          <div className="font-black text-slate-950 uppercase tracking-wider text-[13px]">{bill.toTitle || 'To'}</div>
          <div className="font-bold text-slate-800 whitespace-pre-line leading-relaxed">
            {bill.clientAddress || 'Address:- Prestige Lavender Field Varthur\nBangalore Karnataka -560087'}
          </div>
          {bill.clientMobile && (
            <div className="text-slate-700 font-semibold">Mobile No:- {bill.clientMobile}</div>
          )}
          <div className="text-slate-800 font-bold italic pt-1">{bill.salutation || 'Dear Sir/Madam'}</div>
        </div>

        {/* Right: Labour & Bill Reference Info */}
        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 space-y-1.5 text-xs shadow-2xs">
          <div className="flex justify-between items-center border-b border-slate-200 pb-1">
            <span className="font-bold text-slate-600 uppercase text-[11px]">LABOUR NAME :</span>
            <span className="font-black text-slate-950 uppercase text-[13px] text-emerald-800">{bill.labourName}</span>
          </div>

          <div className="flex justify-between items-center border-b border-slate-200 pb-1">
            <span className="font-bold text-slate-600 uppercase text-[11px]">PAY BILL NO :</span>
            <span className="font-black text-slate-950 bg-amber-100 px-2 py-0.5 rounded border border-amber-300">
              {bill.billNo}
            </span>
          </div>

          <div className="flex justify-between items-center border-b border-slate-200 pb-1">
            <span className="font-bold text-slate-600 uppercase text-[11px]">BILLING DATE :</span>
            <span className="font-bold text-slate-900">{bill.billingDate}</span>
          </div>

          <div className="flex justify-between items-center border-b border-slate-200 pb-1">
            <span className="font-bold text-slate-600 uppercase text-[11px]">PAYMENT DATE :</span>
            <span className="font-bold text-slate-900">{bill.paymentDate}</span>
          </div>

          {bill.labourAadhaar && (
            <div className="flex justify-between items-center pt-0.5">
              <span className="font-bold text-slate-600 uppercase text-[11px]">LABOUR AADHAR :</span>
              <span className="font-mono font-bold text-slate-800">{bill.labourAadhaar}</span>
            </div>
          )}
        </div>
      </div>

      {/* 3. Intro Note */}
      <div className="pt-2 pb-1 text-center text-xs font-semibold text-slate-800">
        {bill.introNote || 'Thank You For Your Valuable Inquiry. We Are Pleased To Quotes As Below :'}
      </div>

      {/* Red Starred / Dotted Divider */}
      <div className="text-center text-red-600 font-bold tracking-widest text-xs select-none overflow-hidden my-1">
        ************************************************************************************************
      </div>

      {/* 4. Table of Work Items */}
      <div className="overflow-x-auto my-2">
        <table className="w-full border-collapse border-2 border-slate-900 text-xs">
          <thead>
            <tr className="bg-slate-100 text-slate-950 font-black border-b-2 border-slate-900 uppercase">
              <th className="border border-slate-900 px-2 py-2 text-center w-20">T = NO</th>
              <th className="border border-slate-900 px-3 py-2 text-left">DESCRIPTION</th>
              <th className="border border-slate-900 px-2 py-2 text-center w-20">QYT</th>
              <th className="border border-slate-900 px-2 py-2 text-center w-20">RATE</th>
              <th className="border border-slate-900 px-3 py-2 text-right w-24">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            {bill.items && bill.items.length > 0 ? (
              bill.items.map((item, index) => (
                <tr
                  key={item.id || index}
                  className={`border-b border-slate-800 text-slate-900 ${
                    index % 2 === 1 ? 'bg-slate-50/70' : 'bg-white'
                  }`}
                >
                  <td className="border border-slate-800 px-2 py-1.5 text-center font-bold text-slate-900 whitespace-nowrap">
                    {item.towerOrFloor || 'T=1/PLF'}
                  </td>
                  <td className="border border-slate-800 px-3 py-1.5 font-medium text-slate-900 leading-tight">
                    {item.description}
                  </td>
                  <td className="border border-slate-800 px-2 py-1.5 text-center font-bold text-slate-950">
                    {item.quantity}
                  </td>
                  <td className="border border-slate-800 px-2 py-1.5 text-center font-semibold text-slate-900">
                    {item.rate}
                  </td>
                  <td className="border border-slate-800 px-3 py-1.5 text-right font-black text-slate-950">
                    {formatCurrency(item.total)}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={5} className="border border-slate-800 p-4 text-center text-slate-500 font-semibold">
                  No work items in this bill
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Red Starred / Dotted Divider below table */}
      <div className="text-center text-red-600 font-bold tracking-widest text-xs select-none overflow-hidden my-1">
        ************************************************************************************************
      </div>

      {/* 5. Three Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-3">
        {/* Card 1: TOTAL WORK AMOUNT */}
        <div className="border border-slate-400 rounded-lg p-2.5 text-center bg-white shadow-2xs">
          <div className="font-bold text-amber-800 text-xs uppercase tracking-tight">
            ( 1 ) TOTAL WORK AMOUNT
          </div>
          <div className="border border-slate-300 rounded mt-1.5 py-1.5 bg-slate-50 font-black text-slate-950 text-base sm:text-lg">
            Rs. {formatCurrency(bill.totalWorkAmount)}
          </div>
          <div className="text-[10px] text-slate-500 font-semibold mt-1">
            Gross Bill ({bill.monthYear || 'Current Cycle'})
          </div>
        </div>

        {/* Card 2: TOTAL KHARCHA */}
        <div className="border border-slate-400 rounded-lg p-2.5 text-center bg-white shadow-2xs">
          <div className="font-bold text-amber-800 text-xs uppercase tracking-tight">
            ( 2 ) TOTAL KHARCHA
          </div>
          <div className="border border-slate-300 rounded mt-1.5 py-1.5 bg-slate-50 font-black text-slate-950 text-base sm:text-lg">
            Rs. {formatCurrency(bill.totalKharcha)}
          </div>
          <div className="text-[10px] text-slate-500 font-semibold mt-1">
            Advance &amp; Site Paid
          </div>
        </div>

        {/* Card 3: NET BALANCE PAYABLE */}
        <div className="border-2 border-emerald-600 rounded-lg p-2.5 text-center bg-emerald-50/50 shadow-2xs relative">
          <div className="font-black text-emerald-900 text-xs uppercase tracking-tight">
            ( 3 ) NET BALANCE PAYABLE
          </div>
          <div
            className={`border rounded mt-1.5 py-1.5 font-black text-base sm:text-lg ${
              bill.netBalancePayable >= 0
                ? 'border-emerald-500 bg-emerald-100 text-emerald-950'
                : 'border-red-400 bg-red-50 text-red-900'
            }`}
          >
            Rs. {bill.netBalancePayable < 0 ? '-' : ''}
            {formatCurrency(Math.abs(bill.netBalancePayable))}
          </div>
          <div className="text-[10px] text-emerald-800 font-bold mt-1">
            {bill.netBalancePayable >= 0 ? 'Payable to Labour' : 'Advance Due / Kharcha Excess'}
          </div>
        </div>
      </div>

      {/* 6. In Words Amount */}
      <div className="border-y-2 border-slate-900 py-2 px-3 my-3 bg-slate-50 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-1">
        <span className="font-black text-slate-950 uppercase tracking-wide">In Words Amount :-</span>
        <span className="font-bold text-slate-900 italic text-right flex-1 sm:pl-2">
          {bill.amountInWords || 'Zero Rupees Only'}
        </span>
      </div>

      {/* 7. Signatures Row */}
      <div className="grid grid-cols-3 gap-4 pt-8 pb-2 text-center text-xs">
        {/* Labour Signature */}
        <div className="flex flex-col items-center justify-end">
          <div className="font-bold text-slate-900 uppercase text-xs pb-1 tracking-wider">
            {bill.labourSignText || bill.labourName || 'SSR'}
          </div>
          <div className="w-3/4 border-t-2 border-slate-900 pt-1 font-black text-slate-800 text-[11px] uppercase">
            Labour Signature
          </div>
        </div>

        {/* Site Supervisor Sign */}
        <div className="flex flex-col items-center justify-end">
          <div className="font-bold text-slate-900 uppercase text-xs pb-1 tracking-wider">
            {bill.supervisorSignText || 'Ramu Kumar'}
          </div>
          <div className="w-3/4 border-t-2 border-slate-900 pt-1 font-black text-slate-800 text-[11px] uppercase">
            Site Supervisor Sign
          </div>
        </div>

        {/* Contractor / For SSR Enterprises */}
        <div className="flex flex-col items-center justify-end">
          <div className="font-serif italic font-black text-slate-900 text-sm pb-1 tracking-wider">
            {bill.contractorSignText || 'Rizwan'}
          </div>
          <div className="w-4/5 border-t-2 border-slate-900 pt-1 font-black text-slate-950 text-[11px] uppercase">
            FOR SSR ENTERPRISES
          </div>
        </div>
      </div>

      {/* Footer tiny print info */}
      <div className="border-t border-slate-200 mt-4 pt-1.5 flex justify-between text-[9px] text-slate-600">
        <span>System Generated Digital Bill &bull; SSR Enterprises Cloud</span>
        <span>Date: {bill.billingDate} &bull; Bill #{bill.billNo}</span>
      </div>
    </div>
  );
};
