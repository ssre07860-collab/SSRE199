import React, { useState } from 'react';
import {
  X,
  Settings,
  Building,
  Calculator,
  Save,
  HardDrive,
  Download,
  Upload,
  RefreshCw,
} from 'lucide-react';
import { BillHeader, UnitSqftConfig } from '../types';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  header: BillHeader;
  sqftConfig: UnitSqftConfig;
  onSaveHeader: (header: BillHeader) => void;
  onSaveSqftConfig: (config: UnitSqftConfig) => void;
  onExportBackupJSON: () => void;
  onImportBackupJSON: (file: File) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  header,
  sqftConfig,
  onSaveHeader,
  onSaveSqftConfig,
  onExportBackupJSON,
  onImportBackupJSON,
}) => {
  const [headerForm, setHeaderForm] = useState<BillHeader>(header);
  const [sqftForm, setSqftForm] = useState<UnitSqftConfig>(sqftConfig);
  const [activeTab, setActiveTab] = useState<'bill' | 'sqft' | 'backup'>('bill');

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveHeader(headerForm);
    onSaveSqftConfig(sqftForm);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Settings className="w-5 h-5 text-emerald-400" />
            <h2 className="text-base font-black">Project &amp; Bill Configuration</h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-4 text-xs font-bold">
          <button
            type="button"
            onClick={() => setActiveTab('bill')}
            className={`py-3 px-3 border-b-2 transition ${
              activeTab === 'bill'
                ? 'border-emerald-600 text-emerald-900 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Bill Header &amp; Signatures
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('sqft')}
            className={`py-3 px-3 border-b-2 transition ${
              activeTab === 'sqft'
                ? 'border-emerald-600 text-emerald-900 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Unit Sqft Dimensions
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('backup')}
            className={`py-3 px-3 border-b-2 transition ${
              activeTab === 'backup'
                ? 'border-emerald-600 text-emerald-900 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            Backup &amp; Restore
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSave} className="p-5 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'bill' && (
            <div className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Subcontractor Agency Name
                </label>
                <input
                  type="text"
                  value={headerForm.scName}
                  onChange={(e) => setHeaderForm({ ...headerForm, scName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 font-bold text-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Project Name
                  </label>
                  <input
                    type="text"
                    value={headerForm.projectName}
                    onChange={(e) => setHeaderForm({ ...headerForm, projectName: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Work Type
                  </label>
                  <input
                    type="text"
                    value={headerForm.workType}
                    onChange={(e) => setHeaderForm({ ...headerForm, workType: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Site Supervisor Signature
                  </label>
                  <input
                    type="text"
                    value={headerForm.supervisorSignature}
                    onChange={(e) => setHeaderForm({ ...headerForm, supervisorSignature: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-bold"
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 uppercase mb-1">
                    Contractor Signature / Authority
                  </label>
                  <input
                    type="text"
                    value={headerForm.contractorSignature}
                    onChange={(e) => setHeaderForm({ ...headerForm, contractorSignature: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-bold text-slate-700 uppercase mb-1">
                  Default Labour Rate (₹ / Sqft)
                </label>
                <input
                  type="number"
                  step="0.5"
                  value={headerForm.defaultLabourRate || 7.0}
                  onChange={(e) => setHeaderForm({ ...headerForm, defaultLabourRate: Number(e.target.value) })}
                  className="w-full bg-slate-50 border border-slate-300 rounded-lg p-2 text-slate-900 font-bold"
                />
              </div>
            </div>
          )}

          {activeTab === 'sqft' && (
            <div className="space-y-3 text-xs">
              <p className="text-slate-500 text-[11px]">
                Standard architectural square footage for each unit type. Updating these values will dynamically calculate release quantities for all tower floors.
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {(['unit1', 'unit2', 'unit3', 'unit4', 'unit5', 'unit6', 'unit7', 'unit8', 'lobby', 'starc1', 'starc2'] as const).map((k) => (
                  <div key={k} className="bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                    <label className="block font-bold text-slate-700 uppercase text-[10px] mb-1">
                      {k.replace('unit', 'Unit ').toUpperCase()}
                    </label>
                    <input
                      type="number"
                      value={sqftForm[k]}
                      onChange={(e) => setSqftForm({ ...sqftForm, [k]: Number(e.target.value) })}
                      className="w-full bg-white border border-slate-300 rounded p-1 text-sm font-black text-slate-900"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="space-y-4 text-xs">
              <div className="bg-sky-50 p-3 rounded-xl border border-sky-200">
                <h4 className="font-bold text-sky-900 text-sm mb-1 flex items-center space-x-1.5">
                  <HardDrive className="w-4 h-4 text-sky-700" />
                  <span>Offline &amp; Lifetime Persistence</span>
                </h4>
                <p className="text-sky-800 text-[11px]">
                  All floor records are continuously mirrored to local browser database and synchronized with Google Cloud Firestore in real time.
                </p>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={onExportBackupJSON}
                  className="flex-1 py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg transition flex items-center justify-center space-x-1.5"
                >
                  <Download className="w-4 h-4 text-emerald-400" />
                  <span>Download Backup JSON File</span>
                </button>

                <label className="flex-1 py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-lg border border-slate-300 transition flex items-center justify-center space-x-1.5 cursor-pointer">
                  <Upload className="w-4 h-4 text-sky-600" />
                  <span>Restore from JSON File</span>
                  <input
                    type="file"
                    accept=".json"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        onImportBackupJSON(file);
                        onClose();
                      }
                    }}
                  />
                </label>
              </div>
            </div>
          )}

          <div className="pt-4 border-t border-slate-200 flex justify-end space-x-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex items-center space-x-1 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-lg shadow-md transition"
            >
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
