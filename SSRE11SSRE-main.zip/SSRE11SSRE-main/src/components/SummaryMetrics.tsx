import React from 'react';
import {
  CheckCircle2,
  Clock,
  Layers,
  Calculator,
  ShieldCheck,
  TrendingUp,
} from 'lucide-react';
import { FloorEntry } from '../types';
import { getFloorProgressStatus } from '../utils/floorCalculationHelper';

interface SummaryMetricsProps {
  floors: FloorEntry[];
  selectedTower: string;
  selectedMonth: string;
}

export const SummaryMetrics: React.FC<SummaryMetricsProps> = ({
  floors,
  selectedTower,
  selectedMonth,
}) => {
  let doneFloors = 0;
  let inProgressFloors = 0;
  let pendingFloors = 0;

  let totalReleaseQty = 0;
  let totalHoldQty = 0;
  let totalPaidQty = 0;
  let totalVerifiedFlats = 0;

  floors.forEach((f) => {
    const statusInfo = getFloorProgressStatus(f);
    if (statusInfo.status === 'done') doneFloors++;
    else if (statusInfo.status === 'in_progress') inProgressFloors++;
    else pendingFloors++;

    totalReleaseQty += Number(f.releaseQuantity || 0);
    totalHoldQty += Number(f.holdQuantity || 0);
    totalPaidQty += Number(f.paidQuantity || 0);
    totalVerifiedFlats += Number(f.verifyFlats || 0);
  });

  const completionPercent =
    floors.length > 0 ? Math.round((doneFloors / floors.length) * 100) : 0;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-4">
      {/* 1. Total Floors */}
      <div className="bg-white rounded-xl p-3 border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between text-slate-500 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider">Total Floors</span>
          <Layers className="w-4 h-4 text-slate-400" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-black text-slate-900">{floors.length}</span>
          <span className="text-xs text-slate-500">{selectedTower}</span>
        </div>
        <div className="mt-1 text-[11px] text-slate-500">
          {completionPercent}% overall billed
        </div>
      </div>

      {/* 2. Ready for Billing (Done) */}
      <div className="bg-emerald-50/70 rounded-xl p-3 border border-emerald-200 shadow-xs">
        <div className="flex items-center justify-between text-emerald-700 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider">Done / Billed</span>
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-black text-emerald-900">{doneFloors}</span>
          <span className="text-xs text-emerald-700">Floors</span>
        </div>
        <div className="mt-1 text-[11px] text-emerald-700 font-medium">
          Ready for 80% release
        </div>
      </div>

      {/* 3. In Progress */}
      <div className="bg-amber-50/70 rounded-xl p-3 border border-amber-200 shadow-xs">
        <div className="flex items-center justify-between text-amber-800 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider">In Progress</span>
          <Clock className="w-4 h-4 text-amber-600" />
        </div>
        <div className="flex items-baseline space-x-2">
          <span className="text-2xl font-black text-amber-950">{inProgressFloors}</span>
          <span className="text-xs text-amber-800">Floors</span>
        </div>
        <div className="mt-1 text-[11px] text-amber-800 font-medium">
          {pendingFloors} pending start
        </div>
      </div>

      {/* 4. Release Quantity */}
      <div className="bg-sky-50/70 rounded-xl p-3 border border-sky-200 shadow-xs">
        <div className="flex items-center justify-between text-sky-800 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider">Release (100%)</span>
          <Calculator className="w-4 h-4 text-sky-600" />
        </div>
        <div className="text-lg sm:text-xl font-black text-sky-950 truncate">
          {totalReleaseQty.toLocaleString('en-IN')}
        </div>
        <div className="mt-1 text-[11px] text-sky-700 font-medium">
          Total measured Sqft
        </div>
      </div>

      {/* 5. Paid Quantity (80%) */}
      <div className="bg-teal-50/70 rounded-xl p-3 border border-teal-200 shadow-xs">
        <div className="flex items-center justify-between text-teal-800 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider">Paid Qty (80%)</span>
          <TrendingUp className="w-4 h-4 text-teal-600" />
        </div>
        <div className="text-lg sm:text-xl font-black text-teal-950 truncate">
          {totalPaidQty.toLocaleString('en-IN')}
        </div>
        <div className="mt-1 text-[11px] text-teal-700 font-medium">
          Certified billable Sqft
        </div>
      </div>

      {/* 6. Hold Quantity (20%) */}
      <div className="bg-rose-50/70 rounded-xl p-3 border border-rose-200 shadow-xs">
        <div className="flex items-center justify-between text-rose-800 mb-1">
          <span className="text-xs font-semibold uppercase tracking-wider">Hold Qty (20%)</span>
          <ShieldCheck className="w-4 h-4 text-rose-600" />
        </div>
        <div className="text-lg sm:text-xl font-black text-rose-950 truncate">
          {totalHoldQty.toLocaleString('en-IN')}
        </div>
        <div className="mt-1 text-[11px] text-rose-700 font-medium">
          Retention held for defects
        </div>
      </div>
    </div>
  );
};
