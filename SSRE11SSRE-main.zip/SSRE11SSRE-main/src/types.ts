export type NavTab = 'dashboard' | 'pdfView' | 'mobileCards' | 'monthlySummary' | 'labourPortal' | 'ownerApprovals';

export type UserRole = 'owner' | 'supervisor' | 'labour';

export interface LedgerItem {
  id: string;
  type: 'advance' | 'kharch';
  amount: number;
  date: string;
  remarks?: string;
  approvedBy?: string;
}

export interface UserAccount {
  id: string; // Firebase UID or unique id
  email: string; // Gmail ID e.g. "dilshad.gypsum@gmail.com"
  name: string; // e.g. "Dilshad" or "Site Supervisor"
  phone?: string;
  role: UserRole;
  specialization?: string; // e.g. "Gypsum Master" or "Site Supervisor"
  assignedTower?: string; // e.g. "Tower No 2" or "all"
  ratePerSqft?: number; // e.g. 12
  status: 'approved' | 'pending' | 'rejected';
  registeredAt: string;
  approvedBy?: string;
  approvedAt?: string;
  notes?: string;
  updatedAt?: string;
  address?: string;
  aadhaarNo?: string;
  panNo?: string;
  photoUrl?: string;
  totalAdvanceGiven?: number;
  totalKharchTaken?: number;
  currentAdvanceDue?: number;
  ledger?: LedgerItem[];
  isVerifiedByOwner?: boolean;
  verifiedByEmail?: string;
  verifiedAt?: string;
  mappedLabourName?: string; // Links this Gmail account to floor entry labour name
  canViewBills?: boolean;
}

export type LabourAccount = UserAccount;

export interface UserAccessInfo {
  role: UserRole;
  email?: string;
  userAccount?: UserAccount;
  labourAccount?: LabourAccount;
  labourName?: string;
  isOwner: boolean;
  isSupervisor: boolean;
  isLabour: boolean;
  isApproved: boolean;
  canEdit: boolean;
  canManageUsers: boolean;
  canApproveBills: boolean;
  canManageSites: boolean;
  isVerifiedByOwner?: boolean;
  verifiedByEmail?: string;
  verifiedAt?: string;
  mappedLabourName?: string;
}

export interface LabourMonthlyApproval {
  id: string; // Unique key e.g. "2026-09-Dilshad" or "2026-09-Tower No 2-Dilshad"
  monthYear: string; // "2026-09"
  labourName: string;
  labourEmail?: string;
  towerNo?: string;
  totalSqft: number;
  ratePerSqft: number;
  grossAmount: number;
  holdAmount: number;
  advanceDeduction: number;
  netPayable: number;
  status: 'approved' | 'pending' | 'rejected';
  approvalDate?: string;
  approvedBy?: string; // e.g. "SSR Contractor (Owner)"
  signatureStamp?: string; // e.g. "VERIFIED & APPROVED - SSR ENTERPRISES"
  paymentStatus: 'paid' | 'partial' | 'pending';
  paidAmount?: number;
  paymentMode?: 'cash' | 'upi' | 'bank_transfer' | 'cheque';
  paymentRef?: string;
  remarks?: string;
  updatedAt: string;
}

export type UnitStatus = 'paid' | 'pending' | 'none';

export interface UnitDetail {
  unitKey: string;
  name: string;
  sqft: number;
}

export interface FloorEntry {
  id: string;
  scName: string;
  towerNo: string;
  floorNo: string;
  flatsNo: string;
  // Unit status: 'paid' = "Pid Bill" (green), 'pending' = pending work (yellow), 'none' = blank (white)
  unit1: UnitStatus;
  unit2: UnitStatus;
  unit3: UnitStatus;
  unit4: UnitStatus;
  unit5: UnitStatus;
  unit6: UnitStatus;
  unit7: UnitStatus;
  unit8: UnitStatus;
  lobby: UnitStatus;
  starc1: UnitStatus;
  starc2: UnitStatus;
  releaseQuantity: number;
  holdQuantity: number;
  paidQuantity: number;
  gypsumRunningFlats: number;
  gypsumRunningLobby: number;
  starches1WC: number;
  starches2WC: number;
  verifyFlats: number;
  verifyLobby: number;
  verifyStar1: number;
  verifyStar2: number;
  remarks: string;
  signature: string;
  // Labour wise tracking fields
  labourName?: string; // Common / primary labour for this floor
  unitLabours?: Record<string, string>; // Specific labour for each unit (e.g. { unit1: 'Ramesh', unit2: 'Ramesh', ... })
  date?: string; // Work completion / billing date (e.g. "2026-09-15")
  month?: string; // Billing Month (e.g. "2026-09")
  // Bill / PDF export & print tracking
  billExportStatus?: 'exported' | 'printed' | 'both' | 'pending';
  isBillExported?: boolean;
  isBillPrinted?: boolean;
  billExportDate?: string;
  billNumber?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface LabourWorkItem {
  floorId: string;
  floorNo: string;
  unitKey: string;
  unitLabel: string;
  status: UnitStatus;
  sqft: number;
  labourName: string;
  date?: string;
}

export interface LabourBillSummary {
  labourName: string;
  totalSqft: number;
  ratePerSqft: number;
  grossAmount: number;
  holdPercentage: number;
  holdAmount: number;
  advanceDeduction: number;
  netPayable: number;
  items: LabourWorkItem[];
  floorsCount: number;
  floorsList: string[];
}

export interface LabourBillConfig {
  billNo: string;
  billDate: string;
  ratePerSqft: number;
  holdPercentage: number;
  advanceDeduction: number;
  labourPhone?: string;
  notes?: string;
}

export interface MonthlyLabourSummaryData {
  monthKey: string; // e.g. "2026-09"
  monthLabel: string; // e.g. "Sep 2026"
  fullMonthName: string; // e.g. "September 2026"
  totalSqft: number;
  targetSqft: number;
  completionRate: number;
  floorsCount: number;
  floorsList: string[];
  unitsCount: number;
  grossLabourCost: number;
  advanceDeductions: number;
  holdDeductions: number;
  netLabourCost: number;
  paidAmount: number;
  pendingAmount: number;
  labourBreakdown: Array<{
    labourName: string;
    sqft: number;
    cost: number;
    unitsCount: number;
    equivalentFloors?: number;
    floorsInvolved?: number;
    floorsList?: string[];
  }>;
}

export interface LabourFloorEfficiency {
  labourName: string;
  totalEquivalentFloors: number;
  distinctFloorsCount: number;
  distinctFloorsList: string[];
  totalUnitsDone: number;
  totalSqft: number;
  totalCost: number;
  activeMonthsCount: number;
  avgFloorsPerMonth: number;
  avgSqftPerMonth: number;
  monthlyRates: Array<{
    monthKey: string;
    monthLabel: string;
    equivalentFloors: number;
    distinctFloors: number;
    unitsDone: number;
    sqft: number;
    cost: number;
    changeFromPrevMonthPercent?: number;
  }>;
  peakMonth: {
    monthLabel: string;
    floors: number;
    sqft: number;
  };
  paceStatus: string;
  paceColor: string;
  trend: 'improving' | 'stable' | 'declining';
  sharePercentage: number;
}

export interface LabourProfile {
  id: string;
  name: string;
  phone?: string;
  specialization?: string; // e.g., 'Senior Gypsum Mistri'
  defaultRatePerSqft: number;
  dailyWagesRate?: number;
  teamSize?: number;
  bankDetails?: {
    accountNumber?: string;
    ifsc?: string;
    bankName?: string;
    upiId?: string;
  };
  joiningDate?: string;
  status: 'active' | 'inactive';
  notes?: string;
}

export interface LabourMonthlyBillRecord {
  id: string;
  billNo: string;
  labourId?: string;
  labourName: string;
  monthYear: string; // e.g., "2026-09"
  towerNo: string;
  billDate: string;
  totalUnitsWorked: number;
  completedSqft: number;
  ratePerSqft: number;
  grossAmount: number;
  advancePaid: number;
  deductions: number;
  netPayable: number;
  paymentStatus: 'paid' | 'partial' | 'pending';
  paidAmount: number;
  paymentDate?: string;
  paymentMode?: 'cash' | 'upi' | 'bank_transfer' | 'cheque';
  transactionRef?: string;
  remarks?: string;
}

export interface BillHeader {
  scName: string;
  projectName: string;
  address: string;
  workType: string;
  towerNo: string;
  documentTitle: string;
  date: string;
  supervisorSignature: string;
  contractorSignature: string;
  defaultLabourRate?: number;
  updatedAt?: string;
}

export interface UnitSqftConfig {
  unit1: number;
  unit2: number;
  unit3: number;
  unit4: number;
  unit5: number;
  unit6: number;
  unit7: number;
  unit8: number;
  lobby: number;
  starc1: number;
  starc2: number;
  inactiveUnits?: string[];
  extraUnits?: Array<{ key: string; label: string; sqft: number }>;
  updatedAt?: string;
}

export interface LabourBillItem {
  id: string;
  towerOrFloor: string; // T = NO, e.g. "T=1/PLF", "T=2/FL-11"
  description: string; // Description e.g. "11 Floor Unit No 1,2,3,4,5,6,7,8 (Labour: SSR Bill)"
  quantity: number; // QYT e.g. 5000, 1, 32
  rate: number; // RATE e.g. 1, 120
  total: number; // TOTAL e.g. 5000, 120
}

export interface LabourDigitalBillRecord {
  id: string;
  billNo: string; // PAY BILL NO e.g. "SSR01"
  billingDate: string; // BILLING DATE e.g. "25/07/2026"
  paymentDate: string; // PAYMENT DATE e.g. "10/08/2026"
  monthYear: string; // e.g. "2026-09"
  companyName: string; // "SSR ENTERPRISE"
  companyAddress: string;
  companyMobile: string;
  companyEmail: string;
  companyGstin: string;
  toTitle: string; // "To"
  clientAddress: string;
  clientMobile: string;
  salutation: string; // "Dear Sir/Madam"
  introNote: string; // "Thank You For Your Valuable Inquiry. We Are Pleased To Quotes As Below :"
  labourName: string; // e.g. "SSR BILL" or "Adil Ahmad"
  labourAadhaar: string; // "5684-8584-2200"
  labourMobile?: string;
  towerNo?: string;
  items: LabourBillItem[];
  totalWorkAmount: number; // ( 1 ) TOTAL WORK AMOUNT (Gross Bill)
  totalKharcha: number; // ( 2 ) TOTAL KHARCHA (Advance & Site Paid)
  netBalancePayable: number; // ( 3 ) NET BALANCE PAYABLE (Final Net Amount)
  amountInWords: string; // In Words Amount
  labourSignText: string; // "SSR"
  supervisorSignText: string; // "Ramu Kumar"
  contractorSignText: string; // "Rizwan"
  status?: 'draft' | 'approved' | 'paid';
  createdAt: string;
  updatedAt: string;
}

