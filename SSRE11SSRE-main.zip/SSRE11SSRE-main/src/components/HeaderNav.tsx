import React, { useState } from 'react';
import {
  Building2,
  FileDown,
  Printer,
  Calendar,
  Layers,
  Settings,
  Shield,
  Users,
  RefreshCw,
  HardDrive,
  CheckCircle2,
  ChevronDown,
  UserCheck,
  PlusCircle,
  Mail,
  CloudCheck,
  ShieldCheck,
  Sliders,
  LayoutDashboard,
  UserPlus,
} from 'lucide-react';
import { User as FirebaseUser } from 'firebase/auth';
import { BillHeader, UserAccessInfo } from '../types';

interface HeaderNavProps {
  header: BillHeader;
  selectedTower: string;
  availableTowers: string[];
  onSelectTower: (tower: string) => void;
  onOpenNewTowerModal: () => void;
  selectedMonth: string;
  availableMonths: string[];
  onSelectMonth: (month: string) => void;
  activeView: 'table' | 'cards' | 'labour' | 'monthly' | 'analytics' | 'supervisor';
  onChangeView: (view: 'table' | 'cards' | 'labour' | 'monthly' | 'analytics' | 'supervisor') => void;
  userAccess: UserAccessInfo;
  onOpenUserModal: () => void;
  onOpenSettingsModal: () => void;
  onOpenFloorModal: () => void;
  onOpenAddLabourModal?: () => void;
  onDownloadPDF: (format: 'a3' | 'a4') => void;
  onPrintPreview: () => void;
  isSyncing: boolean;
  onManualSync: () => void;
  lastBackupTime?: string;
  currentUser: FirebaseUser | null;
  onOpenGmailModal: () => void;
  onOpenOwnerAdminModal: () => void;
  onSignOut: () => void;
  pendingWorkCount?: number;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  header,
  selectedTower,
  availableTowers,
  onSelectTower,
  onOpenNewTowerModal,
  selectedMonth,
  availableMonths,
  onSelectMonth,
  activeView,
  onChangeView,
  userAccess,
  onOpenUserModal,
  onOpenSettingsModal,
  onOpenFloorModal,
  onOpenAddLabourModal,
  onDownloadPDF,
  onPrintPreview,
  isSyncing,
  onManualSync,
  lastBackupTime,
  currentUser,
  onOpenGmailModal,
  onOpenOwnerAdminModal,
  pendingWorkCount = 0,
}) => {
  const [showPdfMenu, setShowPdfMenu] = useState(false);
  const [showTowerMenu, setShowTowerMenu] = useState(false);

  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 shadow-md sticky top-0 z-40">
      {/* Top Banner Row */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Brand & Project Identity */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-600 flex items-center justify-center shadow-inner ring-2 ring-emerald-400/40">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="text-base sm:text-lg font-black tracking-tight text-white leading-tight">
                {header.scName || 'SSR ENTERPRISES'}
              </h1>
              <span className="hidden sm:inline-block px-2 py-0.5 text-xs font-bold uppercase rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {header.workType || 'Gypsum Work'}
              </span>
            </div>
            <p className="text-xs text-slate-400 truncate max-w-[280px] sm:max-w-md">
              {header.projectName || 'Prestige Lavender Field'} &bull; Digital Bill Record
            </p>
          </div>
        </div>

        {/* Global Controls & Actions */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Logout Button */}
          <button
            id="logout-btn"
            type="button"
            onClick={() => {
                if (window.confirm('Are you sure you want to logout?')) {
                  onSignOut();
                }
            }}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-900/50 hover:bg-red-800 text-red-200 text-xs font-bold rounded-lg border border-red-800/50 transition"
          >
            <span>Logout</span>
          </button>
          
          {/* Tower Selector Dropdown */}
          <div className="relative">
            <button
              id="tower-selector-btn"
              type="button"
              onClick={() => setShowTowerMenu(!showTowerMenu)}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-lg border border-slate-700 shadow-xs transition"
            >
              <Building2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{selectedTower}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>
            {showTowerMenu && (
              <div
                className="absolute left-0 mt-1.5 w-48 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-1 z-50 text-xs"
                onMouseLeave={() => setShowTowerMenu(false)}
              >
                <div className="px-3 py-1 text-[11px] font-bold text-slate-400 border-b border-slate-800 uppercase">
                  Select Tower
                </div>
                {availableTowers.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => {
                      onSelectTower(t);
                      setShowTowerMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 flex items-center justify-between hover:bg-slate-800 transition ${
                      selectedTower === t ? 'text-emerald-400 font-bold bg-slate-800/60' : 'text-slate-300'
                    }`}
                  >
                    <span>{t}</span>
                    {selectedTower === t && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                  </button>
                ))}
                {userAccess.canManageSites && (
                  <button
                    type="button"
                    onClick={() => {
                      setShowTowerMenu(false);
                      onOpenNewTowerModal();
                    }}
                    className="w-full text-left px-3 py-2 border-t border-slate-800 text-emerald-400 hover:bg-emerald-950/40 flex items-center space-x-1.5 font-bold"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>+ Add New Tower</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Month Selector */}
          <div className="flex items-center space-x-1 bg-slate-800 rounded-lg px-2.5 py-1 border border-slate-700 text-xs">
            <Calendar className="w-3.5 h-3.5 text-amber-400" />
            <select
              id="month-selector"
              value={selectedMonth}
              onChange={(e) => onSelectMonth(e.target.value)}
              className="bg-transparent text-slate-200 font-medium focus:outline-hidden cursor-pointer"
            >
              <option value="__ALL__" className="bg-slate-900 text-white">All Months</option>
              {availableMonths.map((m) => (
                <option key={m} value={m} className="bg-slate-900 text-white">
                  {m}
                </option>
              ))}
            </select>
          </div>

          {/* Sync Status Button */}
          <button
            id="manual-sync-btn"
            type="button"
            onClick={onManualSync}
            disabled={isSyncing}
            title={lastBackupTime ? `Last saved: ${lastBackupTime}` : 'Cloud & Local storage synced'}
            className="flex items-center space-x-1 px-2.5 py-1.5 bg-slate-800/80 hover:bg-slate-700 text-slate-300 text-xs rounded-lg border border-slate-700 transition"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-sky-400 ${isSyncing ? 'animate-spin' : ''}`} />
            <span className="hidden md:inline">{isSyncing ? 'Saving...' : 'Synced'}</span>
          </button>

          {/* PDF Export Dropdown */}
          <div className="relative">
            <button
              id="export-pdf-menu-btn"
              type="button"
              onClick={() => setShowPdfMenu(!showPdfMenu)}
              className="flex items-center space-x-1 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold rounded-lg shadow-xs transition"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>Export PDF</span>
              <ChevronDown className="w-3 h-3 text-emerald-200" />
            </button>
            {showPdfMenu && (
              <div
                className="absolute right-0 mt-1.5 w-48 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl py-1 z-50 text-xs"
                onMouseLeave={() => setShowPdfMenu(false)}
              >
                <button
                  type="button"
                  onClick={() => {
                    setShowPdfMenu(false);
                    onDownloadPDF('a3');
                  }}
                  className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 hover:text-white flex items-center space-x-2"
                >
                  <FileDown className="w-3.5 h-3.5 text-emerald-400" />
                  <div>
                    <div className="font-bold">Vector PDF (A3 Landscape)</div>
                    <div className="text-[10px] text-slate-400">High-Res Multi-Page Print</div>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowPdfMenu(false);
                    onDownloadPDF('a4');
                  }}
                  className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 hover:text-white flex items-center space-x-2"
                >
                  <FileDown className="w-3.5 h-3.5 text-sky-400" />
                  <div>
                    <div className="font-bold">Standard PDF (A4 Landscape)</div>
                    <div className="text-[10px] text-slate-400">Office Print / Compact</div>
                  </div>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowPdfMenu(false);
                    onPrintPreview();
                  }}
                  className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-800 hover:text-white flex items-center space-x-2 border-t border-slate-800"
                >
                  <Printer className="w-3.5 h-3.5 text-amber-400" />
                  <div>
                    <div className="font-bold">Browser Print Preview</div>
                    <div className="text-[10px] text-slate-400">Instant direct printer dialog</div>
                  </div>
                </button>
              </div>
            )}
          </div>

          {/* Quick Add Floor Button (if supervisor / owner) */}
          {userAccess.canEdit && (
            <button
              id="add-floor-entry-btn"
              type="button"
              onClick={onOpenFloorModal}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold rounded-lg shadow-xs transition"
            >
              <PlusCircle className="w-3.5 h-3.5" />
              <span>+ Add / Edit Floor</span>
            </button>
          )}

          {/* Settings Button */}
          {/* Owner Admin Control Center Button */}
          {userAccess.isOwner && (
            <>
              {/* Direct Add Labour Button on Main Portal */}
              {onOpenAddLabourModal && (
                <button
                  id="main-portal-add-labour-btn"
                  type="button"
                  onClick={onOpenAddLabourModal}
                  title="Add Labour with Gmail ID & Rates (मेन पोर्टल से लेबर जोड़ें)"
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-lg shadow-sm border border-emerald-400/80 transition cursor-pointer"
                >
                  <UserPlus className="w-3.5 h-3.5 text-emerald-100 shrink-0" />
                  <span className="hidden sm:inline">+ Add Labour (लेबर जोड़ें)</span>
                  <span className="sm:hidden">+ Labour</span>
                </button>
              )}

              <button
                id="open-owner-admin-btn"
                type="button"
                onClick={onOpenOwnerAdminModal}
                title="Owner Admin Control Center (Full Master Access)"
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-lg shadow-md border border-amber-400/80 transition cursor-pointer"
              >
                <ShieldCheck className="w-4 h-4 text-slate-950 shrink-0" />
                <span className="hidden md:inline">Owner Admin</span>
                <span className="md:hidden">Admin</span>
              </button>

              <button
                id="open-labour-permission-btn"
                type="button"
                onClick={onOpenOwnerAdminModal}
                title="Labour Gmail Access & Permissions (लेबर जीमेल अनुमति)"
                className="hidden lg:flex items-center space-x-1.5 px-3 py-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-black text-xs rounded-lg shadow-sm border border-emerald-500 transition cursor-pointer"
              >
                <Users className="w-3.5 h-3.5 text-emerald-200 shrink-0" />
                <span>Labour Permissions</span>
              </button>
            </>
          )}

          {userAccess.canManageSites && (
            <button
              id="open-settings-btn"
              type="button"
              onClick={onOpenSettingsModal}
              title="Bill Header & Rate Settings"
              className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg border border-slate-700 transition"
            >
              <Settings className="w-4 h-4" />
            </button>
          )}

          {/* Portal Role Badge */}
          <div className={`flex items-center space-x-1.5 px-2.5 py-1.5 text-xs font-black rounded-lg border select-none ${
            userAccess.isLabour
              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-700/60'
              : 'bg-slate-800 text-amber-400 border-slate-700'
          }`}>
            <Shield className={`w-3.5 h-3.5 ${userAccess.isLabour ? 'text-emerald-400' : 'text-amber-400'}`} />
            <span>{userAccess.isLabour ? `Labour: ${userAccess.labourName || 'Portal'}` : 'Owner Portal'}</span>
          </div>

          {/* Gmail ID Login & Lifetime Cloud Backup Button */}
          <button
            id="gmail-login-btn"
            type="button"
            onClick={onOpenGmailModal}
            className={`flex items-center space-x-1.5 px-3 py-1.5 text-xs font-bold rounded-lg border transition shadow-sm ${
              currentUser && !currentUser.isAnonymous
                ? 'bg-slate-800 hover:bg-slate-700 text-emerald-300 border-emerald-500/50'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-400 shadow-md ring-1 ring-emerald-300/40'
            }`}
          >
            {currentUser && !currentUser.isAnonymous ? (
              <>
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <Mail className="w-3.5 h-3.5 text-emerald-400" />
                <span className="max-w-[110px] sm:max-w-[150px] truncate">
                  {currentUser.email || 'Gmail Synced'}
                </span>
              </>
            ) : (
              <>
                <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.15z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>Gmail Login</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Navigation Tabs Row */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 bg-slate-950/60 border-t border-slate-800/80 flex items-center justify-between overflow-x-auto scrollbar-none py-1">
        <div className="flex items-center space-x-1 text-xs">
          {!userAccess.isLabour && (
            <>
              <button
                type="button"
                onClick={() => onChangeView('table')}
                className={`px-3 py-1.5 font-bold rounded-md transition flex items-center space-x-1.5 ${
                  activeView === 'table'
                    ? 'bg-slate-800 text-emerald-400 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Summary Bill Sheet</span>
              </button>

              <button
                type="button"
                onClick={() => onChangeView('cards')}
                className={`px-3 py-1.5 font-bold rounded-md transition flex items-center space-x-1.5 ${
                  activeView === 'cards'
                    ? 'bg-slate-800 text-emerald-400 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Building2 className="w-3.5 h-3.5" />
                <span>Floor Cards View</span>
              </button>
            </>
          )}

          <button
            type="button"
            onClick={() => onChangeView('labour')}
            className={`px-3 py-1.5 font-bold rounded-md transition flex items-center space-x-1.5 ${
              activeView === 'labour'
                ? 'bg-slate-800 text-amber-400 shadow-xs'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>{userAccess.isLabour ? 'My Bill & Work Summary' : 'Labour Billing & Rates'}</span>
          </button>

          {!userAccess.isLabour && (
            <>
              <button
                type="button"
                onClick={() => onChangeView('analytics')}
                className={`px-3 py-1.5 font-bold rounded-md transition flex items-center space-x-1.5 ${
                  activeView === 'analytics'
                    ? 'bg-slate-800 text-teal-400 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <LayoutDashboard className="w-3.5 h-3.5" />
                <span>All Work Dashboard</span>
              </button>

              <button
                type="button"
                onClick={() => onChangeView('monthly')}
                className={`px-3 py-1.5 font-bold rounded-md transition flex items-center space-x-1.5 ${
                  activeView === 'monthly'
                    ? 'bg-slate-800 text-sky-400 shadow-xs'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Monthly Aggregations</span>
              </button>
            </>
          )}
        </div>

        {/* Read-Only Banner for Labour */}
        {userAccess.isLabour && (
          <div className="text-[11px] text-amber-300/90 font-medium px-2 py-0.5 bg-amber-950/40 rounded border border-amber-800/40">
            View-Only Access ({userAccess.labourName || 'Labourer'})
          </div>
        )}
      </div>
    </header>
  );
};
