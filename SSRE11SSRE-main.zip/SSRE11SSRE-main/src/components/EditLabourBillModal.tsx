import React, { useState, useEffect } from 'react';
import { X, Plus, Trash2, Save, Calculator, AlertCircle } from 'lucide-react';
import { LabourDigitalBillRecord, LabourBillItem } from '../types';
import { calculateDigitalBillTotals } from '../utils/digitalLabourBillHelper';

interface EditLabourBillModalProps {
  isOpen: boolean;
  onClose: () => void;
  bill: LabourDigitalBillRecord | null;
  onSave: (updatedBill: LabourDigitalBillRecord) => Promise<void>;
}

export const EditLabourBillModal: React.FC<EditLabourBillModalProps> = ({
  isOpen,
  onClose,
  bill,
  onSave,
}) => {
  const [formData, setFormData] = useState<LabourDigitalBillRecord | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  useEffect(() => {
    if (bill) {
      setFormData(JSON.parse(JSON.stringify(bill)));
    } else {
      setFormData(null);
    }
  }, [bill, isOpen]);

  if (!isOpen || !formData) return null;

  const handleFieldChange = (field: keyof LabourDigitalBillRecord, value: any) => {
    setFormData((prev) => {
      if (!prev) return null;
      const updated = { ...prev, [field]: value };
      if (field === 'totalKharcha' || field === 'items') {
        const totals = calculateDigitalBillTotals(updated.items, Number(updated.totalKharcha) || 0);
        updated.totalWorkAmount = totals.totalWorkAmount;
        updated.netBalancePayable = totals.netBalancePayable;
        updated.amountInWords = totals.amountInWords;
      }
      return updated;
    });
  };

  const handleItemChange = (index: number, field: keyof LabourBillItem, value: any) => {
    setFormData((prev) => {
      if (!prev) return null;
      const newItems = [...prev.items];
      const item = { ...newItems[index], [field]: value };

      if (field === 'quantity' || field === 'rate') {
        const q = field === 'quantity' ? Number(value) || 0 : Number(item.quantity) || 0;
        const r = field === 'rate' ? Number(value) || 0 : Number(item.rate) || 0;
        item.total = Math.round(q * r);
      }

      newItems[index] = item;
      const totals = calculateDigitalBillTotals(newItems, Number(prev.totalKharcha) || 0);
      return {
        ...prev,
        items: newItems,
        totalWorkAmount: totals.totalWorkAmount,
        netBalancePayable: totals.netBalancePayable,
        amountInWords: totals.amountInWords,
      };
    });
  };

  const handleAddItem = () => {
    setFormData((prev) => {
      if (!prev) return null;
      const newItem: LabourBillItem = {
        id: `item-custom-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        towerOrFloor: prev.items[0]?.towerOrFloor || 'T=1/PLF',
        description: 'New Floor Work Item',
        quantity: 1,
        rate: 120,
        total: 120,
      };
      const newItems = [...prev.items, newItem];
      const totals = calculateDigitalBillTotals(newItems, Number(prev.totalKharcha) || 0);
      return {
        ...prev,
        items: newItems,
        totalWorkAmount: totals.totalWorkAmount,
        netBalancePayable: totals.netBalancePayable,
        amountInWords: totals.amountInWords,
      };
    });
  };

  const handleDeleteItem = (index: number) => {
    setFormData((prev) => {
      if (!prev) return null;
      const newItems = prev.items.filter((_, i) => i !== index);
      const totals = calculateDigitalBillTotals(newItems, Number(prev.totalKharcha) || 0);
      return {
        ...prev,
        items: newItems,
        totalWorkAmount: totals.totalWorkAmount,
        netBalancePayable: totals.netBalancePayable,
        amountInWords: totals.amountInWords,
      };
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData) return;
    try {
      setIsSaving(true);
      setSaveError(null);
      await onSave(formData);
      onClose();
    } catch (err: any) {
      console.error('Error saving edited bill:', err);
      setSaveError(err?.message || 'Failed to save bill record');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-4xl rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
          <div className="flex items-center space-x-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center">
              <Calculator className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-black text-white flex items-center space-x-2">
                <span>Edit Labour Monthly Bill Record</span>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 border border-amber-700/60">
                  {formData.billNo}
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Labour: <strong className="text-slate-200">{formData.labourName}</strong> &bull; Month: {formData.monthYear}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1.5 hover:bg-slate-800 rounded-lg transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="overflow-y-auto p-5 space-y-5 flex-1 text-xs">
          {saveError && (
            <div className="p-3 bg-red-950/60 border border-red-800/80 rounded-xl text-red-200 flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{saveError}</span>
            </div>
          )}

          {/* Top Row: Meta Inputs */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/50 p-3.5 rounded-xl border border-slate-800">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Pay Bill No</label>
              <input
                type="text"
                value={formData.billNo}
                onChange={(e) => handleFieldChange('billNo', e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 font-mono font-bold focus:border-amber-400 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Labour Name</label>
              <input
                type="text"
                value={formData.labourName}
                onChange={(e) => handleFieldChange('labourName', e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 font-bold focus:border-amber-400 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Billing Date</label>
              <input
                type="text"
                value={formData.billingDate}
                onChange={(e) => handleFieldChange('billingDate', e.target.value)}
                placeholder="DD/MM/YYYY"
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:border-amber-400 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Payment Date</label>
              <input
                type="text"
                value={formData.paymentDate}
                onChange={(e) => handleFieldChange('paymentDate', e.target.value)}
                placeholder="DD/MM/YYYY"
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:border-amber-400 focus:outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Labour Aadhaar</label>
              <input
                type="text"
                value={formData.labourAadhaar || ''}
                onChange={(e) => handleFieldChange('labourAadhaar', e.target.value)}
                placeholder="5684-8584-2200"
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 font-mono focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Labour Mobile</label>
              <input
                type="text"
                value={formData.labourMobile || ''}
                onChange={(e) => handleFieldChange('labourMobile', e.target.value)}
                placeholder="9876543210"
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Tower Ref</label>
              <input
                type="text"
                value={formData.towerNo || ''}
                onChange={(e) => handleFieldChange('towerNo', e.target.value)}
                placeholder="Tower 1 / Tower 2"
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 focus:border-amber-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-slate-400 font-semibold mb-1">Bill Status</label>
              <select
                value={formData.status || 'approved'}
                onChange={(e) => handleFieldChange('status', e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 font-bold focus:border-amber-400 focus:outline-none"
              >
                <option value="draft">Draft</option>
                <option value="approved">Approved</option>
                <option value="paid">Paid</option>
              </select>
            </div>
          </div>

          {/* Work Items Table Editor */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-200 uppercase tracking-wide">
                Work Details Table ({formData.items.length} Items)
              </span>
              <button
                type="button"
                onClick={handleAddItem}
                className="flex items-center space-x-1.5 px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-xs shadow-xs transition"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Add Item Row</span>
              </button>
            </div>

            <div className="border border-slate-800 rounded-xl overflow-hidden shadow-xs">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="bg-slate-950 text-slate-400 font-bold border-b border-slate-800 text-[11px] uppercase">
                    <th className="p-2 w-24">T = NO</th>
                    <th className="p-2">DESCRIPTION</th>
                    <th className="p-2 w-20 text-center">QYT</th>
                    <th className="p-2 w-20 text-center">RATE</th>
                    <th className="p-2 w-24 text-right">TOTAL (₹)</th>
                    <th className="p-2 w-10 text-center"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
                  {formData.items.map((item, index) => (
                    <tr key={item.id || index} className="hover:bg-slate-800/40">
                      <td className="p-1.5">
                        <input
                          type="text"
                          value={item.towerOrFloor}
                          onChange={(e) => handleItemChange(index, 'towerOrFloor', e.target.value)}
                          className="w-full bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 font-mono text-xs focus:border-amber-400 focus:outline-none"
                        />
                      </td>
                      <td className="p-1.5">
                        <input
                          type="text"
                          value={item.description}
                          onChange={(e) => handleItemChange(index, 'description', e.target.value)}
                          className="w-full bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 text-xs focus:border-amber-400 focus:outline-none"
                        />
                      </td>
                      <td className="p-1.5">
                        <input
                          type="number"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(index, 'quantity', e.target.value)}
                          className="w-full bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 text-xs text-center font-bold focus:border-amber-400 focus:outline-none"
                        />
                      </td>
                      <td className="p-1.5">
                        <input
                          type="number"
                          value={item.rate}
                          onChange={(e) => handleItemChange(index, 'rate', e.target.value)}
                          className="w-full bg-slate-800 border border-slate-700 text-white rounded px-2 py-1 text-xs text-center focus:border-amber-400 focus:outline-none"
                        />
                      </td>
                      <td className="p-1.5 text-right font-mono font-bold text-amber-300">
                        ₹{(item.total || 0).toLocaleString('en-IN')}
                      </td>
                      <td className="p-1.5 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteItem(index)}
                          title="Delete row"
                          className="text-slate-500 hover:text-red-400 p-1 hover:bg-slate-800 rounded transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Financial Summary & Kharcha Box */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-950/70 p-3.5 rounded-xl border border-slate-800">
            {/* Box 1 */}
            <div className="bg-slate-900 border border-slate-700 p-3 rounded-lg text-center">
              <div className="text-amber-400 font-bold text-[11px] uppercase">( 1 ) TOTAL WORK AMOUNT</div>
              <div className="text-lg font-black text-white mt-1 font-mono">
                ₹{formData.totalWorkAmount.toLocaleString('en-IN')}
              </div>
              <div className="text-[10px] text-slate-400">Gross Bill Calculated</div>
            </div>

            {/* Box 2 */}
            <div className="bg-slate-900 border border-amber-500/50 p-3 rounded-lg text-center">
              <div className="text-amber-400 font-bold text-[11px] uppercase">( 2 ) TOTAL KHARCHA</div>
              <div className="mt-1 flex items-center justify-center space-x-1">
                <span className="text-slate-400 text-sm">₹</span>
                <input
                  type="number"
                  value={formData.totalKharcha}
                  onChange={(e) => handleFieldChange('totalKharcha', Number(e.target.value) || 0)}
                  className="w-32 bg-slate-800 border border-amber-400/80 text-amber-300 text-lg font-black text-center rounded px-2 py-0.5 focus:outline-none font-mono"
                />
              </div>
              <div className="text-[10px] text-slate-400 mt-1">Advance &amp; Site Paid Deductions</div>
            </div>

            {/* Box 3 */}
            <div className="bg-slate-900 border border-emerald-500/50 p-3 rounded-lg text-center">
              <div className="text-emerald-400 font-bold text-[11px] uppercase">( 3 ) NET BALANCE PAYABLE</div>
              <div
                className={`text-lg font-black mt-1 font-mono ${
                  formData.netBalancePayable >= 0 ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                ₹{formData.netBalancePayable.toLocaleString('en-IN')}
              </div>
              <div className="text-[10px] text-slate-400">
                {formData.netBalancePayable >= 0 ? 'Net Payable to Labour' : 'Advance Due / Negative'}
              </div>
            </div>
          </div>

          {/* In Words */}
          <div className="p-2.5 bg-slate-950 border border-slate-800 rounded-lg flex items-center space-x-2">
            <span className="font-bold text-slate-400 whitespace-nowrap">In Words:</span>
            <span className="text-amber-300 font-semibold italic">{formData.amountInWords}</span>
          </div>

          {/* Signatures Edit */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Labour Signature Text</label>
              <input
                type="text"
                value={formData.labourSignText}
                onChange={(e) => handleFieldChange('labourSignText', e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Supervisor Signature Text</label>
              <input
                type="text"
                value={formData.supervisorSignText}
                onChange={(e) => handleFieldChange('supervisorSignText', e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 font-bold"
              />
            </div>
            <div>
              <label className="block text-slate-400 font-semibold mb-1">Contractor Sign (SSR Enterprises)</label>
              <input
                type="text"
                value={formData.contractorSignText}
                onChange={(e) => handleFieldChange('contractorSignText', e.target.value)}
                className="w-full bg-slate-800 border border-slate-700 text-white rounded-lg px-2.5 py-1.5 font-bold"
              />
            </div>
          </div>

          {/* Modal Footer */}
          <div className="pt-3 border-t border-slate-800 flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-lg transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="flex items-center space-x-2 px-5 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-lg shadow-md transition disabled:opacity-50 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{isSaving ? 'Saving...' : 'Save Bill Changes'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
