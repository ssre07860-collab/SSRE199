import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Edit2,
  Trash2,
  Check,
  X,
  User,
  Users,
  Sparkles,
  ChevronRight,
  ArrowUpDown,
  FileDown,
  Printer,
  ChevronDown,
  FileCheck,
  CheckCheck,
  Info,
  UserPlus,
} from 'lucide-react';
import { FloorEntry, UnitSqftConfig, BillHeader, UserAccessInfo, UnitStatus, UserAccount } from '../types';
import {
  UNIT_CONFIG_MAP,
  getFloorProgressStatus,
  toggleSingleUnitStatus,
  toggleFloorCompletedStatus,
  getFloorBillingBadgeInfo,
  updateFloorBillingStatus,
} from '../utils/floorCalculationHelper';
import { generateSingleFloorVectorPDF } from '../utils/pdfGenerator';
import { getUnitLabourName, getUniqueLabourNames } from '../utils/labourBillHelper';
import { ConfirmationDialog } from './ConfirmationDialog';
import { UnitLabourEntryModal } from './UnitLabourEntryModal';

interface FloorTableProps {
  floors: FloorEntry[];
  header: BillHeader;
  sqftConfig: UnitSqftConfig;
  userAccess: UserAccessInfo;
  accounts?: UserAccount[];
  onUpdateFloor: (updated: FloorEntry) => void;
  onDeleteFloor: (floorId: string) => void;
  onEditFloorClick: (floor: FloorEntry) => void;
  onSaveAllFloors?: (updatedFloors: FloorEntry[]) => void;
  onOpenAddLabourModal?: () => void;
}

export const FloorTable: React.FC<FloorTableProps> = ({
  floors,
  header,
  sqftConfig,
  userAccess,
  accounts = [],
  onUpdateFloor,
  onDeleteFloor,
  onEditFloorClick,
  onSaveAllFloors,
  onOpenAddLabourModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'done' | 'in_progress' | 'pending'>('all');
  const [billingFilter, setBillingFilter] = useState<'all' | 'billed' | 'exported' | 'printed' | 'pending'>('all');
  const [labourFilter, setLabourFilter] = useState<string>('all');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [openBillingMenuFloorId, setOpenBillingMenuFloorId] = useState<string | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [isLegendOpen, setIsLegendOpen] = useState(false);
  const [floorToDelete, setFloorToDelete] = useState<FloorEntry | null>(null);

  // Labour-Wise Unit Entry Modal state
  const [isUnitLabourModalOpen, setIsUnitLabourModalOpen] = useState(false);
  const [targetFloorForUnitLabour, setTargetFloorForUnitLabour] = useState<string | undefined>(undefined);
  const [targetUnitForUnitLabour, setTargetUnitForUnitLabour] = useState<string | undefined>(undefined);
  const [unitClickMode, setUnitClickMode] = useState<'status' | 'labour'>('status');

  const availableLabours = useMemo(() => getUniqueLabourNames(floors), [floors]);

  // Unit completion statistics for selected tower progress tracking
  const unitProgressStats = useMemo(() => {
    let totalUnits = 0;
    let completedUnits = 0;
    let pendingUnits = 0;
    let notStartedUnits = 0;
    let fullyCompletedFloors = 0;

    floors.forEach((floor) => {
      let floorDoneCount = 0;
      UNIT_CONFIG_MAP.forEach(({ key }) => {
        totalUnits++;
        const status = (floor[key] as UnitStatus) || 'none';
        if (status === 'paid') {
          completedUnits++;
          floorDoneCount++;
        } else if (status === 'pending') {
          pendingUnits++;
        } else {
          notStartedUnits++;
        }
      });
      if (floorDoneCount === UNIT_CONFIG_MAP.length) {
        fullyCompletedFloors++;
      }
    });

    const percent = totalUnits > 0 ? Math.round((completedUnits / totalUnits) * 100) : 0;
    const pendingPercent = totalUnits > 0 ? Math.round((pendingUnits / totalUnits) * 100) : 0;

    return {
      totalUnits,
      completedUnits,
      pendingUnits,
      notStartedUnits,
      fullyCompletedFloors,
      percent,
      pendingPercent,
      totalFloors: floors.length,
    };
  }, [floors]);

  // Billing statistics for progress tracking
  const billingStats = useMemo(() => {
    let exported = 0;
    let printed = 0;
    let both = 0;
    let pending = 0;

    floors.forEach((f) => {
      const isExp = Boolean(f.isBillExported || f.billExportStatus === 'exported' || f.billExportStatus === 'both');
      const isPrt = Boolean(f.isBillPrinted || f.billExportStatus === 'printed' || f.billExportStatus === 'both');
      if (isExp && isPrt) both++;
      else if (isExp) exported++;
      else if (isPrt) printed++;
      else pending++;
    });

    const totalBilled = exported + printed + both;
    const percent = floors.length > 0 ? Math.round((totalBilled / floors.length) * 100) : 0;
    return { exported, printed, both, pending, totalBilled, percent };
  }, [floors]);

  // Filter & Sort floors
  const filteredFloors = useMemo(() => {
    return floors
      .filter((floor) => {
        // Search filter
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchFloor = String(floor.floorNo).toLowerCase().includes(q);
          const matchFlats = (floor.flatsNo || '').toLowerCase().includes(q);
          const matchLabour = (floor.labourName || '').toLowerCase().includes(q);
          if (!matchFloor && !matchFlats && !matchLabour) return false;
        }

        // Status filter
        if (statusFilter !== 'all') {
          const statusInfo = getFloorProgressStatus(floor);
          if (statusInfo.status !== statusFilter) return false;
        }

        // Billing status filter
        if (billingFilter !== 'all') {
          const isExp = Boolean(floor.isBillExported || floor.billExportStatus === 'exported' || floor.billExportStatus === 'both');
          const isPrt = Boolean(floor.isBillPrinted || floor.billExportStatus === 'printed' || floor.billExportStatus === 'both');
          if (billingFilter === 'billed' && !isExp && !isPrt) return false;
          if (billingFilter === 'exported' && !isExp) return false;
          if (billingFilter === 'printed' && !isPrt) return false;
          if (billingFilter === 'pending' && (isExp || isPrt)) return false;
        }

        // Labour filter
        if (labourFilter !== 'all') {
          const targetLabour = labourFilter.toLowerCase();
          const hasFloorLabour = (floor.labourName || '').toLowerCase() === targetLabour;
          const hasUnitLabour = floor.unitLabours && Object.values(floor.unitLabours).some((l) => l.toLowerCase() === targetLabour);
          if (!hasFloorLabour && !hasUnitLabour) return false;
        }

        return true;
      })
      .sort((a, b) => {
        const numA = parseInt(String(a.floorNo).replace(/\D/g, ''), 10) || 0;
        const numB = parseInt(String(b.floorNo).replace(/\D/g, ''), 10) || 0;
        return sortOrder === 'asc' ? numA - numB : numB - numA;
      });
  }, [floors, searchQuery, statusFilter, billingFilter, labourFilter, sortOrder]);

  // Aggregate totals
  const totals = useMemo(() => {
    let rel = 0;
    let hld = 0;
    let pd = 0;
    let rFlats = 0;
    let rLobby = 0;
    let rS1 = 0;
    let rS2 = 0;
    let vFlats = 0;
    let vLobby = 0;
    let vS1 = 0;
    let vS2 = 0;

    filteredFloors.forEach((f) => {
      rel += Number(f.releaseQuantity || 0);
      hld += Number(f.holdQuantity || 0);
      pd += Number(f.paidQuantity || 0);
      rFlats += Number(f.gypsumRunningFlats || 0);
      rLobby += Number(f.gypsumRunningLobby || 0);
      rS1 += Number(f.starches1WC || 0);
      rS2 += Number(f.starches2WC || 0);
      vFlats += Number(f.verifyFlats || 0);
      vLobby += Number(f.verifyLobby || 0);
      vS1 += Number(f.verifyStar1 || 0);
      vS2 += Number(f.verifyStar2 || 0);
    });

    return { rel, hld, pd, rFlats, rLobby, rS1, rS2, vFlats, vLobby, vS1, vS2 };
  }, [filteredFloors]);

  // Handle single unit click
  const handleUnitClick = (floor: FloorEntry, unitKey: keyof FloorEntry) => {
    if (!userAccess.canEdit) return;
    const updated = toggleSingleUnitStatus(floor, unitKey, sqftConfig);
    onUpdateFloor(updated);
  };

  // Handle entire floor toggle
  const handleToggleFloorStatus = (floor: FloorEntry) => {
    if (!userAccess.canEdit) return;
    const statusInfo = getFloorProgressStatus(floor);
    const markCompleted = statusInfo.status !== 'done';
    const updated = toggleFloorCompletedStatus(floor, sqftConfig, markCompleted);
    onUpdateFloor(updated);
  };

  // Handle single floor PDF export
  const handleDownloadSingleFloorPDF = (floor: FloorEntry) => {
    generateSingleFloorVectorPDF(header, sqftConfig, floor, 'a4');
    const isCurrentlyPrinted = Boolean(floor.isBillPrinted || floor.billExportStatus === 'printed' || floor.billExportStatus === 'both');
    const updated = updateFloorBillingStatus(floor, isCurrentlyPrinted ? 'both' : 'exported');
    onUpdateFloor(updated);
    setActionFeedback(`Floor ${floor.floorNo} PDF exported and marked as billed!`);
    setTimeout(() => setActionFeedback(null), 3500);
  };

  // Handle manual billing status change
  const handleSetBillingStatus = (
    floor: FloorEntry,
    status: 'exported' | 'printed' | 'both' | 'pending'
  ) => {
    const updated = updateFloorBillingStatus(floor, status);
    onUpdateFloor(updated);
    const label = status === 'both' ? 'PDF & Printed' : status === 'exported' ? 'PDF Exported' : status === 'printed' ? 'Printed' : 'Pending';
    setActionFeedback(`Floor ${floor.floorNo} marked as: ${label}`);
    setTimeout(() => setActionFeedback(null), 3000);
  };

  // Tower Work Completion Progress
  const towerProgress = useMemo(() => {
    const total = floors.length;
    if (total === 0) return { total: 0, done: 0, inProgress: 0, percent: 0 };
    let done = 0;
    let inProgress = 0;
    floors.forEach((f) => {
      const st = getFloorProgressStatus(f).status;
      if (st === 'done') done++;
      else if (st === 'in_progress') inProgress++;
    });
    const percent = Math.round((done / total) * 100);
    return { total, done, inProgress, percent };
  }, [floors]);

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden mb-8">
      {/* Toast Feedback banner */}
      {actionFeedback && (
        <div className="absolute top-3 right-4 z-40 bg-slate-900 text-white px-3 py-1.5 rounded-lg shadow-xl text-xs font-semibold flex items-center space-x-2 border border-slate-700">
          <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>{actionFeedback}</span>
        </div>
      )}

      {/* Visual Work Completion Progress Bar for Selected Tower */}
      <div className="px-3 sm:px-4 py-2.5 bg-slate-900 text-white border-b border-slate-800">
        <div className="flex flex-wrap items-center justify-between gap-2 text-xs mb-1.5">
          <div className="flex items-center space-x-2">
            <span className="font-black text-amber-400 uppercase tracking-wider text-[11px]">
              {header.towerNo || 'Tower'} Plastering Progress:
            </span>
            <span className="text-slate-200 font-bold">
              {towerProgress.done} of {towerProgress.total} Floors Done
            </span>
            {towerProgress.inProgress > 0 && (
              <span className="text-amber-300 text-[10px] bg-amber-950/70 px-1.5 py-0.5 rounded border border-amber-500/40">
                {towerProgress.inProgress} in progress
              </span>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <span className="font-mono font-black text-emerald-400 text-sm">
              {towerProgress.percent}% Complete
            </span>
          </div>
        </div>

        {/* Dynamic Progress Bar */}
        <div className="w-full h-2.5 bg-slate-950/90 rounded-full overflow-hidden border border-slate-700/80 p-0.5">
          <div
            className="h-full bg-gradient-to-r from-emerald-500 via-teal-400 to-amber-400 rounded-full transition-all duration-500 shadow-inner"
            style={{ width: `${Math.min(100, towerProgress.percent)}%` }}
          />
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="p-3 sm:p-4 bg-slate-50/70 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
        {/* Search Input */}
        <div className="flex items-center space-x-2 flex-1 min-w-[200px] max-w-xs bg-white px-3 py-1.5 rounded-lg border border-slate-300 focus-within:border-emerald-500 focus-within:ring-1 focus-within:ring-emerald-500">
          <Search className="w-4 h-4 text-slate-400" />
          <input
            id="floor-search-input"
            type="text"
            placeholder="Search Floor No, Flats, Labour..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full text-xs sm:text-sm bg-transparent border-none focus:outline-hidden text-slate-800"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="text-slate-400 hover:text-slate-600"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Filter Pills & Selectors */}
        <div className="flex items-center flex-wrap gap-2 text-xs">
          {/* Work Status Filter */}
          <div className="flex items-center space-x-1 bg-white p-1 rounded-lg border border-slate-300">
            <button
              type="button"
              onClick={() => setStatusFilter('all')}
              className={`px-2 py-1 rounded font-semibold transition ${
                statusFilter === 'all' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              All ({floors.length})
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('done')}
              className={`px-2 py-1 rounded font-semibold transition ${
                statusFilter === 'done' ? 'bg-emerald-600 text-white' : 'text-emerald-800 hover:bg-emerald-50'
              }`}
            >
              Done
            </button>
            <button
              type="button"
              onClick={() => setStatusFilter('in_progress')}
              className={`px-2 py-1 rounded font-semibold transition ${
                statusFilter === 'in_progress' ? 'bg-amber-600 text-white' : 'text-amber-800 hover:bg-amber-50'
              }`}
            >
              In Progress
            </button>
          </div>

          {/* Billing / PDF Status Filter */}
          <div className="flex items-center space-x-1 bg-white p-1 rounded-lg border border-slate-300">
            <button
              type="button"
              onClick={() => setBillingFilter('all')}
              className={`px-2 py-1 rounded font-semibold transition ${
                billingFilter === 'all' ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
              title="All billing records"
            >
              All Bills
            </button>
            <button
              type="button"
              onClick={() => setBillingFilter('billed')}
              className={`px-2 py-1 rounded font-semibold transition flex items-center space-x-1 ${
                billingFilter === 'billed' ? 'bg-sky-700 text-white' : 'text-sky-800 hover:bg-sky-50'
              }`}
              title="Floors exported to PDF or printed"
            >
              <FileCheck className="w-3 h-3" />
              <span>Billed ({billingStats.totalBilled})</span>
            </button>
            <button
              type="button"
              onClick={() => setBillingFilter('pending')}
              className={`px-2 py-1 rounded font-semibold transition flex items-center space-x-1 ${
                billingFilter === 'pending' ? 'bg-slate-700 text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
              title="Floors pending bill export or print"
            >
              <Clock className="w-3 h-3" />
              <span>Pending ({billingStats.pending})</span>
            </button>
          </div>

          {/* Labour Filter */}
          {availableLabours.length > 0 && (
            <div className="flex items-center space-x-1 bg-white px-2.5 py-1.5 rounded-lg border border-slate-300">
              <User className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={labourFilter}
                onChange={(e) => setLabourFilter(e.target.value)}
                className="bg-transparent text-slate-700 font-medium focus:outline-hidden cursor-pointer"
              >
                <option value="all">All Labours</option>
                {availableLabours.map((lab) => (
                  <option key={lab} value={lab}>
                    {lab}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Sort Order */}
          <button
            type="button"
            onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
            className="flex items-center space-x-1 px-2.5 py-1.5 bg-white text-slate-700 font-semibold rounded-lg border border-slate-300 hover:bg-slate-100 transition"
          >
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-500" />
            <span>{sortOrder === 'asc' ? 'Floor 1 → 26' : 'Floor 26 → 1'}</span>
          </button>

          {/* Billing Progress Stat Pill */}
          <div
            className="hidden xl:flex items-center space-x-2 px-3 py-1.5 bg-sky-50 border border-sky-200 text-sky-900 rounded-lg text-xs font-bold"
            title="Total tower billing progress: PDF exported or printed floors"
          >
            <div className="flex items-center space-x-1">
              <FileCheck className="w-3.5 h-3.5 text-sky-600" />
              <span>Tower Billing:</span>
            </div>
            <span className="text-sky-700 font-black">
              {billingStats.totalBilled} / {floors.length} Floors
            </span>
            <span className="text-[10px] px-1.5 py-0.2 bg-sky-200/70 text-sky-800 rounded font-black">
              {billingStats.percent}%
            </span>
          </div>

          {/* Add Labour Button on Main Portal Table */}
          {userAccess.isOwner && onOpenAddLabourModal && (
            <button
              id="floor-table-add-labour-btn"
              type="button"
              onClick={onOpenAddLabourModal}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black rounded-lg shadow-xs border border-emerald-500 transition cursor-pointer text-xs"
              title="Add New Labour with Gmail ID (नया लेबर जोड़ें)"
            >
              <UserPlus className="w-3.5 h-3.5 text-emerald-100 shrink-0" />
              <span>+ Add Labour</span>
            </button>
          )}

          {/* Labour Wise Unit Entry Button */}
          {userAccess.canEdit && (
            <button
              id="open-unit-labour-modal-btn"
              type="button"
              onClick={() => {
                setTargetFloorForUnitLabour(undefined);
                setTargetUnitForUnitLabour(undefined);
                setIsUnitLabourModalOpen(true);
              }}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg shadow-xs border border-amber-400 transition cursor-pointer text-xs"
              title="Labour Name Wise Unit Entry (हर यूनिट में लेबर नाम असाइन करें)"
            >
              <Users className="w-3.5 h-3.5 text-slate-950 shrink-0" />
              <span>Labour Wise Unit Entry</span>
            </button>
          )}

          {/* Unit Click Mode Switcher */}
          {userAccess.canEdit && (
            <div
              className="flex items-center space-x-1 bg-white p-1 rounded-lg border border-slate-300 text-[11px]"
              title="Choose click action for unit cells in the table"
            >
              <span className="text-slate-400 font-bold px-1 hidden md:inline">Click:</span>
              <button
                type="button"
                onClick={() => setUnitClickMode('status')}
                className={`px-2 py-0.5 rounded font-bold transition cursor-pointer ${
                  unitClickMode === 'status'
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
                title="Clicking a unit cell cycles its status (Paid/Pending/None)"
              >
                Toggle Status
              </button>
              <button
                type="button"
                onClick={() => setUnitClickMode('labour')}
                className={`px-2 py-0.5 rounded font-bold transition cursor-pointer ${
                  unitClickMode === 'labour'
                    ? 'bg-amber-500 text-slate-950 shadow-xs'
                    : 'text-amber-800 hover:bg-amber-50'
                }`}
                title="Clicking a unit cell opens Labour Name assignment"
              >
                Assign Labour
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Selected Tower Visual Progress Bar (Unit-Based Completion) */}
      <div className="px-4 py-3 bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white border-b border-slate-700">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
          <div className="flex items-center space-x-2">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-xs font-black uppercase tracking-wider text-slate-100">
              {header.towerNo || 'Tower'} &bull; Unit Work Completion Progress
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-extrabold border border-emerald-500/30">
              {unitProgressStats.percent}% Units Completed
            </span>
          </div>

          <div className="flex items-center flex-wrap gap-x-3 gap-y-1 text-[11px] text-slate-300 font-bold">
            <span className="flex items-center space-x-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
              <span>Paid/Done: <strong className="text-white">{unitProgressStats.completedUnits}</strong>/{unitProgressStats.totalUnits} Units</span>
            </span>
            {unitProgressStats.pendingUnits > 0 && (
              <span className="flex items-center space-x-1 text-amber-300">
                <span className="w-2 h-2 rounded-full bg-amber-400 inline-block" />
                <span>Pending: <strong className="text-white">{unitProgressStats.pendingUnits}</strong></span>
              </span>
            )}
            <span className="hidden md:inline text-slate-400">
              ({unitProgressStats.fullyCompletedFloors} of {unitProgressStats.totalFloors} Floors 100% Done)
            </span>
          </div>
        </div>

        {/* Visual Multi-Segment Progress Track */}
        <div className="w-full bg-slate-700/60 rounded-full h-2.5 overflow-hidden flex shadow-inner">
          <div
            className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full transition-all duration-500 rounded-l-full"
            style={{ width: `${unitProgressStats.percent}%` }}
            title={`Completed & Paid Units: ${unitProgressStats.completedUnits} (${unitProgressStats.percent}%)`}
          />
          <div
            className="bg-amber-400 h-full transition-all duration-500"
            style={{ width: `${unitProgressStats.pendingPercent}%` }}
            title={`Pending Units: ${unitProgressStats.pendingUnits} (${unitProgressStats.pendingPercent}%)`}
          />
        </div>
      </div>

      {/* Status Color Legend */}
      <div className="border-b border-slate-200 bg-slate-50/40">
        <div className="flex items-center justify-between px-4 py-2 bg-slate-100/50">
          <button
            type="button"
            onClick={() => setIsLegendOpen(!isLegendOpen)}
            className="flex items-center space-x-1.5 text-xs font-black text-slate-700 hover:text-slate-900 transition focus:outline-hidden"
          >
            <Info className="w-3.5 h-3.5 text-sky-600" />
            <span>Show Status & Billing Color Code Legend</span>
            <span className="text-[10px] text-slate-500 font-normal ml-1">
              ({isLegendOpen ? 'click to collapse' : 'click to expand'})
            </span>
          </button>
          <button
            type="button"
            onClick={() => setIsLegendOpen(!isLegendOpen)}
            className="text-slate-400 hover:text-slate-600 transition"
          >
            <ChevronDown className={`w-4 h-4 transform transition-transform duration-200 ${isLegendOpen ? 'rotate-180' : ''}`} />
          </button>
        </div>

        {isLegendOpen && (
          <div className="p-4 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs border-t border-slate-200 bg-white">
            {/* Column 1: Floor Work Progress */}
            <div className="space-y-2">
              <h4 className="font-extrabold text-slate-950 uppercase tracking-wider text-[10px] border-b border-slate-200 pb-1">
                Floor Work Progress
              </h4>
              <div className="space-y-1.5">
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 ring-2 ring-emerald-200" />
                  <span className="font-semibold text-slate-800">Done</span>
                  <span className="text-slate-500 text-[10px]">&mdash; Ready for billing (all flats completed)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-amber-500 ring-2 ring-amber-200" />
                  <span className="font-semibold text-slate-800">In Progress</span>
                  <span className="text-slate-500 text-[10px]">&mdash; Underway (some flats completed)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-3 h-3 rounded-full bg-slate-400 ring-2 ring-slate-200" />
                  <span className="font-semibold text-slate-800">Pending</span>
                  <span className="text-slate-500 text-[10px]">&mdash; Not Started (no completed units)</span>
                </div>
              </div>
            </div>

            {/* Column 2: Individual Unit Status */}
            <div className="space-y-2">
              <h4 className="font-extrabold text-slate-950 uppercase tracking-wider text-[10px] border-b border-slate-200 pb-1">
                Individual Unit Status
              </h4>
              <div className="space-y-1.5">
                <div className="flex items-center space-x-2">
                  <div className="px-1.5 py-0.5 bg-emerald-700 text-white font-bold rounded text-[9px] min-w-[50px] text-center">Pid Bill</div>
                  <span className="text-slate-700 font-medium">Paid</span>
                  <span className="text-slate-500 text-[10px]">&mdash; Gypsum completed & verified</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="px-1.5 py-0.5 bg-yellow-200 text-slate-900 font-bold rounded text-[9px] min-w-[50px] text-center">Pending</div>
                  <span className="text-slate-700 font-medium">Pending</span>
                  <span className="text-slate-500 text-[10px]">&mdash; Work started/not certified</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="px-1.5 py-0.5 bg-white text-slate-400 border border-slate-200 rounded text-[9px] min-w-[50px] text-center">&mdash;</div>
                  <span className="text-slate-700 font-medium">Empty</span>
                  <span className="text-slate-500 text-[10px]">&mdash; No work recorded yet</span>
                </div>
              </div>
            </div>

            {/* Column 3: Billing & PDF Status */}
            <div className="space-y-2">
              <h4 className="font-extrabold text-slate-950 uppercase tracking-wider text-[10px] border-b border-slate-200 pb-1">
                Bill Export & Print Status
              </h4>
              <div className="space-y-1.5">
                <div className="flex items-center space-x-2">
                  <div className="px-2 py-0.5 bg-emerald-100 text-emerald-950 border border-emerald-300 rounded-full text-[9px] font-bold">PDF & Printed</div>
                  <span className="text-slate-500 text-[10px]">&mdash; Both exported and printed</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="px-2 py-0.5 bg-sky-100 text-sky-950 border border-sky-300 rounded-full text-[9px] font-bold">PDF Exported</div>
                  <span className="text-slate-500 text-[10px]">&mdash; Saved as digital bill PDF</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="px-2 py-0.5 bg-indigo-100 text-indigo-950 border border-indigo-300 rounded-full text-[9px] font-bold">Printed</div>
                  <span className="text-slate-500 text-[10px]">&mdash; Marked physically printed</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="px-2 py-0.5 bg-slate-100 text-slate-500 border border-slate-200 rounded-full text-[9px] font-bold">Pending Bill</div>
                  <span className="text-slate-500 text-[10px]">&mdash; Not exported/printed yet</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Primary Summary Bill Table */}
      <div className="overflow-x-auto print:overflow-visible">
        <table id="summary-bill-record-table" className="w-full text-left border-collapse text-[11px] leading-tight">
          {/* Main Table Head */}
          <thead>
            {/* Header Row 1 */}
            <tr className="bg-slate-900 text-white text-center font-bold uppercase tracking-wider">
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[70px]">S/C Name</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[65px]">Tower</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[70px]">Floor</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[90px]">Flats No</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[110px]">Labour / Mistri</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">UNIT No 1</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">UNIT No 2</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">UNIT No 3</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">UNIT No 4</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">UNIT No 5</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">UNIT No 6</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">UNIT No 7</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">UNIT No 8</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">Lobby</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">Starc 1</th>
              <th className="p-1.5 border-r border-slate-800 bg-slate-800/90">Starc 2</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 bg-sky-900/90 text-sky-200 min-w-[85px]">Release (100%)</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 bg-rose-950/90 text-rose-200 min-w-[75px]">Hold (20%)</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 bg-teal-900/90 text-teal-200 min-w-[80px]">Paid (80%)</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[60px]" title="Gypsum Running Flats">Run Flats</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[55px]" title="Gypsum Running Lobby">Run Lby</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[55px]" title="Starches 1 WC">Star 1</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[55px]" title="Starches 2 WC">Star 2</th>
              <th colSpan={4} className="p-1.5 border-r border-slate-800 bg-emerald-950/80 text-emerald-300">
                Site Verification
              </th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 min-w-[85px]">Status</th>
              <th rowSpan={2} className="p-2 border-r border-slate-800 bg-slate-800 text-sky-200 min-w-[115px]" title="Bill PDF Export & Print Status">
                Bill / PDF
              </th>
              {userAccess.canEdit && <th rowSpan={2} className="p-2 min-w-[85px]">Actions</th>}
            </tr>

            {/* Header Row 2: Sqft values */}
            <tr className="bg-slate-800 text-slate-300 text-[10px] text-center border-b border-slate-700 font-medium">
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.unit1 || 3700}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.unit2 || 1934}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.unit3 || 2334}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.unit4 || 2334}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.unit5 || 2465}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.unit6 || 2465}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.unit7 || 2465}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.unit8 || 1665}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.lobby || 1500}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.starc1 || 480}</th>
              <th className="p-1 border-r border-slate-700">Sqft {sqftConfig.starc2 || 480}</th>
              <th className="p-1 border-r border-slate-700 text-emerald-300">Flats</th>
              <th className="p-1 border-r border-slate-700 text-emerald-300">Lby</th>
              <th className="p-1 border-r border-slate-700 text-emerald-300">S1</th>
              <th className="p-1 border-r border-slate-700 text-emerald-300">S2</th>
            </tr>
          </thead>

          {/* Table Body */}
          <tbody className="divide-y divide-slate-200">
            {filteredFloors.length === 0 ? (
              <tr>
                <td colSpan={userAccess.canEdit ? 30 : 29} className="p-8 text-center text-slate-500 bg-slate-50">
                  No floor records match your search or filter criteria.
                </td>
              </tr>
            ) : (
              filteredFloors.map((floor) => {
                const statusInfo = getFloorProgressStatus(floor);
                const billingBadge = getFloorBillingBadgeInfo(floor);
                return (
                  <tr
                    key={floor.id}
                    className={`transition-colors duration-150 ${statusInfo.rowBgClass}`}
                  >
                    {/* S/C Name */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-slate-800">
                      {floor.scName || header.scName || 'SSR'}
                    </td>

                    {/* Tower */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-slate-700">
                      {floor.towerNo || header.towerNo || 'T2'}
                    </td>

                    {/* Floor No */}
                    <td className="p-2 border-r border-slate-200 text-center font-black text-slate-900 bg-slate-50/50">
                      <div className="flex items-center justify-center space-x-1">
                        <span>{floor.floorNo}</span>
                        {billingBadge.isBilled && (
                          <span
                            className={`w-1.5 h-1.5 rounded-full inline-block ${
                              billingBadge.isExported && billingBadge.isPrinted
                                ? 'bg-teal-500 ring-2 ring-teal-200'
                                : billingBadge.isExported
                                ? 'bg-sky-500 ring-2 ring-sky-200'
                                : 'bg-indigo-500 ring-2 ring-indigo-200'
                            }`}
                            title={billingBadge.tooltip}
                          />
                        )}
                      </div>
                    </td>

                    {/* Flats No */}
                    <td className="p-2 border-r border-slate-200 font-semibold text-slate-700">
                      {floor.flatsNo || '—'}
                    </td>

                    {/* Labour Name */}
                    <td className="p-2 border-r border-slate-200 font-bold text-amber-950 bg-amber-50/30">
                      <div className="flex items-center space-x-1">
                        <span className="truncate max-w-[100px]" title={floor.labourName}>
                          {floor.labourName || 'Adil Ahmad'}
                        </span>
                      </div>
                    </td>

                    {/* UNIT 1 - 8 & LOBBY & STARC 1 & STARC 2 */}
                    {UNIT_CONFIG_MAP.map(({ key, label }) => {
                      const unitKeyStr = String(key);
                      const unitStatus = (floor[key] as UnitStatus) || 'none';
                      const isPaid = unitStatus === 'paid';
                      const isPending = unitStatus === 'pending';
                      const assignedLabour = getUnitLabourName(floor, unitKeyStr);
                      const isLabourHighlighted =
                        labourFilter !== 'all' &&
                        assignedLabour.toLowerCase() === labourFilter.toLowerCase();

                      return (
                        <td
                          key={unitKeyStr}
                          onClick={() => {
                            if (!userAccess.canEdit) return;
                            if (unitClickMode === 'labour') {
                              setTargetFloorForUnitLabour(floor.id);
                              setTargetUnitForUnitLabour(unitKeyStr);
                              setIsUnitLabourModalOpen(true);
                            } else {
                              handleUnitClick(floor, key);
                            }
                          }}
                          title={`${label}: ${
                            isPaid ? 'Pid Bill' : isPending ? 'Pending' : 'Not Set'
                          }${assignedLabour ? ` (${assignedLabour})` : ''} - Click to ${
                            unitClickMode === 'labour' ? 'assign labour' : 'toggle status'
                          }`}
                          className={`p-1.5 border-r border-slate-200 text-center select-none transition ${
                            userAccess.canEdit ? 'cursor-pointer hover:opacity-85' : 'cursor-default'
                          } ${
                            isPaid
                              ? 'bg-emerald-700 text-white font-black'
                              : isPending
                              ? 'bg-yellow-200 text-slate-900 font-bold'
                              : 'bg-white text-slate-400'
                          } ${
                            isLabourHighlighted
                              ? 'ring-2 ring-amber-400 ring-inset shadow-xs'
                              : ''
                          }`}
                        >
                          <div className="flex flex-col items-center justify-center min-h-[30px] group/unit relative">
                            {isPaid ? (
                              <>
                                <span className="text-[10px] tracking-tight">Pid Bill</span>
                                {assignedLabour && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (!userAccess.canEdit) return;
                                      setTargetFloorForUnitLabour(floor.id);
                                      setTargetUnitForUnitLabour(unitKeyStr);
                                      setIsUnitLabourModalOpen(true);
                                    }}
                                    className="text-[8px] text-emerald-100 hover:text-white font-semibold underline underline-offset-1 truncate max-w-[55px] cursor-pointer"
                                    title={`Labour: ${assignedLabour} (Click to change)`}
                                  >
                                    {assignedLabour.split(' ')[0]}
                                  </button>
                                )}
                              </>
                            ) : isPending ? (
                              <>
                                <span className="text-[10px] tracking-tight text-amber-950">Pending</span>
                                {assignedLabour && (
                                  <button
                                    type="button"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      if (!userAccess.canEdit) return;
                                      setTargetFloorForUnitLabour(floor.id);
                                      setTargetUnitForUnitLabour(unitKeyStr);
                                      setIsUnitLabourModalOpen(true);
                                    }}
                                    className="text-[8px] text-amber-900 hover:text-amber-950 font-semibold underline underline-offset-1 truncate max-w-[55px] cursor-pointer"
                                    title={`Labour: ${assignedLabour} (Click to change)`}
                                  >
                                    {assignedLabour.split(' ')[0]}
                                  </button>
                                )}
                              </>
                            ) : (
                              <>
                                <span className="text-slate-300 text-xs">—</span>
                                {assignedLabour && (
                                  <span className="text-[7px] text-slate-400 truncate max-w-[50px]">
                                    {assignedLabour.split(' ')[0]}
                                  </span>
                                )}
                              </>
                            )}
                          </div>
                        </td>
                      );
                    })}

                    {/* Release Qty (100%) */}
                    <td className="p-2 border-r border-slate-200 text-right font-black text-sky-950 bg-sky-100/50">
                      {(floor.releaseQuantity || 0).toLocaleString('en-IN')}
                    </td>

                    {/* Hold Qty (20%) */}
                    <td className="p-2 border-r border-slate-200 text-right font-bold text-rose-900 bg-rose-100/50">
                      {(floor.holdQuantity || 0).toLocaleString('en-IN')}
                    </td>

                    {/* Paid Qty (80%) */}
                    <td className="p-2 border-r border-slate-200 text-right font-black text-teal-950 bg-teal-100/60">
                      {(floor.paidQuantity || 0).toLocaleString('en-IN')}
                    </td>

                    {/* Running Flats */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-slate-700">
                      {floor.gypsumRunningFlats || 0}
                    </td>

                    {/* Running Lobby */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-slate-700">
                      {floor.gypsumRunningLobby || 0}
                    </td>

                    {/* Starches 1 WC */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-slate-700">
                      {floor.starches1WC || 0}
                    </td>

                    {/* Starches 2 WC */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-slate-700">
                      {floor.starches2WC || 0}
                    </td>

                    {/* Verify Flats */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-emerald-900 bg-emerald-100/40">
                      {floor.verifyFlats || 0}
                    </td>

                    {/* Verify Lobby */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-emerald-900 bg-emerald-100/40">
                      {floor.verifyLobby || 0}
                    </td>

                    {/* Verify Star1 */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-emerald-900 bg-emerald-100/40">
                      {floor.verifyStar1 || 0}
                    </td>

                    {/* Verify Star2 */}
                    <td className="p-2 border-r border-slate-200 text-center font-bold text-emerald-900 bg-emerald-100/40">
                      {floor.verifyStar2 || 0}
                    </td>

                    {/* Status / Quick Toggle */}
                    <td className="p-2 border-r border-slate-200 text-center">
                      <button
                        type="button"
                        onClick={() => handleToggleFloorStatus(floor)}
                        disabled={!userAccess.canEdit}
                        title={statusInfo.isAllPaid ? 'Click to mark in-progress' : 'Click to mark all completed & billed'}
                        className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase transition ${
                          statusInfo.isAllPaid
                            ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-xs'
                            : statusInfo.paidFlatsCount > 0
                            ? 'bg-amber-500 text-white hover:bg-amber-600'
                            : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
                        }`}
                      >
                        {statusInfo.isAllPaid ? (
                          <>
                            <Check className="w-2.5 h-2.5" />
                            <span>Done</span>
                          </>
                        ) : (
                          <>
                            <Clock className="w-2.5 h-2.5" />
                            <span>{statusInfo.paidFlatsCount}/8</span>
                          </>
                        )}
                      </button>
                    </td>

                    {/* Bill / PDF Export & Print Visual Indicator Badge */}
                    <td className="p-2 border-r border-slate-200 text-center relative whitespace-nowrap">
                      <div className="flex items-center justify-center">
                        <button
                          type="button"
                          onClick={() => setOpenBillingMenuFloorId(openBillingMenuFloorId === floor.id ? null : floor.id)}
                          title={`${billingBadge.tooltip} — Click to update status or export floor PDF`}
                          className={`inline-flex items-center space-x-1.5 px-2.5 py-1 rounded-full text-[10px] tracking-tight transition-all duration-150 shadow-xs hover:shadow-md cursor-pointer ${billingBadge.badgeClass}`}
                        >
                          {billingBadge.badgeIconType === 'both' ? (
                            <>
                              <CheckCircle2 className="w-3 h-3 text-emerald-700 shrink-0" />
                              <span>PDF & Printed</span>
                            </>
                          ) : billingBadge.badgeIconType === 'pdf' ? (
                            <>
                              <FileDown className="w-3 h-3 text-sky-700 shrink-0" />
                              <span>PDF Exported</span>
                            </>
                          ) : billingBadge.badgeIconType === 'printed' ? (
                            <>
                              <Printer className="w-3 h-3 text-indigo-700 shrink-0" />
                              <span>Printed</span>
                            </>
                          ) : (
                            <>
                              <Clock className="w-2.5 h-2.5 text-slate-400 shrink-0" />
                              <span>Pending Bill</span>
                            </>
                          )}
                          <ChevronDown className="w-2.5 h-2.5 opacity-60 hover:opacity-100 shrink-0" />
                        </button>
                      </div>

                      {/* Dropdown Menu for fast tracking */}
                      {openBillingMenuFloorId === floor.id && (
                        <div
                          className="absolute right-0 top-full mt-1 w-56 bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 p-2 z-50 text-left text-xs font-sans"
                          onMouseLeave={() => setOpenBillingMenuFloorId(null)}
                        >
                          <div className="px-2 py-1 text-[10px] font-bold text-slate-400 border-b border-slate-800 uppercase tracking-wider mb-1.5 flex justify-between items-center">
                            <span>Floor {floor.floorNo} Billing Status</span>
                            <button
                              type="button"
                              onClick={() => setOpenBillingMenuFloorId(null)}
                              className="text-slate-400 hover:text-white"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>

                          <div className="space-y-1">
                            <button
                              type="button"
                              onClick={() => {
                                handleSetBillingStatus(floor, 'exported');
                                setOpenBillingMenuFloorId(null);
                              }}
                              className={`w-full px-2.5 py-1.5 rounded-lg text-left flex items-center space-x-2 text-[11px] transition ${
                                billingBadge.status === 'exported'
                                  ? 'bg-sky-950 text-sky-300 font-bold border border-sky-800'
                                  : 'hover:bg-slate-800 text-slate-200'
                              }`}
                            >
                              <FileDown className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                              <span>Mark as PDF Exported</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                handleSetBillingStatus(floor, 'printed');
                                setOpenBillingMenuFloorId(null);
                              }}
                              className={`w-full px-2.5 py-1.5 rounded-lg text-left flex items-center space-x-2 text-[11px] transition ${
                                billingBadge.status === 'printed'
                                  ? 'bg-indigo-950 text-indigo-300 font-bold border border-indigo-800'
                                  : 'hover:bg-slate-800 text-slate-200'
                              }`}
                            >
                              <Printer className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                              <span>Mark as Printed</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                handleSetBillingStatus(floor, 'both');
                                setOpenBillingMenuFloorId(null);
                              }}
                              className={`w-full px-2.5 py-1.5 rounded-lg text-left flex items-center space-x-2 text-[11px] transition ${
                                billingBadge.status === 'both'
                                  ? 'bg-emerald-950 text-emerald-300 font-bold border border-emerald-800'
                                  : 'hover:bg-slate-800 text-slate-200'
                              }`}
                            >
                              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              <span>Mark as Both (PDF + Printed)</span>
                            </button>

                            <div className="border-t border-slate-800 my-1 pt-1" />

                            <button
                              type="button"
                              onClick={() => {
                                handleDownloadSingleFloorPDF(floor);
                                setOpenBillingMenuFloorId(null);
                              }}
                              className="w-full px-2.5 py-1.5 rounded-lg hover:bg-emerald-900/60 text-emerald-300 flex items-center space-x-2 text-[11px] font-bold transition border border-emerald-800/40"
                            >
                              <FileDown className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              <span>Download Floor PDF Bill</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                handleSetBillingStatus(floor, 'pending');
                                setOpenBillingMenuFloorId(null);
                              }}
                              className="w-full px-2.5 py-1.5 rounded-lg hover:bg-rose-950/40 text-slate-400 hover:text-rose-300 flex items-center space-x-2 text-[11px] transition"
                            >
                              <X className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                              <span>Reset to Pending / Unbilled</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </td>

                    {/* Actions */}
                    {userAccess.canEdit && (
                      <td className="p-2 text-center whitespace-nowrap">
                        <div className="flex items-center justify-center space-x-1">
                          <button
                            type="button"
                            onClick={() => handleDownloadSingleFloorPDF(floor)}
                            className="p-1 text-slate-600 hover:text-emerald-600 hover:bg-emerald-50 rounded transition"
                            title="Export Single Floor PDF Bill"
                          >
                            <FileDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onEditFloorClick(floor)}
                            className="p-1 text-slate-600 hover:text-sky-600 hover:bg-sky-50 rounded transition"
                            title="Edit floor details"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          {userAccess.canManageSites && (
                            <button
                              type="button"
                              onClick={() => setFloorToDelete(floor)}
                              className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded transition"
                              title="Delete floor"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })
            )}
          </tbody>

          {/* Table Footer / Totals Row */}
          <tfoot>
            <tr className="bg-slate-900 text-white font-black text-center text-[11px] border-t-2 border-slate-700">
              <td colSpan={5} className="p-2.5 text-right uppercase tracking-wider text-slate-300 border-r border-slate-800">
                TOTAL ({filteredFloors.length} Floors)
              </td>
              <td colSpan={11} className="p-2.5 border-r border-slate-800 bg-slate-800/80 text-emerald-400 font-bold">
                Summary Measured Units
              </td>
              <td className="p-2.5 border-r border-slate-800 text-right bg-sky-950 text-sky-200">
                {totals.rel.toLocaleString('en-IN')}
              </td>
              <td className="p-2.5 border-r border-slate-800 text-right bg-rose-950 text-rose-200">
                {totals.hld.toLocaleString('en-IN')}
              </td>
              <td className="p-2.5 border-r border-slate-800 text-right bg-teal-950 text-teal-200">
                {totals.pd.toLocaleString('en-IN')}
              </td>
              <td className="p-2.5 border-r border-slate-800">{totals.rFlats}</td>
              <td className="p-2.5 border-r border-slate-800">{totals.rLobby}</td>
              <td className="p-2.5 border-r border-slate-800">{totals.rS1}</td>
              <td className="p-2.5 border-r border-slate-800">{totals.rS2}</td>
              <td className="p-2.5 border-r border-slate-800 bg-emerald-950 text-emerald-300">{totals.vFlats}</td>
              <td className="p-2.5 border-r border-slate-800 bg-emerald-950 text-emerald-300">{totals.vLobby}</td>
              <td className="p-2.5 border-r border-slate-800 bg-emerald-950 text-emerald-300">{totals.vS1}</td>
              <td className="p-2.5 border-r border-slate-800 bg-emerald-950 text-emerald-300">{totals.vS2}</td>
              <td className="p-2.5 border-r border-slate-800 text-slate-400 text-center">
                —
              </td>
              <td className="p-2.5 border-r border-slate-800 text-center font-bold bg-slate-800 text-sky-300 whitespace-nowrap">
                {billingStats.totalBilled}/{filteredFloors.length} Billed
              </td>
              {userAccess.canEdit && (
                <td className="p-2.5 text-slate-400 text-center">
                  —
                </td>
              )}
            </tr>
          </tfoot>
        </table>
      </div>

      {/* Table Legend & Instructions */}
      <div className="p-3 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-600">
        <div className="flex flex-wrap items-center gap-4">
          {/* Unit Plastering Status Legend */}
          <div className="flex items-center space-x-3">
            <span className="font-bold text-slate-700">Units:</span>
            <div className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-emerald-700 inline-block"></span>
              <span className="font-medium text-slate-800">Pid Bill</span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded-sm bg-yellow-300 border border-yellow-400 inline-block"></span>
              <span className="font-medium text-slate-800">Pending</span>
            </div>
          </div>

          {/* Billing Progress Indicator Legend */}
          <div className="flex items-center space-x-2 border-l border-slate-300 pl-3">
            <span className="font-bold text-slate-700">Bill Badges:</span>
            <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-sky-100 text-sky-950 border border-sky-300">
              PDF Exported
            </span>
            <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-indigo-100 text-indigo-950 border border-indigo-300">
              Printed
            </span>
            <span className="px-2 py-0.5 rounded-full text-[9px] font-black bg-emerald-100 text-emerald-950 border border-emerald-300">
              PDF &amp; Printed
            </span>
            <span className="px-2 py-0.5 rounded-full text-[9px] font-semibold bg-slate-100 text-slate-500 border border-slate-200">
              Pending
            </span>
          </div>
        </div>

        <div className="text-slate-500 text-[10px] italic">
          Click any bill badge to change status or download that floor&apos;s PDF bill instantly.
        </div>
      </div>

      {/* Floor Deletion Confirmation Dialog */}
      <ConfirmationDialog
        isOpen={Boolean(floorToDelete)}
        title={`Delete Floor ${floorToDelete?.floorNo || ''} Record?`}
        message="Are you sure you want to delete this floor record? All associated plastering quantities, verification units, and billing records for this floor will be permanently removed."
        confirmText="Delete Floor Permanently"
        itemDetails={
          floorToDelete
            ? [
                { label: 'Floor No', value: floorToDelete.floorNo },
                { label: 'Tower', value: floorToDelete.towerNo || header.towerNo || 'T2' },
                { label: 'Release Qty', value: `${(floorToDelete.releaseQuantity || 0).toLocaleString('en-IN')} sqft` },
                { label: 'Labour Name', value: floorToDelete.labourName || 'Adil Ahmad' },
              ]
            : []
        }
        onConfirm={() => {
          if (floorToDelete) {
            const floorNo = floorToDelete.floorNo;
            onDeleteFloor(floorToDelete.id);
            setActionFeedback(`Floor ${floorNo} was deleted successfully.`);
            setTimeout(() => setActionFeedback(null), 3500);
            setFloorToDelete(null);
          }
        }}
        onCancel={() => setFloorToDelete(null)}
      />

      {/* Labour-Wise Unit Entry Modal */}
      <UnitLabourEntryModal
        isOpen={isUnitLabourModalOpen}
        onClose={() => {
          setIsUnitLabourModalOpen(false);
          setTargetFloorForUnitLabour(undefined);
          setTargetUnitForUnitLabour(undefined);
        }}
        floors={floors}
        activeTower={header.towerNo || 'Tower 2'}
        sqftConfig={sqftConfig}
        accounts={accounts}
        initialFloorId={targetFloorForUnitLabour}
        initialUnitKey={targetUnitForUnitLabour}
        onSaveFloor={(updated) => {
          onUpdateFloor(updated);
          setActionFeedback(`Updated Floor ${updated.floorNo} unit labour assignments!`);
          setTimeout(() => setActionFeedback(null), 3500);
        }}
        onSaveAllFloors={onSaveAllFloors}
      />
    </div>
  );
};
