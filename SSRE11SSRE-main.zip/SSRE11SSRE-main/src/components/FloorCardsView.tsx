import React, { useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Edit2,
  User,
  Layers,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { FloorEntry, UnitSqftConfig, BillHeader, UserAccessInfo, UnitStatus } from '../types';
import { UNIT_CONFIG_MAP, getFloorProgressStatus, toggleSingleUnitStatus, toggleFloorCompletedStatus } from '../utils/floorCalculationHelper';
import { getUnitLabourName } from '../utils/labourBillHelper';

interface FloorCardsViewProps {
  floors: FloorEntry[];
  header: BillHeader;
  sqftConfig: UnitSqftConfig;
  userAccess: UserAccessInfo;
  onUpdateFloor: (updated: FloorEntry) => void;
  onEditFloorClick: (floor: FloorEntry) => void;
}

export const FloorCardsView: React.FC<FloorCardsViewProps> = ({
  floors,
  header,
  sqftConfig,
  userAccess,
  onUpdateFloor,
  onEditFloorClick,
}) => {
  const [expandedFloors, setExpandedFloors] = useState<Record<string, boolean>>({});

  const toggleExpand = (floorId: string) => {
    setExpandedFloors((prev) => ({ ...prev, [floorId]: !prev[floorId] }));
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
      {floors.map((floor) => {
        const statusInfo = getFloorProgressStatus(floor);
        const isExpanded = Boolean(expandedFloors[floor.id]);

        return (
          <div
            key={floor.id}
            className={`rounded-xl border transition-all duration-200 overflow-hidden shadow-xs ${statusInfo.cardBgClass} ${statusInfo.cardBorderClass}`}
          >
            {/* Top Indicator Line */}
            <div className={`h-1.5 w-full ${statusInfo.cardIndicatorBarClass}`} />

            <div className="p-4">
              {/* Card Header */}
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center space-x-2">
                    <span className="text-xl font-black text-slate-900">
                      Floor {floor.floorNo}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${statusInfo.badgeClass}`}>
                      {statusInfo.label}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 font-medium mt-0.5">
                    Flats: {floor.flatsNo || '—'} &bull; {floor.towerNo || header.towerNo || 'Tower 2'}
                  </p>
                </div>

                {userAccess.canEdit && (
                  <button
                    type="button"
                    onClick={() => onEditFloorClick(floor)}
                    className="p-1.5 text-slate-500 hover:text-sky-600 hover:bg-white rounded-lg transition border border-transparent hover:border-slate-200"
                    title="Edit floor"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Mistri / Labour */}
              <div className="mt-3 flex items-center justify-between bg-white/70 p-2 rounded-lg border border-slate-200/60 text-xs">
                <div className="flex items-center space-x-1.5 text-slate-700">
                  <User className="w-3.5 h-3.5 text-amber-600" />
                  <span className="font-semibold text-slate-800">
                    {floor.labourName || 'Adil Ahmad'}
                  </span>
                </div>
                <span className="text-[11px] text-slate-500 font-medium">
                  {statusInfo.paidFlatsCount}/8 Flats Completed
                </span>
              </div>

              {/* Units Grid */}
              <div className="mt-3">
                <div className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex justify-between">
                  <span>Unit Completion Grid</span>
                  <span className="text-slate-400 font-normal">Tap to toggle</span>
                </div>

                <div className="grid grid-cols-4 gap-1.5">
                  {UNIT_CONFIG_MAP.map(({ key, label }) => {
                    const unitStatus = (floor[key] as UnitStatus) || 'none';
                    const isPaid = unitStatus === 'paid';
                    const isPending = unitStatus === 'pending';
                    const assignedLabour = getUnitLabourName(floor, String(key));

                    return (
                      <button
                        key={String(key)}
                        type="button"
                        disabled={!userAccess.canEdit}
                        onClick={() => {
                          const updated = toggleSingleUnitStatus(floor, key, sqftConfig);
                          onUpdateFloor(updated);
                        }}
                        title={`${label}: ${isPaid ? 'Paid Bill' : isPending ? 'Pending' : 'None'}${assignedLabour ? ` (${assignedLabour})` : ''}`}
                        className={`py-1.5 px-1 rounded text-center transition font-bold text-[10px] truncate ${
                          isPaid
                            ? 'bg-emerald-700 text-white shadow-xs'
                            : isPending
                            ? 'bg-amber-300 text-slate-900 border border-amber-400'
                            : 'bg-white text-slate-400 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <div className="truncate">{label}</div>
                        <div className="text-[8px] font-medium opacity-90">
                          {isPaid ? 'Paid' : isPending ? 'Pending' : '—'}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Quantities Overview */}
              <div className="mt-3 pt-3 border-t border-slate-200/80 grid grid-cols-3 gap-2 text-center text-xs">
                <div className="bg-sky-50/80 p-1.5 rounded-lg border border-sky-200/60">
                  <div className="text-[10px] text-sky-800 font-semibold">Release</div>
                  <div className="font-black text-sky-950">
                    {(floor.releaseQuantity || 0).toLocaleString('en-IN')}
                  </div>
                </div>
                <div className="bg-teal-50/80 p-1.5 rounded-lg border border-teal-200/60">
                  <div className="text-[10px] text-teal-800 font-semibold">Paid (80%)</div>
                  <div className="font-black text-teal-950">
                    {(floor.paidQuantity || 0).toLocaleString('en-IN')}
                  </div>
                </div>
                <div className="bg-rose-50/80 p-1.5 rounded-lg border border-rose-200/60">
                  <div className="text-[10px] text-rose-800 font-semibold">Hold (20%)</div>
                  <div className="font-black text-rose-950">
                    {(floor.holdQuantity || 0).toLocaleString('en-IN')}
                  </div>
                </div>
              </div>

              {/* Expandable Details Section */}
              {isExpanded && (
                <div className="mt-3 pt-2 border-t border-slate-200/80 text-[11px] text-slate-600 space-y-1.5">
                  <div className="flex justify-between py-0.5">
                    <span>Gypsum Running Flats:</span>
                    <span className="font-bold text-slate-800">{floor.gypsumRunningFlats || 0}</span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span>Gypsum Running Lobby:</span>
                    <span className="font-bold text-slate-800">{floor.gypsumRunningLobby || 0}</span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span>Starches 1 &amp; 2 WC:</span>
                    <span className="font-bold text-slate-800">
                      {floor.starches1WC || 0} &bull; {floor.starches2WC || 0}
                    </span>
                  </div>
                  <div className="flex justify-between py-0.5">
                    <span>Site Verified Flats:</span>
                    <span className="font-bold text-emerald-700">{floor.verifyFlats || 0}/8</span>
                  </div>
                  {floor.remarks && (
                    <div className="p-1.5 bg-slate-100 rounded text-slate-700 italic">
                      Remarks: {floor.remarks}
                    </div>
                  )}
                </div>
              )}

              {/* Bottom Actions Row */}
              <div className="mt-3 pt-2 flex items-center justify-between text-xs">
                <button
                  type="button"
                  onClick={() => toggleExpand(floor.id)}
                  className="flex items-center space-x-1 text-slate-500 hover:text-slate-800 font-medium"
                >
                  <span>{isExpanded ? 'Less info' : 'More info'}</span>
                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>

                {userAccess.canEdit && (
                  <button
                    type="button"
                    onClick={() => {
                      const markDone = statusInfo.status !== 'done';
                      const updated = toggleFloorCompletedStatus(floor, sqftConfig, markDone);
                      onUpdateFloor(updated);
                    }}
                    className={`px-2.5 py-1 rounded-lg font-bold text-xs shadow-xs transition flex items-center space-x-1 ${
                      statusInfo.isAllPaid
                        ? 'bg-amber-600 hover:bg-amber-700 text-white'
                        : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                    }`}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{statusInfo.isAllPaid ? 'Set In-Progress' : 'Mark Done'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
