import React, { useMemo, useState } from 'react';
import {
  TrendingUp,
  Building,
  Users,
  CheckCircle2,
  Clock,
  Briefcase,
  Layers,
  ChevronRight,
  ShieldCheck,
  Search,
} from 'lucide-react';
import { FloorEntry, UnitSqftConfig, BillHeader, UserAccount } from '../types';
import { getActiveUnits } from '../utils/floorCalculationHelper';

interface AnalyticsDashboardViewProps {
  floors: FloorEntry[];
  sqftConfig: UnitSqftConfig;
  header: BillHeader;
  accounts: UserAccount[];
  onSelectTower: (tower: string) => void;
  onChangeView: (view: 'table' | 'cards' | 'labour' | 'monthly' | 'analytics' | 'supervisor') => void;
}

export const AnalyticsDashboardView: React.FC<AnalyticsDashboardViewProps> = ({
  floors,
  sqftConfig,
  header,
  accounts,
  onSelectTower,
  onChangeView,
}) => {
  const [selectedDashboardTower, setSelectedDashboardTower] = useState<string>('__ALL__');
  const [labourSearchQuery, setLabourSearchQuery] = useState<string>('');

  // 1. Get list of unique towers
  const uniqueTowers = useMemo(() => {
    const set = new Set<string>();
    floors.forEach((f) => {
      if (f.towerNo) set.add(f.towerNo);
    });
    // Add default if empty
    if (set.size === 0) set.add('Tower 2');
    return Array.from(set).sort();
  }, [floors]);

  // 2. Filter floors based on selected tower in dashboard filter
  const filteredFloors = useMemo(() => {
    if (selectedDashboardTower === '__ALL__') return floors;
    return floors.filter((f) => f.towerNo === selectedDashboardTower);
  }, [floors, selectedDashboardTower]);

  // 3. Compute High-Level Metrics
  const metrics = useMemo(() => {
    const activeUnitsList = getActiveUnits(sqftConfig);
    let totalFloorsCount = filteredFloors.length;
    let totalCertifiedSqft = 0;
    let totalPendingSqft = 0;
    let totalNotStartedSqft = 0;

    let totalCompletedUnitsCount = 0;
    let totalPendingUnitsCount = 0;
    let totalNotStartedUnitsCount = 0;

    filteredFloors.forEach((floor) => {
      activeUnitsList.forEach(({ key, configKey }) => {
        const status = floor[key] || 'none';
        const uSqft = typeof sqftConfig[configKey] === 'number' ? (sqftConfig[configKey] as number) : 0;

        if (status === 'paid') {
          totalCertifiedSqft += uSqft;
          totalCompletedUnitsCount++;
        } else if (status === 'pending') {
          totalPendingSqft += uSqft;
          totalPendingUnitsCount++;
        } else {
          totalNotStartedSqft += uSqft;
          totalNotStartedUnitsCount++;
        }
      });
    });

    const totalPossibleUnits = totalFloorsCount * activeUnitsList.length;
    const progressPercent = totalPossibleUnits > 0 
      ? Math.round((totalCompletedUnitsCount / totalPossibleUnits) * 100) 
      : 0;

    // Billing count
    let totalBilledFloors = 0;
    let totalUnbilledFloors = 0;
    filteredFloors.forEach((f) => {
      const isBilled = Boolean(f.isBillPrinted || f.isBillExported || f.billExportStatus === 'exported' || f.billExportStatus === 'both');
      if (isBilled) totalBilledFloors++;
      else totalUnbilledFloors++;
    });

    return {
      totalFloorsCount,
      totalCertifiedSqft,
      totalPendingSqft,
      totalNotStartedSqft,
      progressPercent,
      totalCompletedUnitsCount,
      totalPendingUnitsCount,
      totalNotStartedUnitsCount,
      totalBilledFloors,
      totalUnbilledFloors,
    };
  }, [filteredFloors, sqftConfig]);

  // 4. Compute Tower breakdown progress
  const towerBreakdowns = useMemo(() => {
    const activeUnitsList = getActiveUnits(sqftConfig);
    return uniqueTowers.map((tower) => {
      const towerFloors = floors.filter((f) => f.towerNo === tower);
      let totalTowerSqft = 0;
      let completedUnits = 0;
      let pendingUnits = 0;
      let totalUnits = towerFloors.length * activeUnitsList.length;

      towerFloors.forEach((floor) => {
        activeUnitsList.forEach(({ key, configKey }) => {
          const status = floor[key] || 'none';
          const uSqft = typeof sqftConfig[configKey] === 'number' ? (sqftConfig[configKey] as number) : 0;
          if (status === 'paid') {
            totalTowerSqft += uSqft;
            completedUnits++;
          } else if (status === 'pending') {
            pendingUnits++;
          }
        });
      });

      const percent = totalUnits > 0 ? Math.round((completedUnits / totalUnits) * 100) : 0;
      
      // Count active distinct labour names in this tower
      const distinctLabours = new Set<string>();
      towerFloors.forEach((f) => {
        if (f.labourName) distinctLabours.add(f.labourName.trim());
      });

      return {
        towerName: tower,
        floorsCount: towerFloors.length,
        completedSqft: totalTowerSqft,
        percent,
        labourCount: distinctLabours.size,
      };
    });
  }, [floors, uniqueTowers, sqftConfig]);

  // 5. Unit-wise plastering work leaderboard
  const unitStats = useMemo(() => {
    const activeUnitsList = getActiveUnits(sqftConfig);
    return activeUnitsList.map(({ key, label, configKey }) => {
      let paidCount = 0;
      let pendingCount = 0;
      let noneCount = 0;
      const uSqft = typeof sqftConfig[configKey] === 'number' ? (sqftConfig[configKey] as number) : 0;

      filteredFloors.forEach((floor) => {
        const st = floor[key] || 'none';
        if (st === 'paid') paidCount++;
        else if (st === 'pending') pendingCount++;
        else noneCount++;
      });

      const total = filteredFloors.length;
      const progressPercent = total > 0 ? Math.round((paidCount / total) * 100) : 0;

      return {
        key,
        label,
        sqft: uSqft,
        paidCount,
        pendingCount,
        noneCount,
        progressPercent,
      };
    }).sort((a, b) => b.progressPercent - a.progressPercent);
  }, [filteredFloors, sqftConfig]);

  // 6. Labour-wise cumulative performance & estimated payout balance
  const labourLeaderboard = useMemo(() => {
    const activeUnitsList = getActiveUnits(sqftConfig);
    const map = new Map<string, { 
      name: string; 
      floorsCount: number; 
      completedSqft: number; 
      pendingSqft: number; 
      floorsList: Set<string>;
    }>();

    filteredFloors.forEach((floor) => {
      // Find out if the floor is mapped to multiple labours or just one
      const floorLabour = (floor.labourName || '').trim();
      if (!floorLabour) return;

      activeUnitsList.forEach(({ key, configKey }) => {
        const st = floor[key] || 'none';
        const uSqft = typeof sqftConfig[configKey] === 'number' ? (sqftConfig[configKey] as number) : 0;

        if (!map.has(floorLabour)) {
          map.set(floorLabour, {
            name: floorLabour,
            floorsCount: 0,
            completedSqft: 0,
            pendingSqft: 0,
            floorsList: new Set<string>(),
          });
        }

        const data = map.get(floorLabour)!;
        data.floorsList.add(floor.floorNo);
        if (st === 'paid') {
          data.completedSqft += uSqft;
        } else if (st === 'pending') {
          data.pendingSqft += uSqft;
        }
      });
    });

    // Populate registration rates
    return Array.from(map.values()).map((item) => {
      const dbUser = accounts.find(
        (acc) => acc.name.trim().toLowerCase() === item.name.toLowerCase() && acc.role === 'labour'
      );
      const rate = dbUser?.ratePerSqft || 12; // Default ₹12/sqft rate
      const registered = !!dbUser;
      
      const earned = item.completedSqft * rate;
      const pendingPayout = item.pendingSqft * rate;

      return {
        ...item,
        floorsCount: item.floorsList.size,
        rate,
        registered,
        earned,
        pendingPayout,
      };
    })
    .filter((item) => {
      if (!labourSearchQuery) return true;
      return item.name.toLowerCase().includes(labourSearchQuery.toLowerCase());
    })
    .sort((a, b) => b.completedSqft - a.completedSqft);
  }, [filteredFloors, sqftConfig, accounts, labourSearchQuery]);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Dashboard Top Row Controls */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-white p-4 rounded-xl border border-slate-200 shadow-xs">
        <div>
          <span className="text-[10px] uppercase font-black tracking-wider text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
            Analytics Command Center
          </span>
          <h2 className="text-xl font-black text-slate-900 mt-1">SSR Enterprises - Executive Dashboard</h2>
          <p className="text-xs text-slate-500 font-medium">{header.projectName || 'Prestige Lavender Field'} &bull; Real-time Construction Progress Overview</p>
        </div>

        {/* Filters */}
        <div className="flex items-center space-x-2 w-full sm:w-auto">
          <label className="text-xs font-bold text-slate-600 shrink-0">Filter Tower:</label>
          <select
            value={selectedDashboardTower}
            onChange={(e) => setSelectedDashboardTower(e.target.value)}
            className="w-full sm:w-auto bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 text-xs font-bold text-slate-800 focus:ring-emerald-500 focus:border-emerald-500"
          >
            <option value="__ALL__">All Towers Consolidated</option>
            {uniqueTowers.map((tower) => (
              <option key={tower} value={tower}>
                {tower}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Grid of Key Performance Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {/* KPI 1 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition">
          <div className="flex justify-between items-start">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            </div>
            <span className="text-[10px] text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded font-black">
              Approved
            </span>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-slate-950 block">
              ₹{(metrics.totalCertifiedSqft * 12).toLocaleString('en-IN')}
            </span>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide block mt-0.5">
              Certified Payout (Est)
            </span>
            <span className="text-[10px] text-slate-500 block mt-1">
              {metrics.totalCertifiedSqft.toLocaleString('en-IN')} Sqft completed
            </span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition">
          <div className="flex justify-between items-start">
            <div className="w-8 h-8 rounded-lg bg-amber-100 flex items-center justify-center">
              <Clock className="w-4 h-4 text-amber-600" />
            </div>
            <span className="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded font-black">
              In Review
            </span>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-slate-950 block">
              ₹{(metrics.totalPendingSqft * 12).toLocaleString('en-IN')}
            </span>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide block mt-0.5">
              Pending Owner Approval
            </span>
            <span className="text-[10px] text-slate-500 block mt-1">
              {metrics.totalPendingSqft.toLocaleString('en-IN')} Sqft awaits signoff
            </span>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition">
          <div className="flex justify-between items-start">
            <div className="w-8 h-8 rounded-lg bg-sky-100 flex items-center justify-center">
              <Layers className="w-4 h-4 text-sky-600" />
            </div>
            <span className="text-[10px] text-sky-700 bg-sky-50 px-1.5 py-0.5 rounded font-black">
              Overall Job
            </span>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-slate-950 block">
              {metrics.progressPercent}%
            </span>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide block mt-0.5">
              Completed Units Rate
            </span>
            <span className="text-[10px] text-emerald-600 font-extrabold block mt-1">
              {metrics.totalCompletedUnitsCount} units certified &bull; {metrics.totalPendingUnitsCount} pending
            </span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition">
          <div className="flex justify-between items-start">
            <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center">
              <Building className="w-4 h-4 text-indigo-600" />
            </div>
            <span className="text-[10px] text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded font-black">
              Unbilled
            </span>
          </div>
          <div className="mt-3">
            <span className="text-xl font-black text-slate-950 block">
              {metrics.totalUnbilledFloors} Floors
            </span>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wide block mt-0.5">
              Pending Bill PDF / Print
            </span>
            <span className="text-[10px] text-indigo-600 font-bold block mt-1">
              {metrics.totalBilledFloors} floors exported &amp; locked
            </span>
          </div>
        </div>
      </div>

      {/* Tower Progress Interactive Row */}
      <div className="space-y-3">
        <div className="flex justify-between items-center">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider">
            Tower Progress Map (Click card to open in Summary Sheet)
          </h3>
          <span className="text-xs text-slate-400 font-medium">Auto-calculated from live floor records</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {towerBreakdowns.map((t) => (
            <div
              key={t.towerName}
              onClick={() => {
                onSelectTower(t.towerName);
                onChangeView('table');
              }}
              className="bg-white border border-slate-200 hover:border-emerald-500 rounded-xl p-4 shadow-xs hover:shadow-md cursor-pointer transition relative overflow-hidden group"
            >
              {/* Top Accent Strip */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 to-teal-600"></div>

              <div className="flex justify-between items-start mb-2">
                <div>
                  <h4 className="font-extrabold text-slate-900 text-sm group-hover:text-emerald-700 transition">
                    {t.towerName}
                  </h4>
                  <span className="text-[10px] font-bold text-slate-400 block">
                    {t.floorsCount} Floors Logged
                  </span>
                </div>
                <span className="text-lg font-black text-emerald-600">{t.percent}%</span>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden mb-3">
                <div
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${t.percent}%` }}
                ></div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1.5 border-t border-slate-100">
                <span className="flex items-center space-x-1">
                  <TrendingUp className="w-3 h-3 text-emerald-500" />
                  <span className="font-bold">{t.completedSqft.toLocaleString('en-IN')} Sqft</span>
                </span>
                <span className="flex items-center space-x-1 font-bold">
                  <Users className="w-3 h-3 text-sky-500" />
                  <span>{t.labourCount} Labours</span>
                </span>
              </div>

              <div className="mt-2 text-right opacity-0 group-hover:opacity-100 transition duration-200">
                <span className="text-[9px] font-extrabold text-emerald-600 uppercase tracking-wider inline-flex items-center space-x-0.5">
                  <span>Open Sheet</span>
                  <ChevronRight className="w-3 h-3" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Two Column Layout: Plastering Units Status VS Labour Performance */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Side: Unit-wise Plastering Leaderboard */}
        <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-4 space-y-4 shadow-xs">
          <div className="border-b border-slate-100 pb-3 flex items-center justify-between">
            <div>
              <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                Plastering Unit Progress
              </h3>
              <p className="text-[11px] text-slate-400 font-medium">Success rate per Flat / Area</p>
            </div>
            <span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] font-black text-slate-600">
              {selectedDashboardTower === '__ALL__' ? 'All Towers' : selectedDashboardTower}
            </span>
          </div>

          <div className="space-y-3 max-h-[420px] overflow-y-auto pr-1">
            {unitStats.map((item) => (
              <div key={String(item.key)} className="space-y-1 group">
                <div className="flex justify-between items-center text-xs">
                  <div className="flex items-center space-x-1.5">
                    <span className="font-extrabold text-slate-800 group-hover:text-emerald-700 transition">
                      {item.label}
                    </span>
                    <span className="text-[10px] text-slate-400">({item.sqft} sqft)</span>
                  </div>
                  <div className="flex items-center space-x-2 font-bold">
                    <span className="text-slate-900">{item.paidCount} / {filteredFloors.length} Done</span>
                    <span className="text-emerald-600 font-extrabold">{item.progressPercent}%</span>
                  </div>
                </div>

                {/* Compound Segmented Bar */}
                <div className="w-full bg-slate-100 h-2.5 rounded-lg overflow-hidden flex">
                  {/* Paid portion */}
                  <div
                    title={`${item.paidCount} Paid`}
                    style={{ width: `${item.progressPercent}%` }}
                    className="bg-gradient-to-r from-emerald-500 to-emerald-600 h-full transition-all duration-300"
                  ></div>
                  {/* Pending portion */}
                  <div
                    title={`${item.pendingCount} Pending`}
                    style={{
                      width: `${
                        filteredFloors.length > 0
                          ? (item.pendingCount / filteredFloors.length) * 100
                          : 0
                      }%`,
                    }}
                    className="bg-amber-400 h-full transition-all duration-300"
                  ></div>
                  {/* Not Started portion */}
                  <div
                    title={`${item.noneCount} Not Started`}
                    style={{
                      width: `${
                        filteredFloors.length > 0
                          ? (item.noneCount / filteredFloors.length) * 100
                          : 0
                      }%`,
                    }}
                    className="bg-slate-200 h-full transition-all duration-300"
                  ></div>
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-400">
                  <span className="text-emerald-600 font-semibold">{item.paidCount} Certified</span>
                  <span className="text-amber-600 font-semibold">{item.pendingCount} Pending</span>
                  <span>{item.noneCount} Not Started</span>
                </div>
              </div>
            ))}

            {unitStats.length === 0 && (
              <div className="py-8 text-center text-slate-400 text-xs font-semibold">
                No active plastering units found in configurations.
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Active Labours Productivity Leaderboard */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-4 space-y-4 shadow-xs">
          <div className="border-b border-slate-100 pb-3 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="text-xs font-black uppercase text-slate-800 tracking-wider">
                Labour Output &amp; Billing Ledger
              </h3>
              <p className="text-[11px] text-slate-400 font-medium">Cumulative sqft done and payment summary</p>
            </div>

            {/* Micro search */}
            <div className="flex items-center space-x-1.5 bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1 w-full sm:w-auto max-w-xs focus-within:border-emerald-500">
              <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <input
                type="text"
                placeholder="Search Labour..."
                value={labourSearchQuery}
                onChange={(e) => setLabourSearchQuery(e.target.value)}
                className="bg-transparent border-none text-xs focus:outline-hidden text-slate-800 font-semibold w-full"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-600 font-bold uppercase text-[10px] border-b border-slate-200">
                  <th className="p-2.5">Labour Name</th>
                  <th className="p-2.5 text-right">Assigned Floors</th>
                  <th className="p-2.5 text-right">Certified Sqft</th>
                  <th className="p-2.5 text-right">Rate</th>
                  <th className="p-2.5 text-right font-black text-emerald-700">Gross Earned (Est)</th>
                  <th className="p-2.5 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {labourLeaderboard.map((item) => (
                  <tr key={item.name} className="hover:bg-slate-50 transition-colors">
                    <td className="p-2.5">
                      <span className="font-extrabold text-slate-900 block">{item.name}</span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        {item.registered ? 'Verified Partner' : 'Manual / Guest Account'}
                      </span>
                    </td>
                    <td className="p-2.5 text-right font-bold text-slate-700">
                      {item.floorsCount} floors
                    </td>
                    <td className="p-2.5 text-right font-mono font-black text-slate-800">
                      {item.completedSqft.toLocaleString('en-IN')} Sqft
                    </td>
                    <td className="p-2.5 text-right font-mono text-slate-500">
                      ₹{item.rate}/sqft
                    </td>
                    <td className="p-2.5 text-right font-mono font-black text-emerald-700 bg-emerald-50/20">
                      ₹{item.earned.toLocaleString('en-IN')}
                    </td>
                    <td className="p-2.5 text-center">
                      {item.registered ? (
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full text-[9px] font-black uppercase inline-block border border-emerald-200">
                          Verified
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-500 rounded-full text-[9px] font-bold uppercase inline-block border border-slate-200">
                          Unregistered
                        </span>
                      )}
                    </td>
                  </tr>
                ))}

                {labourLeaderboard.length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-400 text-xs font-semibold">
                      No matching registered or active labours found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
