import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { AlertTriangle } from 'lucide-react';
import {
  FloorEntry,
  BillHeader,
  UnitSqftConfig,
  UserRole,
  UserAccessInfo,
  UserAccount,
  LabourMonthlyApproval,
} from './types';
import { HeaderNav } from './components/HeaderNav';
import { SummaryMetrics } from './components/SummaryMetrics';
import { FloorTable } from './components/FloorTable';
import { FloorCardsView } from './components/FloorCardsView';
import { LabourBillingView } from './components/LabourBillingView';
import { MonthlySummaryView } from './components/MonthlySummaryView';
import { FloorEntryModal } from './components/FloorEntryModal';
import { TowerManagementModal } from './components/TowerManagementModal';
import { SettingsModal } from './components/SettingsModal';
import { UserRoleModal } from './components/UserRoleModal';
import { GmailAuthModal } from './components/GmailAuthModal';
import { OwnerAdminModal } from './components/OwnerAdminModal';
import { SupervisorDashboard } from './components/SupervisorDashboard';
import { RegistrationGateView } from './components/RegistrationGateView';
import { AnalyticsDashboardView } from './components/AnalyticsDashboardView';
import { LabourRegistrationModal } from './components/LabourRegistrationModal';
import { auth, onAuthStateChanged, User as FirebaseUser, signOutUser } from './firebase';

import {
  loadLifetimeFloors,
  saveLifetimeFloors,
  loadLifetimeHeader,
  saveLifetimeHeader,
  loadLifetimeSqftConfig,
  saveLifetimeSqftConfig,
} from './utils/lifetimeStorage';
import {
  fetchFloorsFromFirestore,
  saveFloorsToFirestore,
  saveFloorToFirestore,
  deleteFloorFromFirestore,
  fetchBillHeaderFromFirestore,
  saveBillHeaderToFirestore,
  fetchUnitSqftConfigFromFirestore,
  saveUnitSqftConfigToFirestore,
  saveLifetimeUserBackup,
  fetchLifetimeUserBackup,
} from './services/firestoreService';
import { getUniqueTowers, generateFloorsForNewTower, deduplicateFloors } from './utils/towerHelper';
import { getUniqueLabourNames } from './utils/labourBillHelper';
import {
  loadLabourAccounts,
  saveLabourAccount,
  deleteLabourAccount,
  loadMonthlyApprovals,
  saveMonthlyApproval,
  resolveUserAccess,
  isOwnerEmail,
} from './utils/labourAccountHelper';
import { exportDataAsBackupJSON, restoreBackupFromJSON } from './utils/backupManager';
import { generateVectorSummaryPDF } from './utils/pdfGenerator';
import { INITIAL_FLOORS, INITIAL_BILL_HEADER, INITIAL_UNIT_SQFT_CONFIG } from './data/initialData';

export default function App() {
  // Core Data States
  const [floors, setFloors] = useState<FloorEntry[]>(() => {
    const cached = loadLifetimeFloors();
    return cached && cached.length > 0 ? deduplicateFloors(cached) : INITIAL_FLOORS;
  });

  const [header, setHeader] = useState<BillHeader>(() => {
    const cached = loadLifetimeHeader();
    return cached || INITIAL_BILL_HEADER;
  });

  const [sqftConfig, setSqftConfig] = useState<UnitSqftConfig>(() => {
    const cached = loadLifetimeSqftConfig();
    return cached || INITIAL_UNIT_SQFT_CONFIG;
  });

  // UI Navigation States
  const [selectedTower, setSelectedTower] = useState<string>('Tower 2');
  const [selectedMonth, setSelectedMonth] = useState<string>('__ALL__');
  const [activeView, setActiveView] = useState<'table' | 'cards' | 'labour' | 'monthly' | 'analytics' | 'supervisor'>('table');

  // User & Role Access States
  const [accounts, setAccounts] = useState<UserAccount[]>([]);
  const [roleOverride, setRoleOverride] = useState<UserRole | null>('owner');
  const [labourNameOverride, setLabourNameOverride] = useState<string | null>(null);

  // Firebase Auth & Gmail Account States
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);

  // Modals States
  const [floorModalOpen, setFloorModalOpen] = useState(false);
  const [editingFloor, setEditingFloor] = useState<FloorEntry | null>(null);
  const [towerModalOpen, setTowerModalOpen] = useState(false);
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);
  const [userModalOpen, setUserModalOpen] = useState(false);
  const [gmailModalOpen, setGmailModalOpen] = useState(false);
  const [ownerAdminModalOpen, setOwnerAdminModalOpen] = useState(false);
  const [addLabourModalOpen, setAddLabourModalOpen] = useState(false);
  const [monthlyApprovals, setMonthlyApprovals] = useState<LabourMonthlyApproval[]>([]);

  // Sync & Feedback States
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastBackupTime, setLastBackupTime] = useState<string>('');

  // 0. Listen to Firebase Auth state (Gmail ID login)
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user && user.email) {
        if (isOwnerEmail(user.email)) {
          setRoleOverride('owner');
        }

        // Auto-restore lifetime backup if available
        try {
          const cloudBackup = await fetchLifetimeUserBackup(user.email);
          if (cloudBackup && cloudBackup.floors && cloudBackup.floors.length > 0) {
            setFloors((curr) => {
              if (curr.length <= cloudBackup.floors.length) {
                const deduped = deduplicateFloors(cloudBackup.floors);
                saveLifetimeFloors(deduped);
                return deduped;
              }
              return curr;
            });
            if (cloudBackup.header) {
              setHeader(cloudBackup.header);
              saveLifetimeHeader(cloudBackup.header);
            }
            if (cloudBackup.sqftConfig) {
              setSqftConfig(cloudBackup.sqftConfig);
              saveLifetimeSqftConfig(cloudBackup.sqftConfig);
            }
            if (cloudBackup.updatedAt) {
              setLastBackupTime(new Date(cloudBackup.updatedAt).toLocaleTimeString());
            }
          }
        } catch (e) {
          console.warn('Auto restore check from user backup warning:', e);
        }
      }
    });

    return () => unsubscribe();
  }, []);

  // 1. Initial Load & Cloud Sync
  useEffect(() => {
    let isMounted = true;

    async function initData() {
      setIsSyncing(true);
      try {
        // Load labour accounts and monthly approvals
        const [loadedAccs, loadedApprovals] = await Promise.all([
          loadLabourAccounts(),
          loadMonthlyApprovals(),
        ]);
        if (isMounted) {
          setAccounts(loadedAccs);
          setMonthlyApprovals(loadedApprovals);
        }

        // Fetch from Firestore
        const [cloudFloors, cloudHeader, cloudSqft] = await Promise.all([
          fetchFloorsFromFirestore(),
          fetchBillHeaderFromFirestore(),
          fetchUnitSqftConfigFromFirestore(),
        ]);

        if (isMounted) {
          if (cloudFloors && cloudFloors.length > 0) {
            const deduped = deduplicateFloors(cloudFloors);
            setFloors(deduped);
            saveLifetimeFloors(deduped);
          } else {
            // Seed Firestore with initial floors
            await saveFloorsToFirestore(floors);
          }

          if (cloudHeader) {
            setHeader(cloudHeader);
            saveLifetimeHeader(cloudHeader);
          } else {
            await saveBillHeaderToFirestore(header);
          }

          if (cloudSqft) {
            setSqftConfig(cloudSqft);
            saveLifetimeSqftConfig(cloudSqft);
          } else {
            await saveUnitSqftConfigToFirestore(sqftConfig);
          }

          setLastBackupTime(new Date().toLocaleTimeString());
        }
      } catch (err) {
        console.warn('Initial cloud synchronization completed with local fallback:', err);
      } finally {
        if (isMounted) setIsSyncing(false);
      }
    }

    initData();

    return () => {
      isMounted = false;
    };
  }, []);

  // Compute available towers and ensure selectedTower matches existing ones
  const availableTowers = useMemo(() => {
    return getUniqueTowers(floors, header.towerNo);
  }, [floors, header.towerNo]);

  useEffect(() => {
    if (availableTowers.length > 0 && !availableTowers.includes(selectedTower)) {
      setSelectedTower(availableTowers[0]);
    }
  }, [availableTowers, selectedTower]);

  // Compute available months
  const availableMonths = useMemo(() => {
    const months = new Set<string>();
    floors.forEach((f) => {
      if (f.month && f.month.trim()) months.add(f.month.trim());
      else if (f.date && f.date.length >= 7) months.add(f.date.slice(0, 7));
    });
    if (months.size === 0) {
      months.add('2026-09');
      months.add('2026-08');
      months.add('2026-07');
    }
    return Array.from(months).sort().reverse();
  }, [floors]);

  // Resolve user permissions
  const userAccess = useMemo(() => {
    return resolveUserAccess(currentUser?.email || null, roleOverride, labourNameOverride, accounts);
  }, [currentUser?.email, roleOverride, labourNameOverride, accounts]);

  // Compute count of pending work entries (units with status 'pending') across all towers
  const pendingWorkCount = useMemo(() => {
    let count = 0;
    const unitKeys = [
      'unit1',
      'unit2',
      'unit3',
      'unit4',
      'unit5',
      'unit6',
      'unit7',
      'unit8',
      'lobby',
      'starc1',
      'starc2',
    ];
    floors.forEach((floor) => {
      unitKeys.forEach((key) => {
        if (floor[key as keyof FloorEntry] === 'pending') {
          count++;
        }
      });
    });
    return count;
  }, [floors]);

  // Programmatically lock labour role to the 'labour' view
  useEffect(() => {
    if (userAccess.isLabour && activeView !== 'labour') {
      setActiveView('labour');
    }
  }, [userAccess.isLabour, activeView]);

  // Filter floors for current tower and optional month
  const currentTowerFloors = useMemo(() => {
    return floors.filter((f) => {
      const matchesTower = (f.towerNo || 'Tower 2').toLowerCase() === selectedTower.toLowerCase();
      if (!matchesTower) return false;
      if (selectedMonth !== '__ALL__') {
        const fMonth = f.month || (f.date ? f.date.slice(0, 7) : '2026-09');
        if (fMonth !== selectedMonth) return false;
      }
      return true;
    });
  }, [floors, selectedTower, selectedMonth]);

  // 2. Data Update Handlers
  const handleUpdateFloor = useCallback(
    async (updated: FloorEntry) => {
      setFloors((prev) => {
        const next = prev.map((f) => (f.id === updated.id ? updated : f));
        saveLifetimeFloors(next);
        return next;
      });

      // Async Firestore sync
      try {
        await saveFloorToFirestore(updated);
        setLastBackupTime(new Date().toLocaleTimeString());
      } catch (err) {
        console.warn('Firestore update sync deferred:', err);
      }
    },
    []
  );

  const handleSaveFloorFromModal = useCallback(
    async (floorToSave: FloorEntry) => {
      setFloors((prev) => {
        const existingIndex = prev.findIndex((f) => f.id === floorToSave.id);
        let next: FloorEntry[];
        if (existingIndex >= 0) {
          next = [...prev];
          next[existingIndex] = floorToSave;
        } else {
          next = [floorToSave, ...prev];
        }
        const deduped = deduplicateFloors(next);
        saveLifetimeFloors(deduped);
        return deduped;
      });

      try {
        await saveFloorToFirestore(floorToSave);
        setLastBackupTime(new Date().toLocaleTimeString());
      } catch (err) {
        console.warn('Firestore floor save error:', err);
      }
    },
    []
  );

  const handleDeleteFloor = useCallback(async (floorId: string) => {
    setFloors((prev) => {
      const next = prev.filter((f) => f.id !== floorId);
      saveLifetimeFloors(next);
      return next;
    });

    try {
      await deleteFloorFromFirestore(floorId);
      setLastBackupTime(new Date().toLocaleTimeString());
    } catch (err) {
      console.warn('Firestore delete error:', err);
    }
  }, []);

  const handleAddTower = useCallback(
    async (newTowerName: string, floorCount: number) => {
      const newFloors = generateFloorsForNewTower({
        towerNo: newTowerName,
        scName: header.scName || 'SSR ENTERPRISES',
        floorTemplate: 'custom',
        customFloorCount: floorCount,
        initialStatus: 'pending',
        sqftConfig,
      });

      setFloors((prev) => {
        const combined = [...prev, ...newFloors];
        const deduped = deduplicateFloors(combined);
        saveLifetimeFloors(deduped);
        return deduped;
      });

      setSelectedTower(newTowerName);

      try {
        await saveFloorsToFirestore(newFloors);
        setLastBackupTime(new Date().toLocaleTimeString());
      } catch (err) {
        console.warn('Firestore tower batch sync deferred:', err);
      }
    },
    [header.scName, sqftConfig]
  );

  const handleBatchDeleteFloors = useCallback(async (floorIds: string[]) => {
    setFloors((prev) => {
      const next = prev.filter((f) => !floorIds.includes(f.id));
      saveLifetimeFloors(next);
      return next;
    });
    try {
      await Promise.all(floorIds.map((id) => deleteFloorFromFirestore(id)));
      setLastBackupTime(new Date().toLocaleTimeString());
    } catch (err) {
      console.warn('Firestore batch delete error:', err);
    }
  }, []);

  const handleBatchSaveFloors = useCallback(async (updatedFloors: FloorEntry[]) => {
    const deduped = deduplicateFloors(updatedFloors);
    setFloors(deduped);
    saveLifetimeFloors(deduped);
    try {
      await saveFloorsToFirestore(deduped);
      setLastBackupTime(new Date().toLocaleTimeString());
    } catch (err) {
      console.warn('Firestore batch save error:', err);
    }
  }, []);

  const handleAddTowerFloors = useCallback(async (newFloors: FloorEntry[]) => {
    setFloors((prev) => {
      const combined = [...prev, ...newFloors];
      const deduped = deduplicateFloors(combined);
      saveLifetimeFloors(deduped);
      return deduped;
    });
    if (newFloors.length > 0 && newFloors[0].towerNo) {
      setSelectedTower(newFloors[0].towerNo);
    }
    try {
      await saveFloorsToFirestore(newFloors);
      setLastBackupTime(new Date().toLocaleTimeString());
    } catch (err) {
      console.warn('Firestore add tower floors error:', err);
    }
  }, []);

  const handleSaveUserAccount = useCallback(async (account: UserAccount) => {
    await saveLabourAccount(account);
    setAccounts((prev) => {
      const idx = prev.findIndex(
        (a) => a.id === account.id || a.email.toLowerCase() === account.email.toLowerCase()
      );
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = account;
        return next;
      }
      return [account, ...prev];
    });
  }, []);

  const handleDeleteUserAccount = useCallback(async (accountId: string) => {
    await deleteLabourAccount(accountId);
    setAccounts((prev) => prev.filter((a) => a.id !== accountId));
  }, []);

  const handleSaveMonthlyApproval = useCallback(async (approval: LabourMonthlyApproval) => {
    await saveMonthlyApproval(approval);
    setMonthlyApprovals((prev) => {
      const idx = prev.findIndex((a) => a.id === approval.id);
      if (idx >= 0) {
        const next = [...prev];
        next[idx] = approval;
        return next;
      }
      return [approval, ...prev];
    });
  }, []);

  const handleSaveHeader = useCallback(async (newHeader: BillHeader) => {
    setHeader(newHeader);
    saveLifetimeHeader(newHeader);
    try {
      await saveBillHeaderToFirestore(newHeader);
    } catch (err) {
      console.warn('Firestore header save error:', err);
    }
  }, []);

  const handleSaveSqftConfig = useCallback(async (newSqft: UnitSqftConfig) => {
    setSqftConfig(newSqft);
    saveLifetimeSqftConfig(newSqft);
    try {
      await saveUnitSqftConfigToFirestore(newSqft);
    } catch (err) {
      console.warn('Firestore sqft save error:', err);
    }
  }, []);

  const handleManualSync = useCallback(async () => {
    setIsSyncing(true);
    try {
      await Promise.all([
        saveFloorsToFirestore(floors),
        saveBillHeaderToFirestore(header),
        saveUnitSqftConfigToFirestore(sqftConfig),
      ]);
      const email = currentUser?.email || 'ssre07860@gmail.com';
      await saveLifetimeUserBackup(email, { floors, header, sqftConfig });
      setLastBackupTime(new Date().toLocaleTimeString());
    } catch (err) {
      console.warn('Manual sync fallback to local store:', err);
    } finally {
      setIsSyncing(false);
    }
  }, [currentUser?.email, floors, header, sqftConfig]);

  // Gmail Lifetime Cloud Backup & Restore
  const handleBackupToGmailCloud = useCallback(async () => {
    setIsSyncing(true);
    try {
      const email = currentUser?.email || 'ssre07860@gmail.com';
      await Promise.all([
        saveFloorsToFirestore(floors),
        saveBillHeaderToFirestore(header),
        saveUnitSqftConfigToFirestore(sqftConfig),
        saveLifetimeUserBackup(email, { floors, header, sqftConfig }),
      ]);
      setLastBackupTime(new Date().toLocaleTimeString());
    } catch (err) {
      console.warn('Backup to Gmail Cloud error:', err);
      throw err;
    } finally {
      setIsSyncing(false);
    }
  }, [currentUser?.email, floors, header, sqftConfig]);

  const handleRestoreFromGmailCloud = useCallback(async () => {
    setIsSyncing(true);
    try {
      const email = currentUser?.email || 'ssre07860@gmail.com';
      const cloudBackup = await fetchLifetimeUserBackup(email);
      if (cloudBackup && cloudBackup.floors && cloudBackup.floors.length > 0) {
        const deduped = deduplicateFloors(cloudBackup.floors);
        setFloors(deduped);
        saveLifetimeFloors(deduped);
        if (cloudBackup.header) {
          setHeader(cloudBackup.header);
          saveLifetimeHeader(cloudBackup.header);
        }
        if (cloudBackup.sqftConfig) {
          setSqftConfig(cloudBackup.sqftConfig);
          saveLifetimeSqftConfig(cloudBackup.sqftConfig);
        }
        if (cloudBackup.updatedAt) {
          setLastBackupTime(new Date(cloudBackup.updatedAt).toLocaleTimeString());
        }
      } else {
        const [cloudFloors, cloudHeader, cloudSqft] = await Promise.all([
          fetchFloorsFromFirestore(),
          fetchBillHeaderFromFirestore(),
          fetchUnitSqftConfigFromFirestore(),
        ]);
        if (cloudFloors && cloudFloors.length > 0) {
          const deduped = deduplicateFloors(cloudFloors);
          setFloors(deduped);
          saveLifetimeFloors(deduped);
        }
        if (cloudHeader) {
          setHeader(cloudHeader);
          saveLifetimeHeader(cloudHeader);
        }
        if (cloudSqft) {
          setSqftConfig(cloudSqft);
          saveLifetimeSqftConfig(cloudSqft);
        }
        setLastBackupTime(new Date().toLocaleTimeString());
      }
    } catch (err) {
      console.warn('Restore from cloud error:', err);
      throw err;
    } finally {
      setIsSyncing(false);
    }
  }, [currentUser?.email]);

  // 3. PDF Export & Print Handlers
  const handleDownloadPDF = useCallback(
    async (format: 'a3' | 'a4') => {
      const filename = `Gypsum_Bill_Record_${selectedTower.replace(/\s+/g, '_')}_${format.toUpperCase()}.pdf`;
      generateVectorSummaryPDF(header, sqftConfig, currentTowerFloors, filename, {
        format,
        showLabourInUnits: true,
      });

      // Update exported floors in state & persistence
      const now = new Date().toISOString();
      const updatedFloors = floors.map((f) => {
        const isCurrent = currentTowerFloors.some((ctf) => ctf.id === f.id);
        if (!isCurrent) return f;
        const newStatus: 'both' | 'exported' = f.isBillPrinted ? 'both' : 'exported';
        return {
          ...f,
          isBillExported: true,
          billExportStatus: newStatus,
          billExportDate: now,
        };
      });
      setFloors(updatedFloors);
      saveLifetimeFloors(updatedFloors);
      try {
        await saveFloorsToFirestore(updatedFloors);
      } catch (err) {
        console.warn('Billing status sync after PDF export:', err);
      }
    },
    [header, sqftConfig, currentTowerFloors, selectedTower, floors]
  );

  const handlePrintPreview = useCallback(async () => {
    window.print();

    // Mark current tower floors as printed
    const now = new Date().toISOString();
    const updatedFloors = floors.map((f) => {
      const isCurrent = currentTowerFloors.some((ctf) => ctf.id === f.id);
      if (!isCurrent) return f;
      const newStatus: 'both' | 'printed' = f.isBillExported ? 'both' : 'printed';
      return {
        ...f,
        isBillPrinted: true,
        billExportStatus: newStatus,
        billExportDate: f.billExportDate || now,
      };
    });
    setFloors(updatedFloors);
    saveLifetimeFloors(updatedFloors);
    try {
      await saveFloorsToFirestore(updatedFloors);
    } catch (err) {
      console.warn('Billing status sync after print:', err);
    }
  }, [currentTowerFloors, floors]);

  // 4. Backup Export & Restore
  const handleExportBackup = useCallback(() => {
    exportDataAsBackupJSON(floors, header, sqftConfig, accounts);
  }, [floors, header, sqftConfig, accounts]);

  const handleImportBackup = useCallback(async (file: File) => {
    try {
      const result = await restoreBackupFromJSON(file);
      if (result.success && result.data) {
        if (result.data.floors) {
          const deduped = deduplicateFloors(result.data.floors);
          setFloors(deduped);
          saveLifetimeFloors(deduped);
          saveFloorsToFirestore(deduped);
        }
        if (result.data.header) {
          setHeader(result.data.header);
          saveLifetimeHeader(result.data.header);
          saveBillHeaderToFirestore(result.data.header);
        }
        if (result.data.sqftConfig) {
          setSqftConfig(result.data.sqftConfig);
          saveLifetimeSqftConfig(result.data.sqftConfig);
          saveUnitSqftConfigToFirestore(result.data.sqftConfig);
        }
        alert('Database restored successfully from backup!');
      } else {
        alert(result.error || 'Failed to restore backup.');
      }
    } catch (err) {
      alert('Error parsing backup file.');
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans antialiased flex flex-col">
      {/* Top Header & Navigation Bar */}
      {currentUser && (
        <HeaderNav
          header={header}
          selectedTower={selectedTower}
          availableTowers={availableTowers}
          onSelectTower={setSelectedTower}
          onOpenNewTowerModal={() => setTowerModalOpen(true)}
          selectedMonth={selectedMonth}
          availableMonths={availableMonths}
          onSelectMonth={setSelectedMonth}
          activeView={activeView}
          onChangeView={setActiveView}
          userAccess={userAccess}
          onOpenUserModal={() => setUserModalOpen(true)}
          onOpenSettingsModal={() => setSettingsModalOpen(true)}
          onOpenFloorModal={() => {
            setEditingFloor(null);
            setFloorModalOpen(true);
          }}
          onOpenAddLabourModal={() => setAddLabourModalOpen(true)}
          onDownloadPDF={handleDownloadPDF}
          onPrintPreview={handlePrintPreview}
          isSyncing={isSyncing}
          onManualSync={handleManualSync}
          lastBackupTime={lastBackupTime}
          currentUser={currentUser}
          onOpenGmailModal={() => setGmailModalOpen(true)}
          onOpenOwnerAdminModal={() => setOwnerAdminModalOpen(true)}
          onSignOut={() => auth.signOut()}
          pendingWorkCount={pendingWorkCount}
        />
      )}

      {/* Main Workspace Canvas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-4 py-4 sm:py-6">
        {!currentUser ? (
          <div className="fixed inset-0 bg-slate-900 flex flex-col items-center justify-center space-y-6 z-50">
             <h2 className="text-2xl font-bold text-white">S/C SSR ENTERPRISES</h2>
             <p className="text-slate-400">Please Login to Access Dashboard</p>
             <button
               onClick={() => setGmailModalOpen(true)}
               className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition flex items-center gap-2"
             >
               Verify & Login with Gmail
             </button>
          </div>
        ) : !userAccess.isApproved && !userAccess.isOwner ? (
          <RegistrationGateView
            currentUser={currentUser}
            accounts={accounts}
            onSaveUserAccount={handleSaveUserAccount}
            onSignOut={() => auth.signOut()}
          />
        ) : (
          <>
            {/* Dynamic Main View */}
            {activeView === 'table' && (
              <FloorTable
                floors={currentTowerFloors}
                header={header}
                sqftConfig={sqftConfig}
                userAccess={userAccess}
                accounts={accounts}
                onOpenAddLabourModal={() => setAddLabourModalOpen(true)}
                onUpdateFloor={handleUpdateFloor}
                onDeleteFloor={handleDeleteFloor}
                onEditFloorClick={(floor) => {
                  setEditingFloor(floor);
                  setFloorModalOpen(true);
                }}
              />
            )}

            {activeView === 'cards' && (
              <FloorCardsView
                floors={currentTowerFloors}
                header={header}
                sqftConfig={sqftConfig}
                userAccess={userAccess}
                onUpdateFloor={handleUpdateFloor}
                onEditFloorClick={(floor) => {
                  setEditingFloor(floor);
                  setFloorModalOpen(true);
                }}
              />
            )}

            {activeView === 'labour' && (
              <LabourBillingView
                floors={floors}
                sqftConfig={sqftConfig}
                header={header}
                userAccess={userAccess}
                accounts={accounts}
                monthlyApprovals={monthlyApprovals}
                onSaveUserAccount={handleSaveUserAccount}
              />
            )}

            {activeView === 'analytics' && (
              <AnalyticsDashboardView
                floors={floors}
                sqftConfig={sqftConfig}
                header={header}
                accounts={accounts}
                onSelectTower={setSelectedTower}
                onChangeView={setActiveView}
              />
            )}

            {activeView === 'monthly' && (
              <MonthlySummaryView
                floors={floors}
                sqftConfig={sqftConfig}
                header={header}
                userAccess={userAccess}
                accounts={accounts}
                onSelectMonthFilter={(month) => {
                  setSelectedMonth(month);
                  setActiveView('table');
                }}
              />
            )}

            {activeView === 'supervisor' && (
              <SupervisorDashboard
                floors={floors}
                sqftConfig={sqftConfig}
                header={header}
                userAccess={userAccess}
                onUpdateFloor={handleUpdateFloor}
                availableTowers={availableTowers}
                accounts={accounts}
                onSaveUserAccount={handleSaveUserAccount}
                onDeleteUserAccount={handleDeleteUserAccount}
                monthlyApprovals={monthlyApprovals}
              />
            )}
          </>
        )}
      </main>

      {/* Persistent Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs py-4 px-4 mt-auto">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center space-x-2">
            <span className="font-bold text-slate-200">{header.scName || 'SSR ENTERPRISES'}</span>
            <span>&bull;</span>
            <span>{header.projectName || 'Prestige Lavender Field'}</span>
            <span>&bull;</span>
            <span className="text-emerald-400 font-semibold">{selectedTower}</span>
          </div>

          <div className="flex items-center space-x-4 text-[11px]">
            <span>Cloud &amp; Local Auto-Sync Active</span>
            <span>&bull;</span>
            <span>Supervisor: {header.supervisorSignature || 'Adel'}</span>
            <span>&bull;</span>
            <span>Contractor: {header.contractorSignature || 'Rizwan'}</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <FloorEntryModal
        isOpen={floorModalOpen}
        floor={editingFloor}
        onClose={() => {
          setFloorModalOpen(false);
          setEditingFloor(null);
          }}
        onSave={handleSaveFloorFromModal}
        sqftConfig={sqftConfig}
        header={header}
        activeTower={selectedTower}
        accounts={accounts}
      />

      <TowerManagementModal
        isOpen={towerModalOpen}
        onClose={() => setTowerModalOpen(false)}
        availableTowers={availableTowers}
        activeTower={selectedTower}
        onSelectTower={(t) => {
          setSelectedTower(t);
          setTowerModalOpen(false);
        }}
        onAddTower={handleAddTower}
      />

      <SettingsModal
        isOpen={settingsModalOpen}
        onClose={() => setSettingsModalOpen(false)}
        header={header}
        sqftConfig={sqftConfig}
        onSaveHeader={handleSaveHeader}
        onSaveSqftConfig={handleSaveSqftConfig}
        onExportBackupJSON={handleExportBackup}
        onImportBackupJSON={handleImportBackup}
      />

      <UserRoleModal
        isOpen={userModalOpen}
        onClose={() => setUserModalOpen(false)}
        userAccess={userAccess}
        availableLabours={getUniqueLabourNames(floors)}
        accounts={accounts}
        onSwitchRole={(role, labourName) => {
          setRoleOverride(role);
          setLabourNameOverride(labourName || null);
        }}
        onOpenOwnerAdminModal={() => setOwnerAdminModalOpen(true)}
      />

      <GmailAuthModal
        isOpen={gmailModalOpen}
        onClose={() => setGmailModalOpen(false)}
        currentUser={currentUser}
        onBackupNow={handleBackupToGmailCloud}
        onRestoreFromCloud={handleRestoreFromGmailCloud}
        lastBackupTime={lastBackupTime}
        totalFloorsCount={floors.length}
      />

      {ownerAdminModalOpen && (
        <OwnerAdminModal
          isOpen={ownerAdminModalOpen}
          onClose={() => setOwnerAdminModalOpen(false)}
          currentUser={currentUser}
          userAccess={userAccess}
          floors={floors}
          header={header}
          sqftConfig={sqftConfig}
          accounts={accounts}
          monthlyApprovals={monthlyApprovals}
          onSaveHeader={handleSaveHeader}
          onSaveSqftConfig={handleSaveSqftConfig}
          onUpdateFloor={handleUpdateFloor}
          onDeleteFloor={handleDeleteFloor}
          onBatchDeleteFloors={handleBatchDeleteFloors}
          onBatchSaveFloors={handleBatchSaveFloors}
          onAddTowerFloors={handleAddTowerFloors}
          onSaveUserAccount={handleSaveUserAccount}
          onDeleteUserAccount={handleDeleteUserAccount}
          onSaveMonthlyApproval={handleSaveMonthlyApproval}
          onOpenGmailModal={() => {
            setOwnerAdminModalOpen(false);
            setGmailModalOpen(true);
          }}
          onBackupNow={handleBackupToGmailCloud}
          onRestoreFromCloud={handleRestoreFromGmailCloud}
          onEditFloorClick={(floor) => {
            setOwnerAdminModalOpen(false);
            setEditingFloor(floor);
            setFloorModalOpen(true);
          }}
        />
      )}

      {/* Direct Add Labour Modal Triggered from Main Portal */}
      {addLabourModalOpen && (
        <LabourRegistrationModal
          isOpen={addLabourModalOpen}
          onClose={() => setAddLabourModalOpen(false)}
          userAccess={userAccess}
          accounts={accounts}
          onSaveUserAccount={async (acc) => {
            await handleSaveUserAccount(acc);
            setAddLabourModalOpen(false);
          }}
          onDeleteUserAccount={handleDeleteUserAccount}
        />
      )}
    </div>
  );
}
