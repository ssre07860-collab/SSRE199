import React, { useState } from 'react';
import {
  X,
  Mail,
  Lock,
  CloudCheck,
  CheckCircle2,
  AlertCircle,
  LogOut,
  RefreshCw,
  Shield,
  User,
  ArrowRight,
  Database,
  CloudUpload,
  CloudDownload,
  Info,
} from 'lucide-react';
import { User as FirebaseUser } from 'firebase/auth';
import {
  signInWithGoogle,
  signInWithGmailPassword,
  registerWithGmailPassword,
  signOutUser,
} from '../firebase';
import { isOwnerEmail } from '../utils/labourAccountHelper';

interface GmailAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: FirebaseUser | null;
  onBackupNow: () => Promise<void>;
  onRestoreFromCloud: () => Promise<void>;
  lastBackupTime?: string;
  totalFloorsCount: number;
}

export const GmailAuthModal: React.FC<GmailAuthModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onBackupNow,
  onRestoreFromCloud,
  lastBackupTime,
  totalFloorsCount,
}) => {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('ssre07860@gmail.com');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('SSR Enterprises');
  const [loading, setLoading] = useState(false);
  const [backupLoading, setBackupLoading] = useState(false);
  const [restoreLoading, setRestoreLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    setError(null);
    setSuccessMsg(null);
    setLoading(true);
    try {
      const user = await signInWithGoogle();
      setSuccessMsg(`Logged in successfully as ${user.email}! Lifetime Cloud Backup Active.`);
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      console.error('Google sign in error:', err);
      if (err?.code === 'auth/popup-blocked') {
        setError('Popup was blocked by browser. Please allow popups or use Gmail & Password login below.');
      } else if (err?.code === 'auth/popup-closed-by-user') {
        setError('Sign-in popup was closed before completing.');
      } else {
        setError(err?.message || 'Failed to sign in with Google. You can also log in with Gmail & Password below.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEmailPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please enter both Gmail address and password.');
      return;
    }
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (tab === 'login') {
        const user = await signInWithGmailPassword(email, password);
        setSuccessMsg(`Logged in successfully as ${user.email}! Lifetime Cloud Data Linked.`);
        setTimeout(() => {
          onClose();
        }, 1200);
      } else {
        const user = await registerWithGmailPassword(email, password, displayName);
        setSuccessMsg(`Account created & logged in as ${user.email}! All data is permanently backed up.`);
        setTimeout(() => {
          onClose();
        }, 1200);
      }
    } catch (err: any) {
      console.error('Email sign in error:', err);
      if (err?.code === 'auth/user-not-found' || err?.code === 'auth/invalid-credential') {
        setError('No account found with this Gmail/password combination. If this is your first time, switch to "Create New Account" below.');
      } else if (err?.code === 'auth/email-already-in-use') {
        setError('This Gmail is already registered. Please enter your password or click "Login".');
      } else if (err?.code === 'auth/weak-password') {
        setError('Password should be at least 6 characters.');
      } else {
        setError(err?.message || 'Authentication failed. Please check your credentials.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    setLoading(true);
    try {
      await signOutUser();
      setSuccessMsg('Signed out successfully.');
    } catch (err: any) {
      setError(err?.message || 'Failed to sign out.');
    } finally {
      setLoading(false);
    }
  };

  const triggerBackup = async () => {
    setBackupLoading(true);
    setError(null);
    setSuccessMsg(null);
    try {
      await onBackupNow();
      setSuccessMsg('All floors, tower data, and bill headers successfully backed up to your Gmail Cloud!');
    } catch (err: any) {
      setError(err?.message || 'Could not complete cloud backup.');
    } finally {
      setBackupLoading(false);
    }
  };

  const triggerRestore = async () => {
    if (!window.confirm('Restore all data from your Gmail Cloud Backup? This will update your local records with the latest cloud snapshot.')) {
      return;
    }
    setRestoreLoading(true);
    setError(null);
    setSuccessMsg(null);
    try {
      await onRestoreFromCloud();
      setSuccessMsg('All data successfully restored from your Gmail Cloud Backup!');
    } catch (err: any) {
      setError(err?.message || 'Could not restore from cloud.');
    } finally {
      setRestoreLoading(false);
    }
  };

  const isUserOwner = currentUser && isOwnerEmail(currentUser.email);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-[#0f172a] rounded-3xl shadow-2xl border border-slate-700 w-full max-w-md overflow-hidden flex flex-col">
        {/* Header - VIP Style */}
        <div className="p-6 bg-gradient-to-br from-slate-900 to-[#0f172a] text-white text-center border-b border-slate-700">
          <div className="mx-auto w-16 h-16 rounded-2xl bg-emerald-950/50 border border-emerald-500/30 flex items-center justify-center shadow-lg mb-4">
            <Shield className="w-8 h-8 text-emerald-400" />
          </div>
          <h2 className="text-2xl font-black tracking-tight text-white mb-1">
            SSR ADMIN PANEL
          </h2>
          <p className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
            Prestige Lavender Field
          </p>
        </div>

        <div className="p-6 space-y-6 overflow-y-auto flex-1 text-sm bg-[#0f172a]">
          {/* Status / Alert notifications */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-950/30 border border-rose-800 text-rose-200 flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <div className="text-xs font-medium leading-relaxed">{error}</div>
            </div>
          )}
          
          {/* ... Rest of the component logic ... */}

          {/* Status / Alert notifications */}
          {error && (
            <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <div className="text-[11px] font-medium leading-relaxed">{error}</div>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 flex items-start space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div className="text-[11px] font-bold leading-relaxed">{successMsg}</div>
            </div>
          )}

          {/* Current Signed-In User State */}
          {currentUser && !currentUser.isAnonymous ? (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-gradient-to-br from-slate-900 to-slate-800 text-white border border-slate-700 shadow-md">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-400 flex items-center space-x-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                    <span>Logged In with Gmail</span>
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                      isUserOwner
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : 'bg-sky-500/20 text-sky-300 border border-sky-500/30'
                    }`}
                  >
                    {isUserOwner ? 'Owner / Super Contractor' : 'Site Member'}
                  </span>
                </div>

                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-slate-700 border-2 border-emerald-500 flex items-center justify-center font-bold text-white text-sm shadow-inner">
                    {currentUser.photoURL ? (
                      <img
                        src={currentUser.photoURL}
                        alt="User Avatar"
                        className="w-full h-full rounded-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      currentUser.email ? currentUser.email.charAt(0).toUpperCase() : 'U'
                    )}
                  </div>
                  <div className="overflow-hidden">
                    <div className="font-bold text-sm text-white truncate">
                      {currentUser.displayName || currentUser.email?.split('@')[0]}
                    </div>
                    <div className="text-slate-300 text-xs font-mono truncate">
                      {currentUser.email}
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-3 border-t border-slate-700/80 flex items-center justify-between text-[11px] text-slate-300">
                  <span>Cloud Records: <strong className="text-emerald-400 font-bold">{totalFloorsCount} Floors</strong></span>
                  <span>Last Sync: <strong className="text-slate-200">{lastBackupTime || 'Active'}</strong></span>
                </div>
              </div>

              {/* Lifetime Cloud Actions */}
              <div className="p-3.5 bg-emerald-50/60 rounded-xl border border-emerald-200 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Database className="w-4 h-4 text-emerald-700" />
                    <span className="font-black text-emerald-950 text-xs">Lifetime Gmail Cloud Storage</span>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-600 text-white font-bold text-[10px]">
                    Permanent
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Aapka poora data (Towers, Floors 1 to 26+, Bill Headers, Rates, aur Labour Vouchers) aapke Gmail ID se hamesha ke liye Cloud Firestore me surakshit rahega. Kisi bhi phone ya computer me bas apna Gmail ID login karo aur poora data turant open ho jayega!
                </p>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={triggerBackup}
                    disabled={backupLoading}
                    className="flex items-center justify-center space-x-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-xs shadow-xs transition"
                  >
                    <CloudUpload className={`w-3.5 h-3.5 ${backupLoading ? 'animate-bounce' : ''}`} />
                    <span>{backupLoading ? 'Saving...' : 'Backup Now'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={triggerRestore}
                    disabled={restoreLoading}
                    className="flex items-center justify-center space-x-1.5 px-3 py-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 rounded-lg font-bold text-xs transition"
                  >
                    <CloudDownload className={`w-3.5 h-3.5 text-sky-600 ${restoreLoading ? 'animate-bounce' : ''}`} />
                    <span>{restoreLoading ? 'Restoring...' : 'Restore Data'}</span>
                  </button>
                </div>
              </div>

              {/* Logout Option */}
              <div className="pt-2 flex justify-end">
                <button
                  type="button"
                  onClick={handleSignOut}
                  disabled={loading}
                  className="flex items-center space-x-1.5 text-rose-600 hover:text-rose-700 font-bold text-xs px-3 py-1.5 rounded-lg hover:bg-rose-50 border border-rose-200 transition"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Logout from this device</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Highlight Banner */}
              <div className="p-3 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl border border-emerald-200 flex items-start space-x-2.5">
                <CloudCheck className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-black text-emerald-950 text-xs">
                    Lifetime Cloud Storage Guarantee
                  </h3>
                  <p className="text-[11px] text-emerald-800/90 mt-0.5 leading-relaxed">
                    Apne Gmail ID se login karein. Aapka saara summary bill data Firestore Cloud me lifetime secure rahega. Kabhi bhi doosre mobile ya computer par apna Gmail ID daal kar poora data wapas khol sakte hain.
                  </p>
                </div>
              </div>

              {/* Quick Google One-Click Button */}
              <div>
                <button
                  type="button"
                  onClick={handleGoogleSignIn}
                  disabled={loading}
                  className="w-full flex items-center justify-center space-x-2.5 px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-800 font-bold rounded-xl border-2 border-slate-300 shadow-xs hover:border-slate-400 transition"
                >
                  <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.66v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.15z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.98 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                    />
                  </svg>
                  <span>{loading ? 'Connecting to Google...' : 'Continue with Google Account'}</span>
                </button>
              </div>

              <div className="relative flex items-center justify-center">
                <div className="border-t border-slate-200 w-full"></div>
                <span className="bg-white px-3 text-[11px] font-bold text-slate-400 uppercase">
                  Or use Gmail &amp; Password
                </span>
              </div>

          {/* Tabs */}
              <div className="flex rounded-xl bg-slate-900 p-1 border border-slate-700">
                <button
                  type="button"
                  onClick={() => setTab('login')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg transition ${
                    tab === 'login' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Login
                </button>
                <button
                  type="button"
                  onClick={() => setTab('register')}
                  className={`flex-1 py-2 text-xs font-bold rounded-lg transition ${
                    tab === 'register' ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Register
                </button>
              </div>

              {/* Form */}
              <form onSubmit={handleEmailPasswordSubmit} className="space-y-4">
                {tab === 'register' && (
                  <div>
                    <label className="block text-[11px] font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                      Organization Name
                    </label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="e.g. SSR Enterprises"
                      className="w-full px-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                )}

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Gmail Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-500 absolute left-4 top-3.5" />
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="yourname@gmail.com"
                      className="w-full pl-11 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-400 mb-1.5 uppercase tracking-wider">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-500 absolute left-4 top-3.5" />
                    <input
                      type="password"
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-11 pr-4 py-3 bg-slate-900 border border-slate-700 rounded-xl text-white text-sm focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex items-center justify-center space-x-2 py-3.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-sm rounded-xl shadow-lg transition cursor-pointer"
                >
                  <span>{loading ? 'Processing...' : tab === 'login' ? 'Secure Access' : 'Create Account'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>


              {/* Quick Owner Hint */}
              <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-600 flex items-center space-x-2">
                <Info className="w-4 h-4 text-slate-400 shrink-0" />
                <span>
                  Super Contractor Email: <strong className="text-slate-900 font-mono">ssre07860@gmail.com</strong> (Owner Access)
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-[11px] text-slate-500">
          <span>Firebase Cloud Database Connected</span>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1 bg-white hover:bg-slate-100 text-slate-700 font-bold rounded-lg border border-slate-200"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
